"""
Metadata models for serverless analyzer.
"""

from dataclasses import dataclass
from typing import Optional


@dataclass
class WorkspaceMetadata:
    """Enhanced workspace metadata for a notebook/file."""

    object_id: Optional[int] = None
    object_type: Optional[str] = None
    path: Optional[str] = None
    language: Optional[str] = None
    size: Optional[int] = None
    created_at: Optional[str] = None
    modified_at: Optional[str] = None
    created_by: Optional[str] = None
    modified_by: Optional[str] = None
    object_name: Optional[str] = None
    parent_path: Optional[str] = None
    is_dir: Optional[bool] = None
    file_extension: Optional[str] = None
    workspace_url: Optional[str] = None
