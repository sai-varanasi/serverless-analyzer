"""
Issue models for serverless analyzer.
"""

from dataclasses import dataclass
from typing import List, Optional


@dataclass
class IssueDetail:
    """Details about a compatibility issue."""

    type: str
    description: str
    line_number: int
    code_snippet: str
    severity: str
    impact: str
    recommendation: str
    affected_apis: Optional[List[str]] = None
    related_issues: Optional[List[str]] = None
    is_skipped: bool = False
    skip_reason: Optional[str] = None
