#!/usr/bin/env python3
from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any, Optional, cast, List, Dict
from databricks.sdk import WorkspaceClient
from databricks.labs.lsql.core import StatementExecutionExt


@dataclass
class PublishConfig:
    """Configuration for publishing analysis results to Unity Catalog."""

    catalog: str = "main"
    schema: str = "serverless_reports"
    warehouse_id: str | None = None
    dataset_table_name: str = "serverless_analysis_consolidated"
    detailed_table_name: str = "notebook_reports_detailed"


class WarehouseManager:
    """Ensures a usable SQL Warehouse is available and returns its ID."""

    def __init__(self, w: WorkspaceClient):
        self.w = w

    def _warehouse_id_or_none(self, obj: Any) -> Optional[str]:
        wid = getattr(obj, "id", None)
        return cast(Optional[str], wid)

    def ensure(self, warehouse_id: str | None) -> str:
        """Return a valid warehouse id, creating/selecting one if needed."""
        if warehouse_id:
            try:
                wh_get = self.w.warehouses.get(id=warehouse_id)
                wid = self._warehouse_id_or_none(wh_get)
                if wid:
                    return wid
            except Exception:
                pass

        for env in ["TEST_DEFAULT_WAREHOUSE_ID", "DATABRICKS_SQL_WAREHOUSE_ID"]:
            eid = os.getenv(env)
            if not eid:
                continue
            try:
                wh_env = self.w.warehouses.get(id=eid)
                wid = self._warehouse_id_or_none(wh_env)
                if wid:
                    return wid
            except Exception:
                continue

        candidates: List[Any] = []
        for wh_list in self.w.warehouses.list():
            state = getattr(wh_list, "state", None)
            if state in {"DELETING", "DELETED"}:
                continue
            candidates.append(wh_list)

        def is_serverless(wh_any: Any) -> bool:
            wt = getattr(wh_any, "warehouse_type", None)
            return str(wt or "").upper() == "SERVERLESS"

        for wh_any in candidates:
            if is_serverless(wh_any):
                wid = self._warehouse_id_or_none(wh_any)
                if wid:
                    return wid
        for wh_any in candidates:
            wid = self._warehouse_id_or_none(wh_any)
            if wid:
                return wid

        name = "serverless_analyzer_warehouse"
        # Try to request serverless type where supported; otherwise fall back
        try:
            from databricks.sdk.service.sql import WarehouseType  # type: ignore[attr-defined]

            created = self.w.warehouses.create(
                name=name,
                cluster_size="2X-SMALL",
                warehouse_type=getattr(WarehouseType, "SERVERLESS", None),
                enable_photon=True,
            )
        except Exception:
            created = self.w.warehouses.create(
                name=name,
                cluster_size="2X-SMALL",
                enable_photon=True,
            )
        wid = self._warehouse_id_or_none(created)
        if not wid:
            raise RuntimeError("Failed to create a SQL warehouse (no id returned)")
        return wid


class AnalysisPublisher:
    """Publishes serverless analysis results to Unity Catalog using LSQL."""

    def __init__(self, cfg: PublishConfig, logger: Any | None = None):
        self.cfg = cfg
        self.logger = logger
        self.w = WorkspaceClient()
        wm = WarehouseManager(self.w)
        wid = wm.ensure(cfg.warehouse_id)
        self.warehouse_id: str = wid
        if self.logger:
            try:
                self.logger.info(
                    f"Using SQL Warehouse: {wid} | Target: {cfg.catalog}.{cfg.schema}"
                )
            except Exception:
                pass
        self.sql = StatementExecutionExt(
            self.w,
            warehouse_id=wid,
            catalog=cfg.catalog,
            schema=cfg.schema,
        )

    # ---------- Public API ----------

    def publish_dataset_summary(self, report: Dict[str, Any]) -> None:
        """Publish the aggregated dataset summary table from the consolidated report."""
        self._ensure_schema_exists()
        dataset_fq = self._dataset_table_fq()
        if self.logger:
            try:
                total_rows = len(report.get("notebook_reports", []))
                self.logger.info(
                    f"Publishing dataset summary to {dataset_fq} (rows: {total_rows})"
                )
            except Exception:
                pass
        self._create_dataset_table_if_missing(dataset_fq)
        self._upsert_dataset_rows(dataset_fq, report)
        if self.logger:
            try:
                self.logger.info(
                    f"Completed publishing dataset summary to {dataset_fq}"
                )
            except Exception:
                pass

    def publish_notebook_detailed(self, detailed_reports: List[Dict[str, Any]]) -> None:
        """Publish per-notebook detailed reports into the configured detailed table."""
        self._ensure_schema_exists()
        table_fq = self._detailed_table_fq()
        if self.logger:
            try:
                self.logger.info(
                    f"Publishing detailed reports to {table_fq} (rows: {len(detailed_reports)})"
                )
            except Exception:
                pass
        self._create_detailed_table_if_missing(table_fq)
        self._insert_detailed_rows(table_fq, detailed_reports)
        if self.logger:
            try:
                self.logger.info(f"Completed publishing detailed reports to {table_fq}")
            except Exception:
                pass

    # ---------- Internal helpers ----------

    def _dataset_table_fq(self) -> str:
        return f"{self.cfg.catalog}.{self.cfg.schema}.{self.cfg.dataset_table_name}"

    def _detailed_table_fq(self) -> str:
        return f"{self.cfg.catalog}.{self.cfg.schema}.{self.cfg.detailed_table_name}"

    def _sql_literal(self, value: Any) -> str:
        if value is None:
            return "NULL"
        if isinstance(value, bool):
            return "TRUE" if value else "FALSE"
        if isinstance(value, (int, float)):
            return str(value)
        s = str(value).replace("'", "''")
        return f"'{s}'"

    def _upsert_dataset_rows(self, dataset_fq: str, report: Dict[str, Any]) -> None:
        ts = report.get("analysis_timestamp")
        if ts is not None:
            ts_escaped = str(ts).replace("'", "''")
            try:
                self.sql.execute(
                    f"DELETE FROM {dataset_fq} WHERE analysis_timestamp = '{ts_escaped}'"
                )
            except Exception as e:
                raise RuntimeError(
                    f"Failed deleting existing rows from {dataset_fq}: {e}"
                )

        rows: List[Dict[str, Any]] = []
        for n in report.get("notebook_reports", []):
            # Normalize migration_effort to an integer value
            mig = n.get("migration_effort", 0)
            if isinstance(mig, dict):
                mig = mig.get("estimated_hours", 0)
            try:
                mig_int = int(mig)
            except Exception:
                mig_int = 0

            rows.append({
                "analysis_timestamp": ts,
                "total_notebooks": report.get("total_notebooks", 0),
                "compatible_notebooks": report.get("compatible_notebooks", 0),
                "incompatible_notebooks": report.get("incompatible_notebooks", 0),
                "total_migration_effort": report.get("total_migration_effort", 0),
                "risk_assessment": (report.get("summary", {}) or {}).get(
                    "risk_assessment", "Unknown"
                ),
                "notebook_path": n.get("path"),
                "is_compatible": bool(n.get("is_compatible", False)),
                "complexity": str(n.get("complexity", "")).upper(),
                "total_issues": int(n.get("total_issues", 0)),
                "migration_effort": mig_int,
            })

        if self.logger:
            try:
                self.logger.info(
                    f"Upserting {len(rows)} dataset rows into {dataset_fq}"
                )
            except Exception:
                pass

        if not rows:
            return None

        chunk_size = 500
        for i in range(0, len(rows), chunk_size):
            chunk = rows[i : i + chunk_size]
            values_list: List[str] = []
            for r in chunk:
                values = [
                    self._sql_literal(r["analysis_timestamp"]),
                    self._sql_literal(r["total_notebooks"]),
                    self._sql_literal(r["compatible_notebooks"]),
                    self._sql_literal(r["incompatible_notebooks"]),
                    self._sql_literal(r["total_migration_effort"]),
                    self._sql_literal(r["risk_assessment"]),
                    self._sql_literal(r["notebook_path"]),
                    self._sql_literal(r["is_compatible"]),
                    self._sql_literal(r["complexity"]),
                    self._sql_literal(r["total_issues"]),
                    self._sql_literal(r["migration_effort"]),
                ]
                values_list.append(f"({', '.join(values)})")
            values_sql = ",\n".join(values_list)
            try:
                self.sql.execute(
                    f"""
INSERT INTO {dataset_fq} (
  analysis_timestamp,
  total_notebooks,
  compatible_notebooks,
  incompatible_notebooks,
  total_migration_effort,
  risk_assessment,
  notebook_path,
  is_compatible,
  complexity,
  total_issues,
  migration_effort
) VALUES {values_sql}
                    """
                )
            except Exception as e:
                raise RuntimeError(
                    f"Failed inserting rows into {dataset_fq} (chunk starting at {i}): {e}"
                )
            if self.logger:
                try:
                    end = min(i + chunk_size, len(rows))
                    self.logger.info(
                        f"Inserted rows {i + 1}-{end} of {len(rows)} into {dataset_fq}"
                    )
                except Exception:
                    pass
        return None

    def _insert_detailed_rows(
        self, table_fq: str, detailed_reports: List[Dict[str, Any]]
    ) -> None:
        if self.logger:
            try:
                self.logger.info(
                    f"Inserting {len(detailed_reports)} detailed rows into {table_fq}"
                )
            except Exception:
                pass

        if not detailed_reports:
            return None

        chunk_size = 250
        for i in range(0, len(detailed_reports), chunk_size):
            chunk = detailed_reports[i : i + chunk_size]
            values_list: List[str] = []
            for r in chunk:
                values = [
                    self._sql_literal(r.get("analysis_timestamp")),
                    self._sql_literal(r.get("notebook_path")),
                    self._sql_literal(r.get("complexity")),
                    self._sql_literal(r.get("is_compatible")),
                    self._sql_literal(r.get("total_issues")),
                    self._sql_literal(r.get("migration_effort")),
                    self._sql_literal(r.get("issue_counts_json")),
                    self._sql_literal(r.get("detailed_issues_json")),
                    self._sql_literal(r.get("notebook_metadata_json")),
                    self._sql_literal(r.get("spark_configurations_json")),
                ]
                values_list.append(f"({', '.join(values)})")
            values_sql = ",\n".join(values_list)
            try:
                self.sql.execute(
                    f"""
INSERT INTO {table_fq} (
  analysis_timestamp,
  notebook_path,
  complexity,
  is_compatible,
  total_issues,
  migration_effort,
  issue_counts_json,
  detailed_issues_json,
  notebook_metadata_json,
  spark_configurations_json
) VALUES {values_sql}
                    """
                )
            except Exception as e:
                raise RuntimeError(
                    f"Failed inserting rows into {table_fq} (chunk starting at {i}): {e}"
                )
            if self.logger:
                try:
                    end = min(i + chunk_size, len(detailed_reports))
                    self.logger.info(
                        f"Inserted rows {i + 1}-{end} of {len(detailed_reports)} into {table_fq}"
                    )
                except Exception:
                    pass
        return None

    def _create_dataset_table_if_missing(self, dataset_fq: str) -> None:
        self.sql.execute(
            f"""CREATE TABLE IF NOT EXISTS {dataset_fq} (
  analysis_timestamp STRING,
  total_notebooks INT,
  compatible_notebooks INT,
  incompatible_notebooks INT,
  total_migration_effort INT,
  risk_assessment STRING,
  notebook_path STRING,
  is_compatible BOOLEAN,
  complexity STRING,
  total_issues INT,
  migration_effort INT
) USING DELTA
            """
        )

    def _create_detailed_table_if_missing(self, table_fq: str) -> None:
        self.sql.execute(
            f"""CREATE TABLE IF NOT EXISTS {table_fq} (
  analysis_timestamp STRING,
  notebook_path STRING,
  complexity STRING,
  is_compatible BOOLEAN,
  total_issues INT,
  migration_effort INT,
  issue_counts_json STRING,
  detailed_issues_json STRING,
  notebook_metadata_json STRING,
  spark_configurations_json STRING
) USING DELTA
            """
        )

    def _ensure_schema_exists(self) -> None:
        self.sql.execute(
            f"CREATE SCHEMA IF NOT EXISTS {self.cfg.catalog}.{self.cfg.schema}"
        )
