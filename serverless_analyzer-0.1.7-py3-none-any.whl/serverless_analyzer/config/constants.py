"""
Constants for serverless analyzer.
"""

# Supported Spark configurations for serverless
SUPPORTED_SPARK_CONFIGS = [
    "spark.databricks.execution.timeout",
    "spark.sql.legacy.timeParserPolicy",
    "spark.sql.session.timeZone",
    "spark.sql.shuffle.partitions",
    "spark.sql.ansi.enabled",
]
