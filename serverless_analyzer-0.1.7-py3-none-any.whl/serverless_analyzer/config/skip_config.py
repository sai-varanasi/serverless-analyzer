"""
Skip configuration for serverless analyzer.
"""

from typing import List, Set, Optional, Dict
from .patterns import PATTERNS


class SkipConfig:
    """Manages skip patterns for compatibility checks."""

    def __init__(self, skip_checks: Optional[List[str]] = None):
        """
        Initialize skip configuration.

        Args:
            skip_checks: List of category or sub-pattern names to skip
        """
        self.skip_checks = skip_checks or []
        self.skip_categories: Set[str] = set()
        self.skip_sub_patterns: Set[str] = set()

        # Map all sub-patterns to their categories for reverse lookup
        self.sub_pattern_to_category: Dict[str, str] = {}
        for category, patterns in PATTERNS.items():
            if isinstance(patterns, dict):
                for sub_pattern in patterns.keys():
                    self.sub_pattern_to_category[sub_pattern] = category

        # Parse skip_checks into categories and sub-patterns
        self._parse_skip_checks()

    def _parse_skip_checks(self) -> None:
        """Parse skip_checks list into categories and sub-patterns."""
        for check in self.skip_checks:
            check = check.strip()
            if not check:
                continue

            # Check if it's a category
            if check in PATTERNS:
                self.skip_categories.add(check)
            # Check if it's a sub-pattern
            elif check in self.sub_pattern_to_category:
                self.skip_sub_patterns.add(check)
            else:
                # Will be caught during validation
                pass

    def should_skip(self, category: str, sub_pattern: Optional[str] = None) -> bool:
        """
        Check if a pattern should be skipped.

        Args:
            category: Pattern category name (e.g., "performance_concerns")
            sub_pattern: Optional sub-pattern name (e.g., "driver_actions")

        Returns:
            True if the pattern should be skipped
        """
        # Skip if entire category is in skip list
        if category in self.skip_categories:
            return True

        # Skip if specific sub-pattern is in skip list
        if sub_pattern and sub_pattern in self.skip_sub_patterns:
            return True

        return False

    def get_skip_reason(self, category: str, sub_pattern: Optional[str] = None) -> str:
        """
        Get the reason why a check is being skipped.

        Args:
            category: Pattern category name
            sub_pattern: Optional sub-pattern name

        Returns:
            Human-readable skip reason
        """
        # Prefer sub-pattern specific reason when provided
        if sub_pattern and sub_pattern in self.skip_sub_patterns:
            return f"Pattern '{sub_pattern}' skipped by user"

        if category in self.skip_categories:
            return f"Category '{category}' skipped by user"

        return "Skipped by user"

    def validate(self) -> List[str]:
        """
        Validate skip_checks against available patterns.

        Returns:
            List of validation error messages (empty if valid)
        """
        errors = []
        valid_categories = set(PATTERNS.keys())
        valid_sub_patterns = set(self.sub_pattern_to_category.keys())

        for check in self.skip_checks:
            check = check.strip()
            if not check:
                continue

            if check not in valid_categories and check not in valid_sub_patterns:
                errors.append(
                    f"Invalid check name: '{check}'. "
                    f"Run with --list-checks to see available options."
                )

        return errors

    @staticmethod
    def list_available_checks() -> Dict[str, List[str]]:
        """
        List all available check names organized by category.

        Returns:
            Dictionary mapping categories to their sub-patterns
        """
        available: Dict[str, List[str]] = {}
        for category, patterns in PATTERNS.items():
            # All PATTERNS values are dictionaries of sub-patterns
            available[category] = list(patterns.keys())
        return available

    @staticmethod
    def get_help_text() -> str:
        """
        Get help text for skip-checks feature.

        Returns:
            Formatted help text with examples
        """
        lines = [
            "Skip specific compatibility checks during analysis.",
            "",
            "Available Categories:",
        ]

        for category in sorted(PATTERNS.keys()):
            lines.append(f"  - {category}")

        lines.extend([
            "",
            "Available Sub-patterns:",
        ])

        sub_patterns: Set[str] = set()
        for patterns in PATTERNS.values():
            if isinstance(patterns, dict):
                sub_patterns.update(patterns.keys())

        for pattern in sorted(sub_patterns):
            lines.append(f"  - {pattern}")

        lines.extend([
            "",
            "Examples:",
            "  --skip-checks performance_concerns",
            "  --skip-checks driver_actions,cache_apis",
            "  --skip-checks performance_concerns,unsupported_caching",
        ])

        return "\n".join(lines)
