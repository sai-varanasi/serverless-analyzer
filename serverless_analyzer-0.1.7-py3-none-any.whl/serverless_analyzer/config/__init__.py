"""
Configuration for serverless analyzer.
"""

from .patterns import PATTERNS
from .constants import SUPPORTED_SPARK_CONFIGS
from .skip_config import SkipConfig

__all__ = [
    "PATTERNS",
    "SUPPORTED_SPARK_CONFIGS",
    "SkipConfig",
]
