#!/usr/bin/env python3
"""
Utility functions for Serverless Analyzer.
"""

import os
import json
import re
from typing import List, Any
from enum import Enum

# -----------------------------------------------------------------------------
# Notebook type Enum
# -----------------------------------------------------------------------------


class NotebookType(Enum):
    """Type of a notebook."""

    PYTHON = "python"
    SQL = "sql"
    SCALA = "scala"
    R = "r"
    IPYNB = "ipynb"
    MARKDOWN = "markdown"
    UNKNOWN = "unknown"


# -----------------------------------------------------------------------------
# Notebook language and type detection
# -----------------------------------------------------------------------------


def _determine_notebook_type_from_content(content: str) -> NotebookType:
    """
    Determine notebook type from content when API doesn't provide language information.

    This function examines the content patterns to detect the most likely programming
    language or notebook format.

    Args:
        content: Notebook content as string

    Returns:
        NotebookType enum value representing the detected notebook type
    """
    # Check if empty
    if not content or not content.strip():
        return NotebookType.UNKNOWN

    # Check if content is a Jupyter notebook (JSON format)
    try:
        if content.strip().startswith("{") and (
            '"cells":' in content or '"worksheets":' in content
        ):
            # It's a Jupyter notebook, try to determine language from cells
            notebook_data = json.loads(content)

            # Look for kernelspec in metadata
            language = (
                notebook_data.get("metadata", {})
                .get("kernelspec", {})
                .get("language", "")
                .lower()
            )

            if language:
                if language == "python":
                    return NotebookType.PYTHON
                elif language == "sql":
                    return NotebookType.SQL
                elif language == "scala":
                    return NotebookType.SCALA
                elif language == "r":
                    return NotebookType.R

            # If kernelspec doesn't have language, check the first code cell
            for cell in notebook_data.get("cells", []):
                if cell.get("cell_type") == "code":
                    # Look for magic commands or language-specific syntax
                    source = (
                        "".join(cell.get("source", ""))
                        if isinstance(cell.get("source"), list)
                        else cell.get("source", "")
                    )
                    if source:
                        if (
                            source.startswith("%python")
                            or "import " in source
                            or "def " in source
                        ):
                            return NotebookType.PYTHON
                        elif source.startswith("%sql") or "SELECT " in source.upper():
                            return NotebookType.SQL
                        elif (
                            source.startswith("%scala")
                            or "val " in source
                            or "object " in source
                        ):
                            return NotebookType.SCALA
                        elif source.startswith("%r") or "<-" in source:
                            return NotebookType.R
                    break

            # If we still couldn't determine, return IPYNB
            return NotebookType.IPYNB
    except (json.JSONDecodeError, ValueError, TypeError):
        # Not valid JSON, continue with other checks
        pass

    # If we reach here, check for language indicators in plaintext content

    # Check for Markdown
    md_patterns = ["# ", "## ", "### ", "---", "```", "*", "_"]
    md_score = sum(1 for pattern in md_patterns if pattern in content)
    if md_score >= 3 and not re.search(r"(import|class|def)\s+\w+", content):
        return NotebookType.MARKDOWN

    # Check for Python
    if (
        "# Databricks notebook source" in content
        or re.search(r"import\s+\w+", content)
        or re.search(r"from\s+\w+\s+import", content)
        or re.search(r"def\s+\w+\s*\(", content)
        or re.search(r"class\s+\w+\s*\(?\w*\)?:", content)
    ):
        return NotebookType.PYTHON

    # Check for SQL
    sql_patterns = [
        r"SELECT\s+",
        r"INSERT\s+INTO",
        r"UPDATE\s+",
        r"DELETE\s+FROM",
        r"CREATE\s+TABLE",
        r"DROP\s+",
        r"ALTER\s+TABLE",
        r"WITH\s+\w+\s+AS",
    ]
    if any(re.search(pattern, content, re.IGNORECASE) for pattern in sql_patterns):
        return NotebookType.SQL

    # Check for Scala
    scala_patterns = [
        r"val\s+\w+\s*=",
        r"var\s+\w+\s*=",
        r"def\s+\w+\s*\(.*\)",
        r"object\s+\w+",
        r"class\s+\w+",
        r"import\s+org\.apache\.spark",
    ]
    if any(re.search(pattern, content) for pattern in scala_patterns):
        return NotebookType.SCALA

    # Check for R
    r_patterns = [r"\w+\s*<-", r"library\(", r"function\("]
    if any(re.search(pattern, content) for pattern in r_patterns):
        return NotebookType.R

    # Default to UNKNOWN if we couldn't determine the type
    return NotebookType.UNKNOWN


def get_file_extension_for_notebook_type(notebook_type: NotebookType) -> str:
    """
    Get the appropriate file extension based on notebook type.

    Args:
        notebook_type: The NotebookType enum value

    Returns:
        File extension with leading dot (e.g. '.py')
    """
    extension_map = {
        NotebookType.PYTHON: ".py",
        NotebookType.SQL: ".sql",
        NotebookType.SCALA: ".scala",
        NotebookType.R: ".r",
        NotebookType.MARKDOWN: ".md",
        NotebookType.IPYNB: ".ipynb",
        NotebookType.UNKNOWN: ".txt",
    }

    return extension_map.get(notebook_type, ".txt")


def write_notebook_to_local(
    output_path: str, content: str, notebook_type: NotebookType
) -> str:
    """
    Write notebook content to a local file.

    Args:
        output_path: Path where to save the notebook
        content: Notebook content
        notebook_type: Type of notebook

    Returns:
        Path to the created file
    """
    if not os.path.exists(os.path.dirname(output_path)):
        os.makedirs(os.path.dirname(output_path), exist_ok=True)

    # Make sure the path has the appropriate extension
    extension = get_file_extension_for_notebook_type(notebook_type)

    # If output_path doesn't already have the correct extension, add it
    if not output_path.endswith(extension):
        output_path = os.path.splitext(output_path)[0] + extension

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(content)

    return output_path


def extract_notebook_cells(notebook_data: Any) -> List[str]:
    """
    Extract individual cells from a notebook.

    Args:
        notebook_data: Notebook data, can be various formats

    Returns:
        List of cell content strings
    """
    # For Databricks notebook JSON
    if isinstance(notebook_data, dict) and "commands" in notebook_data:
        return [cmd.get("command", "") for cmd in notebook_data.get("commands", [])]

    # For Jupyter notebook JSON
    if isinstance(notebook_data, dict) and "cells" in notebook_data:
        cells = []
        for cell in notebook_data.get("cells", []):
            if "source" in cell:
                if isinstance(cell["source"], list):
                    cells.append("".join(cell["source"]))
                else:
                    cells.append(cell["source"])
        return cells

    # If it's just a string, split by markdown headers as a heuristic
    if isinstance(notebook_data, str):
        # Try to split by markdown headers
        import re

        cells = re.split(r"^(#{1,6} .*)$", notebook_data, flags=re.MULTILINE)
        if len(cells) > 1:
            result = []
            for i in range(1, len(cells), 2):
                if i < len(cells) - 1:
                    result.append(cells[i] + cells[i + 1])
                else:
                    result.append(cells[i])
            return result

        # Otherwise, just return as a single cell
        return [notebook_data]

    # Default - empty list if we couldn't extract cells
    return []


def get_notebook_content(notebook_data: Any) -> str:
    """
    Get notebook content as a string.

    Args:
        notebook_data: Notebook data in various formats

    Returns:
        Notebook content as string
    """
    if isinstance(notebook_data, str):
        return notebook_data

    # Try to extract from JSON structures
    if isinstance(notebook_data, dict):
        # For Databricks notebooks
        if "commands" in notebook_data:
            cells = [
                cmd.get("command", "") for cmd in notebook_data.get("commands", [])
            ]
            return "\n\n".join(cells)

        # For Jupyter notebooks
        if "cells" in notebook_data:
            content = []
            for cell in notebook_data.get("cells", []):
                if "source" in cell:
                    if isinstance(cell["source"], list):
                        content.append("".join(cell["source"]))
                    else:
                        content.append(cell["source"])
            return "\n\n".join(content)

    # Default - stringify whatever we got
    return str(notebook_data)
