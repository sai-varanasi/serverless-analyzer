#!/usr/bin/env python3
"""
Entry point for the serverless-analyzer package when run as a module.
"""

from serverless_analyzer.cli.cli_runner import main

if __name__ == "__main__":
    raise SystemExit(main())
