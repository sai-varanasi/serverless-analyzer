#!/usr/bin/env python3
"""
Utility functions for working with Databricks DBC archives.
"""

import os
import logging
import zipfile
import json
import base64
from typing import Dict, List, Optional, Union, Any, cast
from rich.console import Console

# Set up logging and console
logger = logging.getLogger(__name__)
console = Console()


def format_size(size_bytes: float) -> str:
    """
    Format file size in a human-readable format.

    Args:
        size_bytes: Size in bytes

    Returns:
        Human-readable size string (e.g., "1.23 MB")
    """
    if size_bytes < 0:
        return f"-{format_size(-size_bytes)}"

    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if size_bytes < 1024.0 or unit == "TB":
            if unit == "B":
                return f"{int(size_bytes)} {unit}"
            return f"{size_bytes:.2f} {unit}"
        size_bytes /= 1024.0
    # Fallback; should not be reached due to 'TB' guard
    return f"{size_bytes:.2f} TB"


class DBCArchive:
    """Class for working with Databricks DBC archives."""

    def __init__(self, dbc_path: str, debug: bool = False) -> None:
        """
        Initialize a DBC archive object.

        Args:
            dbc_path: Path to the DBC file
            debug: Enable debug output
        """
        self.dbc_path = dbc_path
        self.debug = debug
        self.archive_type: Optional[str] = None  # 'zip' or 'tar' when valid

        if not os.path.exists(dbc_path):
            raise FileNotFoundError(f"DBC file not found: {dbc_path}")

        if not self._is_valid_dbc():
            error_msg = f"Invalid DBC file: {dbc_path}"
            if debug:
                logger.error(error_msg)
                self._print_archive_contents()
            raise ValueError(error_msg)

        logger.debug(f"Valid DBC file: {dbc_path}")

    def _print_archive_contents(self) -> None:
        """
        Print the contents of the archive file for debugging purposes.
        Works with both ZIP and TAR archives.
        """
        # Try as ZIP first
        try:
            with zipfile.ZipFile(self.dbc_path, "r") as zip_file:
                file_list = zip_file.namelist()
                logger.debug(f"ZIP file contains {len(file_list)} files")

                # Print first 20 files as a sample
                max_files_to_show = 20
                files_to_show = file_list[:max_files_to_show]
                logger.debug(f"Sample of files: {files_to_show}")

                if len(file_list) > max_files_to_show:
                    logger.debug(
                        f"...and {len(file_list) - max_files_to_show} more files"
                    )

                # Log file extensions
                extensions = set()
                for file in file_list:
                    ext = os.path.splitext(file)[1]
                    if ext:
                        extensions.add(ext)

                if extensions:
                    logger.debug(f"File extensions found: {sorted(list(extensions))}")
            return
        except zipfile.BadZipFile:
            logger.debug("Not a valid ZIP file, trying as TAR...")
        except Exception as e:
            logger.debug(f"Error reading ZIP file: {str(e)}, trying as TAR...")

        # Try as TAR if ZIP fails
        try:
            import tarfile

            with tarfile.open(self.dbc_path, "r:*") as tar_file:
                members = tar_file.getmembers()
                file_list = [m.name for m in members if m.isfile()]

                logger.debug(f"TAR file contains {len(file_list)} files")

                # Print first 20 files as a sample
                max_files_to_show = 20
                files_to_show = file_list[:max_files_to_show]
                logger.debug(f"Sample of files: {files_to_show}")

                if len(file_list) > max_files_to_show:
                    logger.debug(
                        f"...and {len(file_list) - max_files_to_show} more files"
                    )

                # Log file extensions
                extensions = set()
                for file in file_list:
                    ext = os.path.splitext(file)[1]
                    if ext:
                        extensions.add(ext)

                if extensions:
                    logger.debug(f"File extensions found: {sorted(list(extensions))}")
        except Exception as e:
            logger.debug(f"Error reading archive: {str(e)}")
            logger.debug("The file is neither a valid ZIP nor TAR archive")

    def _is_valid_dbc(self) -> bool:
        """
        Check if the file is a valid DBC (Databricks archive) file by attempting to extract its contents.
        """
        # Try as ZIP first
        if self._is_zip_file():
            try:
                with zipfile.ZipFile(self.dbc_path, "r") as zip_file:
                    file_list = zip_file.namelist()

                    # Check if the ZIP has valid DBC content
                    if self._check_file_list_for_dbc_content(
                        file_list, zip_file, "zip"
                    ):
                        self.archive_type = "zip"
                        return True
            except Exception as e:
                if self.debug:
                    logger.error(f"Error processing ZIP file: {str(e)}")
                return False

        # Not a valid DBC file
        return False

    def _check_file_list_for_dbc_content(
        self, file_list: List[str], archive: Any, archive_type: str
    ) -> bool:
        """
        Check if the file list contains valid DBC content structure.
        """
        # Check for known DBC file patterns
        notebook_files = [
            f
            for f in file_list
            if f.endswith(".python")
            or f.endswith(".scala")
            or f.endswith(".sql")
            or f.endswith(".r")
        ]
        metadata_files = [f for f in file_list if "/metadata" in f or f == "metadata"]

        # Simple heuristic: either has notebook files with recognized extensions
        # or has metadata files in proper structure
        return len(notebook_files) > 0 or len(metadata_files) > 0

    def _is_zip_file(self) -> bool:
        """Check if the file is a ZIP archive."""
        try:
            with open(self.dbc_path, "rb") as f:
                # Check for the ZIP magic number (PK)
                return f.read(2) == b"PK"
        except Exception:
            return False

    def get_notebook(self, notebook_path: str) -> Optional[Union[Dict[str, Any], str]]:
        """
        Get notebook data from the DBC archive.

        Args:
            notebook_path: Path to the notebook within the DBC file

        Returns:
            Dictionary with notebook data, plain string content, or None if not found
        """
        if not self.archive_type:
            raise ValueError("Not a valid DBC archive")

        # For ZIP archives
        if self.archive_type == "zip":
            try:
                with zipfile.ZipFile(self.dbc_path, "r") as zip_file:
                    # Try the exact path
                    try:
                        # Get binary content
                        content = zip_file.read(notebook_path)

                        # Try to decode as JSON
                        try:
                            notebook_data = cast(Dict[str, Any], json.loads(content))
                            return notebook_data
                        except json.JSONDecodeError:
                            # Not JSON, try to decode as base64
                            try:
                                decoded_content = base64.b64decode(content).decode(
                                    "utf-8"
                                )
                                return str(decoded_content)
                            except Exception:
                                # Return as plain text if not base64
                                return content.decode("utf-8", errors="replace")
                    except KeyError:
                        # The exact path wasn't found
                        pass

                    # Try with variations
                    variations = [
                        notebook_path,
                        notebook_path + ".python",
                        notebook_path + ".scala",
                        notebook_path + ".sql",
                        notebook_path + ".r",
                        # Try with different slashes
                        notebook_path.replace("/", "\\"),
                        notebook_path.replace("\\", "/"),
                    ]

                    for var in variations:
                        if var in zip_file.namelist():
                            content = zip_file.read(var)
                            try:
                                notebook_data = cast(
                                    Dict[str, Any], json.loads(content)
                                )
                                return notebook_data
                            except json.JSONDecodeError:
                                # Not JSON, try to decode as base64
                                try:
                                    decoded_content = base64.b64decode(content).decode(
                                        "utf-8"
                                    )
                                    return str(decoded_content)
                                except Exception:
                                    # Return as plain text if not base64
                                    return content.decode("utf-8", errors="replace")
            except Exception as e:
                if self.debug:
                    logger.error(f"Error getting notebook from DBC: {str(e)}")
                return None

        return None

    def list_notebooks(self) -> List[str]:
        """
        List notebooks in the DBC archive.

        Returns:
            List of notebook paths
        """
        if not self.archive_type:
            raise ValueError("Not a valid DBC archive")

        notebooks: List[str] = []

        # For ZIP archives
        if self.archive_type == "zip":
            try:
                with zipfile.ZipFile(self.dbc_path, "r") as zip_file:
                    for filename in zip_file.namelist():
                        if self._is_notebook_file(filename):
                            notebooks.append(self._get_notebook_name(filename))
            except Exception as e:
                if self.debug:
                    logger.error(f"Error listing notebooks: {str(e)}")

        return notebooks

    def _is_notebook_file(self, filename: str) -> bool:
        """
        Check if a file is a notebook based on its extension.

        Args:
            filename: Filename to check

        Returns:
            True if it's a notebook file, False otherwise
        """
        # Extensions for notebook files in a DBC
        notebook_extensions = [".python", ".scala", ".sql", ".r", ".ipynb"]

        # Check if the file has a notebook extension
        return any(filename.endswith(ext) for ext in notebook_extensions)

    def _get_notebook_name(self, filename: str) -> str:
        """
        Get the notebook name from its filename.

        Args:
            filename: Full filename with path in the DBC

        Returns:
            Notebook name without extension
        """
        # Remove any extension
        basename = os.path.basename(filename)
        for ext in [".python", ".scala", ".sql", ".r", ".ipynb"]:
            if basename.endswith(ext):
                return filename[: -len(ext)]

        # If no extension was removed, return the original filename
        return filename
