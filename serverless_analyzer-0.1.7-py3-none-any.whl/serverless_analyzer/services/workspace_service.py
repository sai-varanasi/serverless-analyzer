"""
Workspace service for managing workspace operations.
"""

from pathlib import Path
from typing import Any, Dict, List, Union, Sequence, Optional
from ..io.file_reader import FileReader
from ..io.workspace_client import WorkspaceClient
from ..models.metadata import WorkspaceMetadata


class WorkspaceService:
    """Service for managing workspace operations and metadata."""

    def __init__(self, logger: Optional[Any] = None) -> None:
        self.workspace_client = WorkspaceClient(logger=logger)
        self.file_reader = FileReader()
        self.logger = logger

    def get_workspace_metadata(
        self, paths: Sequence[Union[str, Path]]
    ) -> Dict[str, WorkspaceMetadata]:
        """Get metadata for multiple workspace paths."""
        metadata = {}

        for path in paths:
            path_str = str(path)

            if self.workspace_client.is_workspace_path(path_str):
                # Get metadata from workspace
                ws_metadata = self.workspace_client.get_notebook_metadata(path_str)
                if ws_metadata:
                    metadata[path_str] = ws_metadata
                else:
                    # Fallback to file metadata
                    metadata[path_str] = self.file_reader.get_file_metadata(path)
            else:
                # Get file metadata
                metadata[path_str] = self.file_reader.get_file_metadata(path)

        return metadata

    def list_workspace_contents(self, workspace_path: str) -> List[str]:
        """List contents of a workspace path."""
        if not self.workspace_client.is_workspace_path(workspace_path):
            if self.logger:
                self.logger.warning(f"Path is not a workspace path: {workspace_path}")
            return []

        return self.workspace_client.list_workspace_paths(workspace_path)

    def find_notebooks_in_workspace(self, workspace_path: str) -> List[str]:
        """Recursively find all files in a workspace path (not just by extension)."""
        if not self.workspace_client.is_workspace_path(workspace_path):
            if self.logger:
                self.logger.warning(f"Path is not a workspace path: {workspace_path}")
            return []

        try:
            files = list(self.workspace_client.iter_workspace_files(workspace_path))
            return files
        except Exception as e:
            if self.logger:
                self.logger.warning(
                    f"Error recursively listing workspace files for {workspace_path}: {e}"
                )
            return []

    def get_system_table_queries(self, workspace_paths: List[str]) -> Dict[str, str]:
        """Generate system table queries for workspace analysis.

        Returns a dictionary of query_name -> SQL text. Includes a commented
        example block of analyzed notebook paths and preserves the :path_filter
        placeholder for user-provided filtering.
        """
        # Build commented example path block (only workspace-like paths)
        example_paths: List[str] = []
        for p in workspace_paths:
            try:
                if self.workspace_client.is_workspace_path(p):
                    example_paths.append(p)
            except Exception:
                # Ignore any unexpected errors in detection
                pass

        example_comment_lines = [
            "-- Example path filter values (auto-detected from analysis):"
        ]
        if example_paths:
            # Limit to a reasonable number of lines
            for ep in example_paths[:50]:
                example_comment_lines.append(f"-- {ep}")
        else:
            example_comment_lines.append("-- (no workspace paths detected)")
        example_comment_lines.append(
            "-- Use with: ... IN (:path_filter) where :path_filter is a list of paths"
        )
        example_comment_block = "\n".join(example_comment_lines)

        queries: Dict[str, str] = {}

        # Query 1: Audit logs for notebook activities
        queries["audit_logs_notebook_access"] = f"""
-- Query to get audit logs for notebook activities
{example_comment_block}
WITH notebook_activity AS (
    SELECT 
        event_date,
        event_time,
        user_identity.email as user_email,
        service_name,
        action_name,
        request_id,
        response.status_code,
        COALESCE(
            request_params.path, 
            request_params.notebook_path, 
            request_params.object_path
        ) as notebook_path,
        audit_level,
        user_identity.subject_name
    FROM system.access.audit
    WHERE 
        event_date >= CURRENT_DATE() - INTERVAL 30 DAYS
        AND service_name = "notebook"
        AND (
            COALESCE(
                request_params.path, 
                request_params.notebook_path, 
                request_params.object_path
            ) IN (:path_filter)
        )
        AND action_name IN (
                      'createNotebook', 
             'deleteNotebook', 'runCommand', 'downloadPreviewResults','downloadLargeResults'
        )
),
daily_activity_summary AS (
    SELECT 
        event_date,
        notebook_path,
        user_email,
        COUNT(CASE WHEN action_name IN ('notebookRun', 'commandRun', 'commandSubmit') THEN 1 END) as execution_count,
        COUNT(CASE WHEN action_name IN ('notebookRead', 'notebookEdit') THEN 1 END) as development_count,
        COUNT(*) as total_activities
    FROM notebook_activity
    GROUP BY event_date, notebook_path, user_email
)
SELECT 
    event_date,
    notebook_path,
    user_email,
    execution_count,
    development_count,
    total_activities,
    CASE 
        WHEN execution_count > 0 THEN 'Active Execution'
        WHEN development_count > 0 THEN 'Development Only'
        ELSE 'Other'
    END as activity_type
FROM daily_activity_summary
ORDER BY event_date DESC, execution_count DESC;
""".strip()

        # Query 2: Query history for notebooks (when notebooks execute SQL)
        queries["query_history_serverless_analysis"] = """
-- Query to get SQL query execution history from notebooks
WITH query_executions AS (
    SELECT 
        statement_id,
        statement_text,
        statement_type,
        executed_by,
        start_time,
        end_time,
        compute.type as compute_type,
        compute.warehouse_id,
        compute.cluster_id,
        total_duration_ms,
        compilation_duration_ms,
        execution_duration_ms,
        read_bytes,
        written_bytes,
        written_files,
        written_rows,
        client_application,
        account_id,
        workspace_id
        -- Detect serverless usage
    FROM system.query.history 
    WHERE start_time >= CURRENT_DATE() - INTERVAL 30 DAY
        AND (
            statement_text LIKE '%-- MAGIC%'
            OR statement_text LIKE '%-- COMMAND%'
            OR client_application LIKE '%notebook%'
            OR client_application LIKE '%Databricks%'
            OR client_application LIKE '%DatabricksNotebook%'
        )
),
query_performance_analysis AS (
    SELECT 
        compute_type,
        statement_type,
        COUNT(*) as query_count,
        AVG(total_duration_ms) as avg_duration_ms,
        SUM(read_bytes) as total_read_bytes,
        SUM(written_bytes) as total_written_bytes,
        AVG(execution_duration_ms) as avg_execution_ms
    FROM query_executions
    GROUP BY compute_type, statement_type
)
SELECT 
    compute_type,
    statement_type,
    query_count,
    ROUND(avg_duration_ms / 1000, 2) as avg_duration_seconds,
    ROUND(avg_execution_ms / 1000, 2) as avg_execution_seconds,
    ROUND(total_read_bytes / (1024*1024), 2) as total_read_mb,
    ROUND(total_written_bytes / (1024*1024), 2) as total_written_mb
FROM query_performance_analysis
ORDER BY query_count DESC, avg_duration_ms DESC;
""".strip()

        # Query 3: Job runs and compute usage
        queries["job_runs_compute"] = """
-- Query to get job runs that may be related to notebooks


SELECT 
    run_id,
    job_id,
    period_start_time,
    period_end_time,
    result_state,
    
    -- setup_duration_ms,
    -- execution_duration_ms,
    -- cleanup_duration_ms,
    trigger,
    creator_user_name,
    run_name,
    run_type
FROM system.lakeflow.job_run_timeline
WHERE period_start_time >= CURRENT_DATE() - INTERVAL 30 DAY
ORDER BY period_start_time DESC;
""".strip()

        # Query 4: Job task runs for more granular analysis
        queries["cluster_usage_serverless_migration"] = """
-- Query to get job task runs and compute resources used
WITH cluster_usage AS (
    SELECT 
        c.cluster_id,
        c.cluster_name,
        c.owned_by,
        c.driver_node_type,
        c.worker_node_type,
        c.worker_count,
        c.auto_termination_minutes,
        c.cluster_source,
        c.dbr_version,
        c.create_time,
        c.delete_time,
        c.data_security_mode,
        -- Identify clusters that could be migrated to serverless
        CASE 
            WHEN c.cluster_source in ('UI', 'API') AND c.auto_termination_minutes <= 60 THEN 'Good Serverless Candidate'
            WHEN c.cluster_source = 'JOB' AND c.worker_count <= 2 THEN 'Potential Serverless Job'
            WHEN c.cluster_source in ('UI', 'API') AND c.auto_termination_minutes > 60 THEN 'Review Auto-termination'
            ELSE 'Traditional Use Case'
        END as serverless_migration_potential
    FROM system.compute.clusters c
    WHERE c.create_time >= CURRENT_DATE() - INTERVAL 30 DAY
),
cluster_costs AS (
    SELECT 
        sku_name,
        usage_metadata.cluster_id,
        COUNT(DISTINCT usage_date) as active_days,
        SUM(usage_quantity) as total_usage_units
    FROM system.billing.usage 
    WHERE usage_date >= CURRENT_DATE() - INTERVAL 30 DAY
        AND usage_metadata.cluster_id IS NOT NULL
        -- AND sku_name LIKE '%COMPUTE%'
    GROUP BY usage_metadata.cluster_id, sku_name
)
SELECT 
    cu.cluster_id,
    cu.cluster_name,
    cu.owned_by,
    cu.cluster_source,
    cu.worker_count,
    cu.auto_termination_minutes,
    cu.serverless_migration_potential,
    cu.create_time,
    cu.delete_time,
    cc.active_days,
    cc.total_usage_units,
    CASE 
        WHEN cc.total_usage_units > 0 THEN 'Cost Incurred'
        ELSE 'No Cost Data'
    END as cost_status
FROM cluster_usage cu
LEFT JOIN cluster_costs cc ON cu.cluster_id = cc.cluster_id
ORDER BY cu.create_time DESC;
""".strip()

        # Query 5: Billing usage for compute resources
        queries["billing_usage_compute"] = """
-- Query to get compute costs and DBU usage
SELECT 
    usage_date,
    account_id,
    workspace_id,
    sku_name,
    cloud,
    usage_start_time,
    usage_end_time,
    usage_date,
    usage_unit,
    usage_type,
    usage_quantity,
    usage_metadata
FROM system.billing.usage 
WHERE usage_date >= CURRENT_DATE() - INTERVAL 30 DAY
    AND sku_name LIKE '%COMPUTE%'
ORDER BY usage_date DESC;
""".strip()

        # Query 6: Data lineage with impact analysis for serverless migration
        queries["data_lineage_impact_analysis"] = """
-- Query to get data lineage with impact analysis for serverless migration
WITH table_access_patterns AS (
    SELECT 
        COALESCE( source_path, concat_ws('.',source_table_catalog,source_table_schema,source_table_full_name)
        )as source_asset ,
        COALESCE( target_path, concat_ws('.',target_table_catalog,target_table_schema,target_table_full_name)) as target_asset,
        source_type,
        target_type,
        entity_type,
        entity_id,
        event_date,
        event_time
    FROM system.access.table_lineage
    WHERE event_date >= CURRENT_DATE() - INTERVAL 30 DAY
),
lineage_summary AS (
    SELECT 
      source_type,
      target_type,
        COUNT(DISTINCT source_asset) as source_tables,
        COUNT(DISTINCT target_asset) as target_tables,
        COUNT(*) as lineage_events,
        COUNT(DISTINCT entity_id) as unique_entities
    FROM table_access_patterns
    GROUP BY source_type, target_type
)
SELECT 
          source_type,
      target_type,
    source_tables,
    target_tables,
    lineage_events,
    unique_entities
FROM lineage_summary
ORDER BY lineage_events DESC;
""".strip()

        return queries

    def validate_workspace_access(self, workspace_path: str) -> bool:
        """Validate access to a workspace path."""
        if not self.workspace_client.is_workspace_path(workspace_path):
            return False

        try:
            # Try to list the path to validate access
            self.workspace_client.list_workspace_paths(workspace_path)
            return True
        except Exception as e:
            if self.logger:
                self.logger.warning(
                    f"Cannot access workspace path {workspace_path}: {e}"
                )
            return False

    def get_workspace_summary(self, workspace_path: str) -> Dict[str, Any]:
        """Get a summary of workspace contents."""
        if not self.workspace_client.is_workspace_path(workspace_path):
            return {"error": "Not a workspace path"}

        try:
            # Get all notebook paths
            notebook_paths = self.find_notebooks_in_workspace(workspace_path)

            # Get metadata for all paths
            metadata = self.get_workspace_metadata(notebook_paths)

            # Calculate summary statistics
            total_notebooks = len(notebook_paths)
            languages: Dict[str, int] = {}
            total_size: int = 0

            for path, meta in metadata.items():
                if meta.language:
                    languages[meta.language] = languages.get(meta.language, 0) + 1
                if meta.size:
                    total_size += meta.size

            return {
                "workspace_path": workspace_path,
                "total_notebooks": total_notebooks,
                "languages": languages,
                "total_size_bytes": total_size,
                "notebook_paths": notebook_paths,
                "metadata": {
                    path: {
                        "object_id": meta.object_id,
                        "object_type": meta.object_type,
                        "language": meta.language,
                        "size": meta.size,
                        "created_at": meta.created_at,
                        "modified_at": meta.modified_at,
                    }
                    for path, meta in metadata.items()
                },
            }
        except Exception as e:
            if self.logger:
                self.logger.error(
                    f"Error getting workspace summary for {workspace_path}: {e}"
                )
            return {"error": str(e)}
