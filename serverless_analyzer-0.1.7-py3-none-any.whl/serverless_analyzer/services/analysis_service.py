"""
Analysis service for orchestrating notebook analysis.
"""

from pathlib import Path
from typing import Any, Dict, List, Optional, Union, Sequence

from ..core.analyzer import CompatibilityAnalyzer
from ..io.file_reader import FileReader
from ..io.notebook_parser import NotebookParser
from ..io.workspace_client import WorkspaceClient
from .workspace_service import WorkspaceService
from ..models.analysis import ConsolidatedReport, ServerlessAnalysis


class AnalysisService:
    """Service for orchestrating notebook analysis operations."""

    def __init__(
        self,
        scala_as_jar: bool = False,
        verbose: bool = False,
        logger: Optional[Any] = None,
        force_workspace: bool = False,
        max_file_size: int = 10 * 1024 * 1024,
        skip_checks: Optional[List[str]] = None,
    ) -> None:
        self.analyzer = CompatibilityAnalyzer(
            scala_as_jar=scala_as_jar, skip_checks=skip_checks
        )
        self.file_reader = FileReader()
        self.notebook_parser = NotebookParser()
        self.workspace_client = WorkspaceClient(logger=logger)
        # When set, treat workspace-like paths as workspace even if env detection fails
        self.force_workspace = force_workspace
        self.max_file_size = max_file_size
        self.verbose = verbose
        self.logger = logger

    def analyze_notebook(self, notebook_path: Union[str, Path]) -> ServerlessAnalysis:
        """Analyze a single notebook."""
        path = Path(notebook_path)

        if self.verbose and self.logger:
            self.logger.info(f"Analyzing notebook: {path}")

        try:
            # Get notebook content
            content = self._get_notebook_content(path)
            if not content:
                error_msg = f"Could not read content from {path}"
                if self.logger:
                    self.logger.warning(error_msg)
                return self._create_empty_analysis(str(path), error_msg)

            # Get metadata
            metadata = self._get_notebook_metadata(path)

            # Analyze the content
            analysis = self.analyzer.analyze_notebook_from_content(content, str(path))

            # Update metadata in analysis
            analysis.notebook_metadata.update(metadata)

            if self.verbose and self.logger:
                self.logger.info(f"Successfully analyzed notebook: {path}")
                self.logger.info(f"Found {sum(analysis.issue_counts.values())} issues")

            return analysis

        except Exception as e:
            error_msg = f"Error analyzing notebook {path}: {str(e)}"
            if self.logger:
                self.logger.error(error_msg)
            return self._create_empty_analysis(str(path), error_msg)

    def analyze_multiple_notebooks(
        self, notebook_paths: Sequence[Union[str, Path]]
    ) -> List[ServerlessAnalysis]:
        """Analyze multiple notebooks."""
        analyses = []

        if self.verbose and self.logger:
            self.logger.info(f"Analyzing {len(notebook_paths)} notebooks")

        for i, path in enumerate(notebook_paths, 1):
            try:
                if self.verbose and self.logger:
                    self.logger.info(
                        f"Analyzing notebook {i}/{len(notebook_paths)}: {path}"
                    )

                analysis = self.analyze_notebook(path)
                analyses.append(analysis)
            except Exception as e:
                error_msg = f"Error analyzing {path}: {e}"
                if self.logger:
                    self.logger.error(error_msg)
                # Create empty analysis for failed notebooks
                analyses.append(self._create_empty_analysis(str(path), error_msg))

        return analyses

    def analyze_directory(
        self, directory_path: Union[str, Path]
    ) -> List[ServerlessAnalysis]:
        """Analyze all notebooks in a directory."""
        # Workspace directory path handling
        if self._is_workspace_path(str(directory_path)):
            ws = WorkspaceService(logger=self.logger)
            notebook_paths = ws.find_notebooks_in_workspace(str(directory_path))
            if self.verbose and self.logger:
                self.logger.info(
                    f"Found {len(notebook_paths)} workspace notebooks in {directory_path}"
                )
            return self.analyze_multiple_notebooks(notebook_paths)

        path = Path(directory_path)

        if not path.exists():
            error_msg = f"Directory does not exist: {path}"
            if self.logger:
                self.logger.error(error_msg)
            return []

        # Find all notebook files
        notebook_files = self.file_reader.find_notebook_files(path)

        if self.verbose and self.logger:
            self.logger.info(f"Found {len(notebook_files)} notebook files in {path}")

        if not notebook_files:
            if self.logger:
                # Extra diagnostic to help when users expect workspace discovery
                self.logger.warning(f"No notebook files found in {path}.")

        return self.analyze_multiple_notebooks(notebook_files)

    def create_consolidated_report(
        self, analyses: List[ServerlessAnalysis]
    ) -> ConsolidatedReport:
        """Create a consolidated report from multiple analyses."""
        if not analyses:
            return self._create_empty_consolidated_report()

        if self.verbose and self.logger:
            self.logger.info(
                f"Creating consolidated report for {len(analyses)} analyses"
            )

        # Calculate summary statistics
        total_notebooks = len(analyses)
        compatible_notebooks = sum(1 for a in analyses if a.is_compatible)
        incompatible_notebooks = total_notebooks - compatible_notebooks

        # Complexity distribution
        complexity_distribution: Dict[str, int] = {}
        for analysis in analyses:
            complexity = analysis.complexity.value
            complexity_distribution[complexity] = (
                complexity_distribution.get(complexity, 0) + 1
            )

        # Issue distribution (active-only). Track skipped separately.
        issue_distribution: Dict[str, int] = {}
        skipped_issues_total = 0
        for analysis in analyses:
            for issue_type, count in analysis.issue_counts.items():
                if issue_type == "skipped_issues":
                    skipped_issues_total += count
                    continue
                issue_distribution[issue_type] = (
                    issue_distribution.get(issue_type, 0) + count
                )

        # Total migration effort
        total_migration_effort = sum(
            int(analysis.migration_effort.get("estimated_hours", 0))
            for analysis in analyses
        )

        # Collect all Spark configurations
        all_spark_configurations: Dict[str, List[Dict[str, Any]]] = {}
        for analysis in analyses:
            for config_name, usages in analysis.spark_configurations.items():
                if config_name not in all_spark_configurations:
                    all_spark_configurations[config_name] = []
                all_spark_configurations[config_name].extend(usages)

        # Create notebook reports
        notebook_reports = []
        for analysis in analyses:
            notebook_reports.append({
                "path": analysis.notebook_path,
                "is_compatible": analysis.is_compatible,
                "complexity": analysis.complexity.value,
                # Total issues should exclude skipped issues for consistency
                "total_issues": sum(
                    count
                    for key, count in (analysis.issue_counts or {}).items()
                    if key != "skipped_issues"
                ),
                "issue_counts": analysis.issue_counts,
                "migration_effort": analysis.migration_effort,
            })

        # Create summary
        summary = {
            "compatibility_rate": (compatible_notebooks / total_notebooks * 100)
            if total_notebooks > 0
            else 0,
            "average_complexity": self._calculate_average_complexity(analyses),
            "most_common_issues": self._get_most_common_issues(issue_distribution),
            "total_estimated_hours": total_migration_effort,
        }

        if self.verbose and self.logger:
            self.logger.info(
                f"Consolidated report: {compatible_notebooks}/{total_notebooks} compatible"
            )

        return ConsolidatedReport(
            analysis_timestamp=analyses[0].analysis_timestamp if analyses else "",
            total_notebooks=total_notebooks,
            compatible_notebooks=compatible_notebooks,
            incompatible_notebooks=incompatible_notebooks,
            complexity_distribution=complexity_distribution,
            issue_distribution=issue_distribution,
            total_migration_effort=total_migration_effort,
            notebook_reports=notebook_reports,
            summary=summary,
            all_spark_configurations=all_spark_configurations,
            skipped_issues_total=skipped_issues_total,
        )

    def _get_notebook_content(self, path: Path) -> Optional[str]:
        """Get notebook content from file or workspace."""
        try:
            if self._is_workspace_path(str(path)):
                if self.verbose and self.logger:
                    self.logger.info(f"Reading workspace notebook: {path}")
                return self.workspace_client.read_notebook_content(str(path))
            else:
                if self.verbose and self.logger:
                    self.logger.info(f"Reading local file: {path}")
                # If local ipynb, parse via NotebookParser to extract code cells
                if path.suffix.lower() == ".ipynb":
                    parsed = self.notebook_parser.parse_notebook(path)
                    return parsed.get("content") or ""
                # Otherwise, respect size limit
                content = self.file_reader.read_file_content(
                    path, max_size=self.max_file_size
                )
                return content
        except Exception as e:
            if self.logger:
                self.logger.error(f"Error reading content from {path}: {e}")
            return None

    def _get_notebook_metadata(self, path: Path) -> Dict[str, Any]:
        """Get notebook metadata."""
        try:
            if self.workspace_client.is_workspace_path(str(path)):
                metadata = self.workspace_client.get_notebook_metadata(str(path))
                if metadata:
                    return {
                        "object_id": metadata.object_id,
                        "object_type": metadata.object_type,
                        "created_at": metadata.created_at,
                        "modified_at": metadata.modified_at,
                        "created_by": metadata.created_by,
                        "modified_by": metadata.modified_by,
                        "workspace_url": metadata.workspace_url,
                    }
        except Exception as e:
            if self.logger:
                self.logger.warning(f"Error getting workspace metadata for {path}: {e}")

        # Fallback to file metadata
        try:
            file_metadata = self.file_reader.get_file_metadata(path)
            notebook_info = self.notebook_parser.get_notebook_info(path)

            return {
                "path": file_metadata.path,
                "object_name": file_metadata.object_name,
                "parent_path": file_metadata.parent_path,
                "is_dir": file_metadata.is_dir,
                "file_extension": file_metadata.file_extension,
                "size": file_metadata.size,
                "language": notebook_info.get("language"),
                "format": notebook_info.get("format"),
                "total_lines": notebook_info.get("total_lines"),
                "non_empty_lines": notebook_info.get("non_empty_lines"),
                "imports": notebook_info.get("imports", []),
                "dependencies": notebook_info.get("dependencies", []),
            }
        except Exception as e:
            if self.logger:
                self.logger.warning(f"Error getting file metadata for {path}: {e}")
            return {}

    def _create_empty_analysis(
        self, notebook_path: str, error_message: str = "Unknown error"
    ) -> ServerlessAnalysis:
        """Create an empty analysis for failed notebooks."""
        from datetime import datetime
        from ..models.enums import ComplexityLevel

        return ServerlessAnalysis(
            notebook_path=notebook_path,
            is_compatible=False,
            complexity=ComplexityLevel.EXTREME,
            issues=[],
            required_changes=[],
            performance_impacts=[],
            recommendations=[f"Failed to analyze notebook - {error_message}"],
            code_snippets={},
            language_support={},
            api_support={},
            data_source_support={},
            streaming_support={},
            ml_support={},
            caching_support={},
            hive_support={},
            issue_counts={"analysis_error": 1},
            complexity_factors={},
            migration_effort={
                "estimated_hours": 0,
                "risk_level": "High",
                "priority": "High",
            },
            detailed_issues=[],
            analysis_timestamp=datetime.now().isoformat(),
            notebook_metadata={"error": error_message},
            spark_configurations={},
        )

    def _is_workspace_path(self, path: str) -> bool:
        """Decide whether a path should be treated as a Databricks workspace path."""
        if self.force_workspace and isinstance(path, str) and path.startswith("/"):
            return any(
                path.startswith(prefix)
                for prefix in ["/Workspace/", "/Repos/", "/Shared/", "/Users/"]
            )
        return self.workspace_client.is_workspace_path(path)

    def _create_empty_consolidated_report(self) -> ConsolidatedReport:
        """Create an empty consolidated report."""
        from datetime import datetime

        return ConsolidatedReport(
            analysis_timestamp=datetime.now().isoformat(),
            total_notebooks=0,
            compatible_notebooks=0,
            incompatible_notebooks=0,
            complexity_distribution={},
            issue_distribution={},
            total_migration_effort=0,
            notebook_reports=[],
            summary={},
            all_spark_configurations={},
        )

    def _calculate_average_complexity(self, analyses: List[ServerlessAnalysis]) -> str:
        """Calculate average complexity level."""
        if not analyses:
            return "Unknown"

        complexity_values = {"Low": 1, "Medium": 2, "High": 3, "Extreme": 4}
        total_complexity = sum(
            complexity_values.get(a.complexity.value, 0) for a in analyses
        )
        average = total_complexity / len(analyses)

        if average <= 1.5:
            return "Low"
        elif average <= 2.5:
            return "Medium"
        elif average <= 3.5:
            return "High"
        else:
            return "Extreme"

    def _get_most_common_issues(self, issue_distribution: Dict[str, int]) -> List[str]:
        """Get the most common issue types."""
        sorted_issues = sorted(
            issue_distribution.items(), key=lambda x: x[1], reverse=True
        )
        return [issue_type for issue_type, count in sorted_issues[:5] if count > 0]
