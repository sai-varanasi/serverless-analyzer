"""
Report generation service for serverless analyzer.
"""

import json
from pathlib import Path
from typing import Any, Dict, Optional, Union, List
import csv
from ..models.analysis import ConsolidatedReport, ServerlessAnalysis


class ReportService:
    """Service for generating reports from analysis results."""

    def __init__(self, logger: Optional[Any] = None) -> None:
        self.logger = logger

    def generate_json_report(
        self,
        analysis: ServerlessAnalysis,
        output_path: Optional[Union[str, Path]] = None,
    ) -> str:
        """Generate JSON report for a single analysis."""
        report_data = self._analysis_to_dict(analysis)

        if output_path:
            output_path = Path(output_path)
            with open(output_path, "w", encoding="utf-8") as f:
                json.dump(report_data, f, indent=2, ensure_ascii=False)

            if self.logger:
                self.logger.info(f"JSON report saved to: {output_path}")

        return json.dumps(report_data, indent=2, ensure_ascii=False)

    def generate_consolidated_json_report(
        self, report: ConsolidatedReport, output_path: Optional[Union[str, Path]] = None
    ) -> str:
        """Generate JSON report for consolidated analysis."""
        report_data = self._consolidated_report_to_dict(report)

        if output_path:
            output_path = Path(output_path)
            with open(output_path, "w", encoding="utf-8") as f:
                json.dump(report_data, f, indent=2, ensure_ascii=False)

            if self.logger:
                self.logger.info(f"Consolidated JSON report saved to: {output_path}")

        return json.dumps(report_data, indent=2, ensure_ascii=False)

    def generate_directory_reports(
        self,
        analyses: List[ServerlessAnalysis],
        consolidated_report: ConsolidatedReport,
        output_dir: Union[str, Path],
    ) -> None:
        """Generate both consolidated and individual reports in a directory."""
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

        # Generate consolidated report
        consolidated_path = output_dir / "consolidated_report.json"
        self.generate_consolidated_json_report(consolidated_report, consolidated_path)

        # Generate individual reports
        individual_dir = output_dir / "individual_reports"
        individual_dir.mkdir(exist_ok=True)

        for analysis in analyses:
            # Create a safe filename from the notebook path
            safe_name = self._get_safe_filename(analysis.notebook_path)
            individual_path = individual_dir / f"{safe_name}_report.json"
            self.generate_json_report(analysis, individual_path)

        if self.logger:
            self.logger.info(f"All reports saved to: {output_dir}")

    def write_query_files(
        self, queries: Dict[str, str], output_dir: Union[str, Path]
    ) -> List[Path]:
        """Write one .sql file per query under a queries subdirectory.

        Returns the list of written file paths.
        """
        output_dir = Path(output_dir)
        queries_dir = output_dir / "queries"
        queries_dir.mkdir(parents=True, exist_ok=True)

        # Stable order by friendly key name
        ordered_items = list(queries.items())

        def file_name(idx: int, key: str) -> str:
            # zero-padded index and safe key
            safe_key = "".join(c for c in key if c.isalnum() or c in "_-")
            return f"{idx:02d}_{safe_key}.sql"

        written: List[Path] = []
        for i, (key, sql) in enumerate(ordered_items, start=1):
            path = queries_dir / file_name(i, key)
            with open(path, "w", encoding="utf-8") as f:
                f.write(sql.rstrip() + "\n")
            written.append(path)

        if self.logger:
            self.logger.info(f"Wrote {len(written)} query files to: {queries_dir}")

        return written

    def generate_csv_reports(
        self,
        analyses: List[ServerlessAnalysis],
        consolidated_report: ConsolidatedReport,
        output_dir: Union[str, Path],
    ) -> Dict[str, Path]:
        """Write CSV exports for consolidated dataset summary and detailed issues.

        Returns mapping of file type to written path.
        """
        out_dir = Path(f"{output_dir}/csv")
        out_dir.mkdir(parents=True, exist_ok=True)

        # Dataset summary CSV (single row from consolidated report summary)
        ds_path = out_dir / "dataset_summary.csv"
        ds_fields = [
            "analysis_timestamp",
            "total_notebooks",
            "compatible_notebooks",
            "incompatible_notebooks",
            "total_migration_effort",
            "compatibility_rate",
            "average_complexity",
        ]
        with open(ds_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=ds_fields)
            writer.writeheader()
            writer.writerow({
                "analysis_timestamp": consolidated_report.analysis_timestamp,
                "total_notebooks": consolidated_report.total_notebooks,
                "compatible_notebooks": consolidated_report.compatible_notebooks,
                "incompatible_notebooks": consolidated_report.incompatible_notebooks,
                "total_migration_effort": consolidated_report.total_migration_effort,
                "compatibility_rate": consolidated_report.summary.get(
                    "compatibility_rate"
                ),
                "average_complexity": consolidated_report.summary.get(
                    "average_complexity"
                ),
            })

        # Build dynamic columns for expansions
        all_issue_keys: List[str] = sorted({
            k for a in analyses for k in (a.issue_counts or {}).keys()
        })

        # Detailed issues CSV (row per notebook with selected aggregates + expanded issue counts and spark config counts)
        di_path = out_dir / "notebook_detailed.csv"
        di_fields = [
            "analysis_timestamp",
            "notebook_path",
            "complexity",
            "is_compatible",
            "total_issues",
            "migration_effort_hours",
        ]
        # Expanded issue count columns
        di_fields += [f"issue_count_{k}" for k in all_issue_keys]
        # Expanded spark configuration columns removed; keep JSON blob only
        # Keep original JSON blobs for full fidelity
        di_fields += [
            "issue_counts_json",
            "detailed_issues_json",
            "notebook_metadata_json",
            "spark_configurations_json",
        ]
        with open(di_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=di_fields)
            writer.writeheader()
            for a in analyses:
                row: Dict[str, Any] = {
                    "analysis_timestamp": consolidated_report.analysis_timestamp,
                    "notebook_path": a.notebook_path,
                    "complexity": a.complexity.value,
                    "is_compatible": a.is_compatible,
                    "total_issues": sum(a.issue_counts.values())
                    if a.issue_counts
                    else 0,
                    "migration_effort_hours": (
                        a.migration_effort.get("estimated_hours", 0)
                        if isinstance(a.migration_effort, dict)
                        else a.migration_effort
                    ),
                }
                # Expanded issue counts
                for k in all_issue_keys:
                    row[f"issue_count_{k}"] = (a.issue_counts or {}).get(k, 0)
                # Spark configuration counts removed from flat columns
                # Original JSON blobs
                row["issue_counts_json"] = json.dumps(a.issue_counts or {})
                row["detailed_issues_json"] = json.dumps([
                    {
                        "type": di.type,
                        "description": di.description,
                        "line_number": di.line_number,
                        "code_snippet": di.code_snippet,
                        "severity": di.severity,
                        "impact": di.impact,
                        "recommendation": di.recommendation,
                        "affected_apis": di.affected_apis,
                        "related_issues": di.related_issues,
                    }
                    for di in (a.detailed_issues or [])
                ])
                row["notebook_metadata_json"] = json.dumps(a.notebook_metadata or {})
                row["spark_configurations_json"] = json.dumps(
                    a.spark_configurations or {}
                )
                writer.writerow(row)

        # Per-issue CSV (row per detailed issue across all notebooks)
        def _truncate_snippet(snippet: str, max_len: int = 200) -> str:
            if len(snippet) <= max_len:
                return snippet
            return snippet[: max_len - 1] + "\u2026"

        ii_path = out_dir / "issues_detailed.csv"
        ii_fields = [
            "analysis_timestamp",
            "notebook_path",
            "complexity",
            "is_compatible",
            "issue_type",
            "description",
            "line_number",
            "code_snippet",
            "severity",
            "impact",
            "recommendation",
            "affected_apis",
            "related_issues",
            "is_skipped",
            "skip_reason",
        ]
        # Expand with issue counts only (spark conf counts removed)
        ii_fields_expanded = ii_fields + [f"issue_count_{k}" for k in all_issue_keys]
        with open(ii_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=ii_fields_expanded)
            writer.writeheader()
            for a in analyses:
                if not a.detailed_issues:
                    continue
                for di in a.detailed_issues:
                    row_issue: Dict[str, Any] = {
                        "analysis_timestamp": consolidated_report.analysis_timestamp,
                        "notebook_path": a.notebook_path,
                        "complexity": a.complexity.value,
                        "is_compatible": a.is_compatible,
                        "issue_type": di.type,
                        "description": di.description,
                        "line_number": di.line_number,
                        "code_snippet": _truncate_snippet(di.code_snippet or ""),
                        "severity": di.severity,
                        "impact": di.impact,
                        "recommendation": di.recommendation,
                        "affected_apis": ", ".join(di.affected_apis)
                        if di.affected_apis
                        else "",
                        "related_issues": ", ".join(di.related_issues)
                        if di.related_issues
                        else "",
                        "is_skipped": getattr(di, "is_skipped", False),
                        "skip_reason": getattr(di, "skip_reason", "") or "",
                    }
                    for k in all_issue_keys:
                        row_issue[f"issue_count_{k}"] = (a.issue_counts or {}).get(k, 0)
                    # Spark configuration counts removed from per-issue rows
                    writer.writerow(row_issue)

        # Skipped issues CSV (optional, for programmatic filtering)
        skipped_path = out_dir / "issues_skipped.csv"
        with open(skipped_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=ii_fields)
            writer.writeheader()
            for a in analyses:
                if not a.detailed_issues:
                    continue
                for di in a.detailed_issues:
                    if not getattr(di, "is_skipped", False):
                        continue
                    writer.writerow({
                        "analysis_timestamp": consolidated_report.analysis_timestamp,
                        "notebook_path": a.notebook_path,
                        "complexity": a.complexity.value,
                        "is_compatible": a.is_compatible,
                        "issue_type": di.type,
                        "description": di.description,
                        "line_number": di.line_number,
                        "code_snippet": _truncate_snippet(di.code_snippet or ""),
                        "severity": di.severity,
                        "impact": di.impact,
                        "recommendation": di.recommendation,
                        "affected_apis": ", ".join(di.affected_apis)
                        if di.affected_apis
                        else "",
                        "related_issues": ", ".join(di.related_issues)
                        if di.related_issues
                        else "",
                        "is_skipped": True,
                        "skip_reason": getattr(di, "skip_reason", ""),
                    })

        if self.logger:
            self.logger.info(
                f"CSV reports saved: {ds_path.name}, {di_path.name}, {ii_path.name}, {skipped_path.name} under {out_dir}"
            )

        return {
            "dataset_summary": ds_path,
            "notebook_detailed": di_path,
            "issues_detailed": ii_path,
            "issues_skipped": skipped_path,
        }

    def _get_safe_filename(self, notebook_path: str) -> str:
        """Convert notebook path to a safe filename."""
        path = Path(notebook_path)
        # Get the stem (filename without extension)
        stem = path.stem
        # Replace any unsafe characters
        safe_stem = "".join(c for c in stem if c.isalnum() or c in "._-")
        return safe_stem

    def generate_summary_report(self, report: ConsolidatedReport) -> str:
        """Generate a human-readable summary report."""
        lines = []
        lines.append("=" * 80)
        lines.append("DATABRICKS SERVERLESS COMPATIBILITY ANALYSIS SUMMARY")
        lines.append("=" * 80)
        lines.append("")

        # Overview
        lines.append("OVERVIEW:")
        lines.append(f"  Total Notebooks Analyzed: {report.total_notebooks}")
        lines.append(f"  Compatible Notebooks: {report.compatible_notebooks}")
        lines.append(f"  Incompatible Notebooks: {report.incompatible_notebooks}")
        lines.append(
            f"  Compatibility Rate: {report.summary.get('compatibility_rate', 0):.1f}%"
        )
        lines.append("")

        # Complexity Distribution
        lines.append("COMPLEXITY DISTRIBUTION:")
        for complexity, count in report.complexity_distribution.items():
            lines.append(f"  {complexity}: {count} notebooks")
        lines.append("")

        # Issue Distribution
        lines.append("ISSUE DISTRIBUTION:")
        for issue_type, count in report.issue_distribution.items():
            lines.append(f"  {issue_type}: {count} issues")
        lines.append("")

        # Migration Effort
        lines.append("MIGRATION EFFORT:")
        lines.append(f"  Total Estimated Hours: {report.total_migration_effort}")
        lines.append(
            f"  Average Complexity: {report.summary.get('average_complexity', 'Unknown')}"
        )
        lines.append("")

        # Most Common Issues
        most_common = report.summary.get("most_common_issues", [])
        if most_common:
            lines.append("MOST COMMON ISSUES:")
            for i, issue in enumerate(most_common, 1):
                lines.append(f"  {i}. {issue}")
            lines.append("")

        # Notebook Details
        lines.append("NOTEBOOK DETAILS:")
        for notebook in report.notebook_reports:
            status = "✓ COMPATIBLE" if notebook["is_compatible"] else "✗ INCOMPATIBLE"
            lines.append(
                f"  {notebook['path']}: {status} ({notebook['complexity']} complexity, {notebook['total_issues']} issues)"
            )
        lines.append("")

        lines.append("=" * 80)

        return "\n".join(lines)

    def _analysis_to_dict(self, analysis: ServerlessAnalysis) -> Dict[str, Any]:
        """Convert ServerlessAnalysis to dictionary."""
        return {
            "notebook_path": analysis.notebook_path,
            "is_compatible": analysis.is_compatible,
            "complexity": analysis.complexity.value,
            "issues": analysis.issues,
            "required_changes": analysis.required_changes,
            "performance_impacts": analysis.performance_impacts,
            "recommendations": analysis.recommendations,
            "code_snippets": analysis.code_snippets,
            "language_support": analysis.language_support,
            "api_support": analysis.api_support,
            "data_source_support": analysis.data_source_support,
            "streaming_support": analysis.streaming_support,
            "ml_support": analysis.ml_support,
            "caching_support": analysis.caching_support,
            "hive_support": analysis.hive_support,
            "issue_counts": analysis.issue_counts,
            "complexity_factors": analysis.complexity_factors,
            "migration_effort": analysis.migration_effort,
            "detailed_issues": [
                {
                    "type": issue.type,
                    "description": issue.description,
                    "line_number": issue.line_number,
                    "code_snippet": issue.code_snippet,
                    "severity": issue.severity,
                    "impact": issue.impact,
                    "recommendation": issue.recommendation,
                    "affected_apis": issue.affected_apis,
                    "related_issues": issue.related_issues,
                    "is_skipped": issue.is_skipped,
                    "skip_reason": issue.skip_reason,
                }
                for issue in analysis.detailed_issues
            ],
            "analysis_timestamp": analysis.analysis_timestamp,
            "notebook_metadata": analysis.notebook_metadata,
            "spark_configurations": analysis.spark_configurations,
        }

    def _consolidated_report_to_dict(
        self, report: ConsolidatedReport
    ) -> Dict[str, Any]:
        """Convert ConsolidatedReport to dictionary."""
        return {
            "analysis_timestamp": report.analysis_timestamp,
            "total_notebooks": report.total_notebooks,
            "compatible_notebooks": report.compatible_notebooks,
            "incompatible_notebooks": report.incompatible_notebooks,
            "complexity_distribution": report.complexity_distribution,
            "issue_distribution": report.issue_distribution,
            # Skipped issues are tracked separately (not in issue_distribution)
            "skipped_issues_total": getattr(report, "skipped_issues_total", 0),
            "total_migration_effort": report.total_migration_effort,
            "notebook_reports": report.notebook_reports,
            "summary": report.summary,
            "all_spark_configurations": report.all_spark_configurations,
            "workspace_metadata": report.workspace_metadata,
            "system_table_queries": report.system_table_queries,
        }
