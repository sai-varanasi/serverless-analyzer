"""
Language-aware comment filtering utilities.
"""

from typing import List, Tuple


def filter_comments(content_lines: List[str], language: str) -> List[str]:
    language = (language or "").lower()
    filtered: List[str] = []
    in_block = False

    for line in content_lines:
        s = line.strip()
        if not s:
            filtered.append(line)
            continue

        if language == "sql":
            # Inside SQL block comment
            if in_block:
                if "*/" in s:
                    in_block = False
                    after = s.rsplit("*/", 1)[1]
                    if after.strip():
                        filtered.append(after)
                continue

            # Line comments
            if s.startswith("--"):
                continue

            # Inline block comment on same line
            if "/*" in s and "*/" in s:
                before = s.split("/*", 1)[0]
                after = s.rsplit("*/", 1)[1]
                combined = (before + after).strip()
                if combined:
                    filtered.append(before + after)
                continue

            # Start of block comment
            if "/*" in s:
                in_block = True
                before = s.split("/*", 1)[0]
                if before.strip():
                    filtered.append(before)
                continue

            # Plain SQL line
            filtered.append(line)
            continue

        # Non-SQL languages (python/scala/r)
        if in_block:
            # End of triple-quote or C-style block
            if s.endswith('"""') or s.endswith("'''") or "*/" in s:
                in_block = False
                if "*/" in s:
                    after = s.rsplit("*/", 1)[1]
                    if after.strip():
                        filtered.append(after)
            continue

        # Single-line comments
        if s.startswith("#") or s.startswith("//"):
            continue

        # Single-line triple-quoted docstring
        if (s.startswith('"""') and s.endswith('"""') and len(s) > 6) or (
            s.startswith("'''") and s.endswith("'''") and len(s) > 6
        ):
            continue

        # Start of multi-line triple-quote block
        if s.startswith('"""') or s.startswith("'''"):
            in_block = True
            continue

        # Inline C-style block comment on same line
        if "/*" in s and "*/" in s:
            before = s.split("/*", 1)[0]
            after = s.rsplit("*/", 1)[1]
            combined = (before + after).strip()
            if combined:
                filtered.append(before + after)
            continue

        # Start of C-style block comment
        if "/*" in s:
            in_block = True
            before = s.split("/*", 1)[0]
            if before.strip():
                filtered.append(before)
            continue

        # Plain code line
        filtered.append(line)

    return filtered


def filter_comments_with_mapping(
    content_lines: List[str], language: str
) -> Tuple[List[str], List[int]]:
    """Filter comments like filter_comments, but also return a mapping from
    filtered line indices to original line numbers (1-based).

    The mapping preserves the original line number for any emitted line,
    even if the content was altered to remove inline comments.
    """
    language = (language or "").lower()
    filtered: List[str] = []
    line_number_map: List[int] = []
    in_block = False

    for idx, line in enumerate(content_lines, start=1):
        s = line.strip()
        if not s:
            filtered.append(line)
            line_number_map.append(idx)
            continue

        if language == "sql":
            # Inside SQL block comment
            if in_block:
                if "*/" in s:
                    in_block = False
                    after = s.rsplit("*/", 1)[1]
                    if after.strip():
                        filtered.append(after)
                        line_number_map.append(idx)
                continue

            # Line comments
            if s.startswith("--"):
                continue

            # Inline block comment on same line
            if "/*" in s and "*/" in s:
                before = s.split("/*", 1)[0]
                after = s.rsplit("*/", 1)[1]
                combined = (before + after).strip()
                if combined:
                    filtered.append(before + after)
                    line_number_map.append(idx)
                continue

            # Start of block comment
            if "/*" in s:
                in_block = True
                before = s.split("/*", 1)[0]
                if before.strip():
                    filtered.append(before)
                    line_number_map.append(idx)
                continue

            # Plain SQL line
            filtered.append(line)
            line_number_map.append(idx)
            continue

        # Non-SQL languages (python/scala/r)
        if in_block:
            # End of triple-quote or C-style block
            if s.endswith('"""') or s.endswith("'''") or "*/" in s:
                in_block = False
                if "*/" in s:
                    after = s.rsplit("*/", 1)[1]
                    if after.strip():
                        filtered.append(after)
                        line_number_map.append(idx)
            continue

        # Single-line comments
        if s.startswith("#") or s.startswith("//"):
            continue

        # Single-line triple-quoted docstring
        if (s.startswith('"""') and s.endswith('"""') and len(s) > 6) or (
            s.startswith("'''") and s.endswith("'''") and len(s) > 6
        ):
            continue

        # Start of multi-line triple-quote block
        if s.startswith('"""') or s.startswith("'''"):
            in_block = True
            continue

        # Inline C-style block comment on same line
        if "/*" in s and "*/" in s:
            before = s.split("/*", 1)[0]
            after = s.rsplit("*/", 1)[1]
            combined = (before + after).strip()
            if combined:
                filtered.append(before + after)
                line_number_map.append(idx)
            continue

        # Start of C-style block comment
        if "/*" in s:
            in_block = True
            before = s.split("/*", 1)[0]
            if before.strip():
                filtered.append(before)
                line_number_map.append(idx)
            continue

        # Plain code line
        filtered.append(line)
        line_number_map.append(idx)

    return filtered, line_number_map
