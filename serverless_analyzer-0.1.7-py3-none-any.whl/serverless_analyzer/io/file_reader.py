"""
File reading operations for serverless analyzer.
"""

from pathlib import Path
from typing import Optional, Union, List
from ..models.metadata import WorkspaceMetadata


class FileReader:
    """Handles file reading operations for notebooks and files."""

    def __init__(self) -> None:
        pass

    def is_databricks_path(self, path: str) -> bool:
        """Check if a path is a Databricks workspace path."""
        return (
            isinstance(path, str)
            and path.startswith("/")
            and any(
                path.startswith(prefix)
                for prefix in ["/Workspace/", "/Repos/", "/Shared/"]
            )
        )

    def safe_is_file(self, path: Union[str, Path]) -> bool:
        """Safely check if a path is a file, handling remote paths."""
        path_str = str(path) if isinstance(path, Path) else path
        if self.is_databricks_path(path_str):
            return not path_str.endswith("/")
        try:
            p = Path(path)
            if p.exists():
                return p.is_file()
            return bool(p.suffix)
        except Exception:
            return False

    def safe_get_file_size(self, path: Union[str, Path]) -> int:
        """Safely get file size, handling remote paths."""
        path_str = str(path) if isinstance(path, Path) else path
        if self.is_databricks_path(path_str):
            return 0
        try:
            return Path(path).stat().st_size
        except Exception:
            return 0

    def read_file_content(
        self, file_path: Union[str, Path], max_size: int = 10 * 1024 * 1024
    ) -> Optional[str]:
        """Read file content safely.

        max_size: maximum allowed size in bytes; returns None if exceeded.
        """
        try:
            path = Path(file_path)
            if not path.exists():
                return None

            # Check file size to avoid reading very large files
            file_size = path.stat().st_size
            if file_size > max_size:
                return None

            with open(path, "r", encoding="utf-8") as f:
                return f.read()
        except Exception:
            return None

    def get_file_metadata(self, file_path: Union[str, Path]) -> WorkspaceMetadata:
        """Get metadata for a file."""
        path = Path(file_path)

        return WorkspaceMetadata(
            path=str(path),
            object_name=path.name,
            parent_path=str(path.parent),
            is_dir=path.is_dir(),
            file_extension=path.suffix,
            size=self.safe_get_file_size(path) if path.is_file() else 0,
        )

    def list_directory(self, dir_path: Union[str, Path]) -> List[Path]:
        """List files in a directory."""
        try:
            path = Path(dir_path)
            if not path.is_dir():
                return []

            return [item for item in path.iterdir()]
        except Exception:
            return []

    def find_notebook_files(self, root_path: Union[str, Path]) -> List[Path]:
        """Find all notebook files in a directory tree."""
        notebook_extensions = {".py", ".sql", ".scala", ".r", ".ipynb"}
        notebook_files: List[Path] = []

        try:
            root = Path(root_path)
            if not root.exists():
                return notebook_files

            if root.is_file():
                if root.suffix.lower() in notebook_extensions:
                    return [root]
                return notebook_files

            # Recursively find notebook files
            for item in root.rglob("*"):
                if item.is_file() and item.suffix.lower() in notebook_extensions:
                    notebook_files.append(item)

            return notebook_files
        except Exception:
            return notebook_files
