"""
Notebook parsing utilities for serverless analyzer.
"""

import json
import re
from pathlib import Path
from typing import Any, Dict, List, Union

from .file_reader import FileReader


class NotebookParser:
    """Handles parsing of different notebook formats."""

    def __init__(self) -> None:
        self.file_reader = FileReader()

    def parse_notebook(self, file_path: Union[str, Path]) -> Dict[str, Any]:
        """Parse a notebook file and extract content."""
        path = Path(file_path)

        if path.suffix.lower() == ".ipynb":
            return self._parse_jupyter_notebook(path)
        else:
            return self._parse_plain_notebook(path)

    def _parse_jupyter_notebook(self, file_path: Path) -> Dict[str, Any]:
        """Parse Jupyter notebook format."""
        try:
            content = self.file_reader.read_file_content(file_path)
            if not content:
                return {"cells": [], "metadata": {}, "content": ""}

            notebook_data = json.loads(content)

            # Extract code from all cells
            code_cells = []
            for cell in notebook_data.get("cells", []):
                if cell.get("cell_type") == "code":
                    source = cell.get("source", [])
                    if isinstance(source, list):
                        code_cells.extend(source)
                    else:
                        code_cells.append(source)

            return {
                "cells": notebook_data.get("cells", []),
                "metadata": notebook_data.get("metadata", {}),
                "content": "".join(code_cells),
                "format": "jupyter",
            }
        except Exception:
            return {"cells": [], "metadata": {}, "content": "", "format": "jupyter"}

    def _parse_plain_notebook(self, file_path: Path) -> Dict[str, Any]:
        """Parse plain text notebook (Python, SQL, Scala, R)."""
        try:
            content = self.file_reader.read_file_content(file_path)
            if not content:
                return {"content": "", "format": "plain"}

            return {
                "content": content,
                "format": "plain",
                "language": self._detect_language_from_extension(file_path),
            }
        except Exception:
            return {"content": "", "format": "plain"}

    def _detect_language_from_extension(self, file_path: Path) -> str:
        """Detect language from file extension."""
        extension_map = {
            ".py": "python",
            ".sql": "sql",
            ".scala": "scala",
            ".r": "r",
        }
        return extension_map.get(file_path.suffix.lower(), "python")

    def extract_imports(self, content: str) -> List[str]:
        """Extract imported module names from Python code, not full lines.

        - Handles "from pkg.subpkg import X" -> ["pkg.subpkg"]
        - Handles "import a, b" -> ["a", "b"]
        - Avoids matching SQL "FROM" clauses by anchoring to line start with Python syntax.
        """
        modules: List[str] = []
        seen = set()
        lines = content.splitlines()

        # Capture either 'from X import' or 'import A, B' at start of line
        import_stmt = re.compile(
            r"^(?:from\s+([A-Za-z_][\w\.]*)\s+import\b|import\s+([A-Za-z_][\w\.]*\s*(?:,\s*[A-Za-z_][\w\.]*)*))"
        )

        for line in lines:
            s = line.strip()
            m = import_stmt.match(s)
            if not m:
                continue

            from_mod = m.group(1)
            import_list = m.group(2)

            if from_mod:
                if from_mod not in seen:
                    seen.add(from_mod)
                    modules.append(from_mod)
            elif import_list:
                for part in import_list.split(","):
                    mod = part.strip()
                    if mod and mod not in seen:
                        seen.add(mod)
                        modules.append(mod)

        return modules

    def extract_dependencies(self, content: str) -> List[str]:
        """Extract dependency statements from content."""
        dependencies = []
        lines = content.splitlines()

        for line in lines:
            line = line.strip()
            if line.startswith("pip install") or line.startswith("%pip install"):
                dependencies.append(line)

        return dependencies

    def get_notebook_info(self, file_path: Union[str, Path]) -> Dict[str, Any]:
        """Get comprehensive notebook information."""
        path = Path(file_path)
        parsed = self.parse_notebook(path)

        return {
            "path": str(path),
            "name": path.name,
            "extension": path.suffix,
            "language": parsed.get(
                "language", self._detect_language_from_extension(path)
            ),
            "format": parsed.get("format", "plain"),
            "content": parsed.get("content", ""),
            "imports": self.extract_imports(parsed.get("content", "")),
            "dependencies": self.extract_dependencies(parsed.get("content", "")),
            "total_lines": len(parsed.get("content", "").splitlines()),
            "non_empty_lines": len([
                line for line in parsed.get("content", "").splitlines() if line.strip()
            ]),
        }
