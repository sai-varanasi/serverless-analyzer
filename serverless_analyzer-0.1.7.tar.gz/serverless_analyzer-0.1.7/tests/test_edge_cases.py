#!/usr/bin/env python3
"""
Tests for Edgecases and Cornercases scenarios:
1) Language detection should accept `%run` as Python.
2) SQL FROM clauses should not be treated as imports.
3) Overlapping pattern matches should not be double-counted in issue counts while all detailed issues remain.
"""

import os
import sys
import tempfile
import unittest

# Ensure package import from project root
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from serverless_analyzer.core.language_detector import LanguageDetector
from serverless_analyzer.io.notebook_parser import NotebookParser
from serverless_analyzer.services.analysis_service import AnalysisService
from serverless_analyzer.models.enums import ComplexityLevel


class TestRunMagicLanguageDetection(unittest.TestCase):
    def test_percent_run_detects_python(self):
        content = "%run ./some/other_notebook\nprint('ok')\n"
        detector = LanguageDetector()
        detected = detector.detect_language_from_content(content, "test.py")
        self.assertEqual(detected, "python")


class TestSqlFromNotImports(unittest.TestCase):
    def test_sql_from_not_treated_as_import(self):
        parser = NotebookParser()
        # Mixed content with Python import and SQL FROM
        content = (
            "import os\n"
            "from math import sqrt\n"
            "%sql\n"
            "select * from abcd -- this is a table, not an import\n"
            "select count(1) FROM schema.table_name\n"
        )

        modules = parser.extract_imports(content)
        # Ensure only module names are captured
        self.assertIn("os", modules)
        self.assertIn("math", modules)
        # Ensure no SQL FROM lines or table names are captured as imports
        self.assertNotIn("abcd", modules)
        self.assertNotIn("schema.table_name", modules)


class TestOverlappingPatternDedup(unittest.TestCase):
    def test_overlapping_patterns_count_once(self):
        service = AnalysisService(verbose=False)
        # Line includes both a caching API and a performance concern pattern (cache)
        content = (
            "# Databricks notebook source\n"
            "%python\n"
            "df = spark.range(10)\n"
            "df.cache().collect()\n"  # triggers Unsupported Caching and Performance Concern on same line
        )

        # Write to a temp file to go through the normal service path
        with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as tmp:
            tmp.write(content)
            tmp_path = tmp.name

        try:
            analysis = service.analyze_notebook(tmp_path)

            # All detailed issues should be present (at least two on same line)
            types_on_line = [
                (iss.type, iss.line_number) for iss in analysis.detailed_issues
            ]
            # Depending on comment filtering and line indexing, the line number can be 3 or 4
            self.assertTrue(
                ("Unsupported Caching", 3) in types_on_line
                or ("Unsupported Caching", 4) in types_on_line
            )
            self.assertTrue(
                ("Performance Concern", 3) in types_on_line
                or ("Performance Concern", 4) in types_on_line
            )

            # But the counts per category should not double-count the same line
            # caching_issues and performance_issues should both be 1
            self.assertEqual(analysis.issue_counts.get("caching_issues", 0), 1)
            self.assertEqual(analysis.issue_counts.get("performance_issues", 0), 1)

            # Total unique-issue lines should be 1 for these categories; overall may include others
            self.assertIn(
                analysis.complexity,
                {
                    ComplexityLevel.LOW,
                    ComplexityLevel.MEDIUM,
                    ComplexityLevel.HIGH,
                    ComplexityLevel.EXTREME,
                },
            )
        finally:
            os.unlink(tmp_path)


class TestContextualRecommendations(unittest.TestCase):
    def test_contextual_recommendations(self):
        service = AnalysisService(verbose=False)

        content = (
            "# Databricks notebook source\n"
            "%python\n"
            "# Trigger only caching and performance and an unsupported API\n"
            "rdd = sc.parallelize([1,2,3])\n"  # Unsupported API (rdd)
            "df = spark.range(10)\n"
            "df.cache().collect()\n"  # Caching + Performance
        )

        with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as tmp:
            tmp.write(content)
            tmp_path = tmp.name

        try:
            analysis = service.analyze_notebook(tmp_path)

            self.assertFalse(analysis.is_compatible)

            recs = analysis.recommendations
            self.assertIn(
                "Replace unsupported APIs with Spark Connect alternatives", recs
            )
            self.assertIn("Implement alternative caching strategies", recs)
            self.assertIn("Review and optimize performance-heavy operations", recs)

            self.assertNotIn("Migrate from Hive SerDe tables and variables", recs)
            self.assertNotIn("Use Trigger.AvailableNow for streaming", recs)
        finally:
            os.unlink(tmp_path)


class TestRefreshTableUnsupportedApi(unittest.TestCase):
    def test_refresh_table_detected_in_sql_cell(self):
        service = AnalysisService(verbose=False)

        content = (
            "-- Databricks notebook source\n%sql\nREFRESH TABLE my_schema.my_table\n"
        )

        with tempfile.NamedTemporaryFile(mode="w", suffix=".sql", delete=False) as tmp:
            tmp.write(content)
            tmp_path = tmp.name

        try:
            analysis = service.analyze_notebook(tmp_path)
            # Look for Unsupported SQL API with affected_apis == ["refresh_table"]
            found_api = [
                iss
                for iss in analysis.detailed_issues
                if iss.type == "Unsupported SQL API"
                and (iss.affected_apis or [None])[0] == "refresh_table"
            ]
            self.assertTrue(
                found_api, "REFRESH TABLE should be flagged as Unsupported SQL API"
            )
        finally:
            os.unlink(tmp_path)

    def test_refresh_table_detected_in_python_spark_sql(self):
        service = AnalysisService(verbose=False)

        content = (
            "# Databricks notebook source\n"
            "%python\n"
            'spark.sql("REFRESH TABLE some_db.some_table")\n'
        )

        with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as tmp:
            tmp.write(content)
            tmp_path = tmp.name

        try:
            analysis = service.analyze_notebook(tmp_path)
            found_api = [
                iss
                for iss in analysis.detailed_issues
                if iss.type == "Unsupported SQL API"
                and (iss.affected_apis or [None])[0] == "refresh_table"
            ]
            self.assertTrue(
                found_api,
                "REFRESH TABLE in spark.sql should be flagged as Unsupported SQL API",
            )
        finally:
            os.unlink(tmp_path)


if __name__ == "__main__":
    unittest.main()
