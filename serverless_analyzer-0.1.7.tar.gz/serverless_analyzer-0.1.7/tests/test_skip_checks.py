"""
Tests for skip-checks functionality.
"""

from serverless_analyzer.config.skip_config import SkipConfig
from serverless_analyzer.core.analyzer import CompatibilityAnalyzer


class TestSkipConfig:
    """Test the SkipConfig class."""

    def test_skip_config_initialization(self):
        """Test SkipConfig initialization."""
        skip_config = SkipConfig(["performance_concerns", "driver_actions"])
        assert "performance_concerns" in skip_config.skip_categories
        assert "driver_actions" in skip_config.skip_sub_patterns

    def test_should_skip_category(self):
        """Test skipping entire category."""
        skip_config = SkipConfig(["performance_concerns"])
        assert skip_config.should_skip("performance_concerns")
        assert skip_config.should_skip("performance_concerns", "driver_actions")
        assert not skip_config.should_skip("unsupported_apis")

    def test_should_skip_sub_pattern(self):
        """Test skipping specific sub-pattern."""
        skip_config = SkipConfig(["driver_actions"])
        assert skip_config.should_skip("performance_concerns", "driver_actions")
        assert not skip_config.should_skip("performance_concerns", "large_operations")
        assert not skip_config.should_skip("performance_concerns")

    def test_get_skip_reason(self):
        """Test getting skip reason."""
        skip_config = SkipConfig(["performance_concerns", "driver_actions"])
        reason_category = skip_config.get_skip_reason("performance_concerns")
        assert "performance_concerns" in reason_category
        assert "skipped by user" in reason_category.lower()

        reason_pattern = skip_config.get_skip_reason(
            "performance_concerns", "driver_actions"
        )
        assert "driver_actions" in reason_pattern
        assert "skipped by user" in reason_pattern.lower()

    def test_validate_valid_checks(self):
        """Test validation with valid check names."""
        skip_config = SkipConfig(["performance_concerns", "driver_actions"])
        errors = skip_config.validate()
        assert len(errors) == 0

    def test_validate_invalid_checks(self):
        """Test validation with invalid check names."""
        skip_config = SkipConfig(["invalid_check", "another_invalid"])
        errors = skip_config.validate()
        assert len(errors) == 2
        assert "invalid_check" in errors[0]
        assert "another_invalid" in errors[1]

    def test_list_available_checks(self):
        """Test listing available checks."""
        available = SkipConfig.list_available_checks()
        assert "performance_concerns" in available
        assert "unsupported_apis" in available
        assert isinstance(available["performance_concerns"], list)

    def test_get_help_text(self):
        """Test help text generation."""
        help_text = SkipConfig.get_help_text()
        assert "performance_concerns" in help_text
        assert "driver_actions" in help_text
        assert "Examples:" in help_text


class TestAnalyzerWithSkipChecks:
    """Test the analyzer with skip-checks functionality."""

    def test_analyzer_without_skip_checks(self):
        """Test analyzer without skip checks."""
        analyzer = CompatibilityAnalyzer()

        # Notebook with performance issues
        content = """
df.collect()
df.toPandas()
"""

        result = analyzer.analyze_notebook_from_content(content, "test.py")

        # Should have performance issues
        performance_issues = [
            issue
            for issue in result.detailed_issues
            if issue.type == "Performance Concern"
        ]
        assert len(performance_issues) > 0
        assert all(not issue.is_skipped for issue in performance_issues)

    def test_analyzer_with_skip_category(self):
        """Test analyzer with skip checks for entire category."""
        analyzer = CompatibilityAnalyzer(skip_checks=["performance_concerns"])

        # Notebook with performance issues
        content = """
df.collect()
df.toPandas()
"""

        result = analyzer.analyze_notebook_from_content(content, "test.py")

        # Should have performance issues but all skipped
        performance_issues = [
            issue
            for issue in result.detailed_issues
            if issue.type == "Performance Concern"
        ]
        assert len(performance_issues) > 0
        assert all(issue.is_skipped for issue in performance_issues)
        assert all(issue.skip_reason for issue in performance_issues)

        # Should be compatible since skipped issues don't count
        assert result.is_compatible

    def test_analyzer_with_skip_sub_pattern(self):
        """Test analyzer with skip checks for specific sub-pattern."""
        analyzer = CompatibilityAnalyzer(skip_checks=["driver_actions"])

        # Notebook with different performance issues
        content = """
df.collect()
df.toPandas()
"""

        result = analyzer.analyze_notebook_from_content(content, "test.py")

        # collect() should be skipped, toPandas() should not
        collect_issues = [
            issue
            for issue in result.detailed_issues
            if "collect" in issue.code_snippet.lower()
        ]
        topandas_issues = [
            issue
            for issue in result.detailed_issues
            if "topandas" in issue.code_snippet.lower()
        ]

        if collect_issues:
            assert all(issue.is_skipped for issue in collect_issues)
        if topandas_issues:
            assert all(not issue.is_skipped for issue in topandas_issues)

    def test_skipped_issues_count(self):
        """Test that skipped issues are counted separately."""
        analyzer = CompatibilityAnalyzer(skip_checks=["performance_concerns"])

        content = """
df.collect()
df.toPandas()
"""

        result = analyzer.analyze_notebook_from_content(content, "test.py")

        # Check that skipped_issues count is tracked
        assert "skipped_issues" in result.issue_counts
        assert result.issue_counts["skipped_issues"] > 0

    def test_mixed_skip_checks(self):
        """Test analyzer with mix of category and sub-pattern skips."""
        analyzer = CompatibilityAnalyzer(skip_checks=["performance_concerns", "rdd"])

        content = """
df.collect()
rdd = sc.parallelize([1, 2, 3])
"""

        result = analyzer.analyze_notebook_from_content(content, "test.py")

        # Both performance and RDD issues should be skipped
        skipped = [issue for issue in result.detailed_issues if issue.is_skipped]
        assert len(skipped) > 0
