#!/usr/bin/env python3
"""
Test the modularized services layer.
"""

import unittest
import tempfile
import os
import sys
from pathlib import Path

# Add the parent directory to the path to import the module
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from serverless_analyzer.services.analysis_service import AnalysisService
from serverless_analyzer.services.report_service import ReportService
from serverless_analyzer.services.workspace_service import WorkspaceService
from serverless_analyzer.models.enums import ComplexityLevel


class TestAnalysisService(unittest.TestCase):
    """Test the AnalysisService."""

    def setUp(self):
        """Set up test fixtures."""
        self.service = AnalysisService(scala_as_jar=False, verbose=False)

    def test_service_initialization(self):
        """Test service initialization."""
        self.assertIsNotNone(self.service.analyzer)
        self.assertIsNotNone(self.service.file_reader)
        self.assertIsNotNone(self.service.notebook_parser)
        self.assertIsNotNone(self.service.workspace_client)
        self.assertFalse(self.service.analyzer.scala_as_jar)
        self.assertFalse(self.service.verbose)

    def test_analyze_simple_python(self):
        """Test analyzing simple Python code."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as tmp:
            tmp.write("""
# Databricks notebook source
%python
import pyspark.sql.functions as F

df = spark.read.table("test_table")
df.show()
""")
            tmp_path = tmp.name

        try:
            analysis = self.service.analyze_notebook(tmp_path)

            self.assertEqual(analysis.notebook_path, tmp_path)
            self.assertTrue(analysis.is_compatible)
            self.assertEqual(analysis.complexity, ComplexityLevel.LOW)
            self.assertEqual(analysis.notebook_metadata["language"], "python")
        finally:
            os.unlink(tmp_path)

    def test_analyze_unsupported_features(self):
        """Test analyzing code with unsupported features."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as tmp:
            tmp.write("""
# Databricks notebook source
%python
import pyspark.sql.functions as F

# Unsupported RDD API
rdd = sc.parallelize([1, 2, 3])
df = rdd.toDF()

# Unsupported caching
df.cache()

# Unsupported global temp view
df.createGlobalTempView("global_temp")
""")
            tmp_path = tmp.name

        try:
            analysis = self.service.analyze_notebook(tmp_path)

            self.assertFalse(analysis.is_compatible)
            self.assertGreater(sum(analysis.issue_counts.values()), 0)
            self.assertGreater(analysis.issue_counts["api_issues"], 0)
            self.assertGreater(analysis.issue_counts["caching_issues"], 0)
        finally:
            os.unlink(tmp_path)

    def test_analyze_multiple_notebooks(self):
        """Test analyzing multiple notebooks."""
        with (
            tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as tmp1,
            tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as tmp2,
        ):
            tmp1.write("print('Hello World')")
            tmp2.write("rdd = sc.parallelize([1, 2, 3])")

            tmp1_path = tmp1.name
            tmp2_path = tmp2.name

        try:
            analyses = self.service.analyze_multiple_notebooks([tmp1_path, tmp2_path])

            self.assertEqual(len(analyses), 2)
            self.assertTrue(analyses[0].is_compatible)
            self.assertFalse(analyses[1].is_compatible)
        finally:
            os.unlink(tmp1_path)
            os.unlink(tmp2_path)

    def test_create_consolidated_report(self):
        """Test creating consolidated report."""
        # Create mock analyses
        from serverless_analyzer.models.analysis import ServerlessAnalysis
        from datetime import datetime

        analysis1 = ServerlessAnalysis(
            notebook_path="test1.py",
            is_compatible=True,
            complexity=ComplexityLevel.LOW,
            issues=[],
            required_changes=[],
            performance_impacts=[],
            recommendations=[],
            code_snippets={},
            language_support={},
            api_support={},
            data_source_support={},
            streaming_support={},
            ml_support={},
            caching_support={},
            hive_support={},
            issue_counts={},
            complexity_factors={},
            migration_effort={"estimated_hours": 1},
            detailed_issues=[],
            analysis_timestamp=datetime.now().isoformat(),
            notebook_metadata={},
            spark_configurations={},
        )

        analysis2 = ServerlessAnalysis(
            notebook_path="test2.py",
            is_compatible=False,
            complexity=ComplexityLevel.HIGH,
            issues=[],
            required_changes=[],
            performance_impacts=[],
            recommendations=[],
            code_snippets={},
            language_support={},
            api_support={},
            data_source_support={},
            streaming_support={},
            ml_support={},
            caching_support={},
            hive_support={},
            issue_counts={"api_issues": 2},
            complexity_factors={},
            migration_effort={"estimated_hours": 4},
            detailed_issues=[],
            analysis_timestamp=datetime.now().isoformat(),
            notebook_metadata={},
            spark_configurations={},
        )

        report = self.service.create_consolidated_report([analysis1, analysis2])

        self.assertEqual(report.total_notebooks, 2)
        self.assertEqual(report.compatible_notebooks, 1)
        self.assertEqual(report.incompatible_notebooks, 1)
        self.assertEqual(report.total_migration_effort, 5)
        self.assertEqual(report.complexity_distribution["Low"], 1)
        self.assertEqual(report.complexity_distribution["High"], 1)


class TestReportService(unittest.TestCase):
    """Test the ReportService."""

    def setUp(self):
        """Set up test fixtures."""
        self.service = ReportService()

    def test_service_initialization(self):
        """Test service initialization."""
        self.assertIsNotNone(self.service)

    def test_generate_summary_report(self):
        """Test generating summary report."""
        from serverless_analyzer.models.analysis import ConsolidatedReport
        from datetime import datetime

        report = ConsolidatedReport(
            analysis_timestamp=datetime.now().isoformat(),
            total_notebooks=2,
            compatible_notebooks=1,
            incompatible_notebooks=1,
            complexity_distribution={"Low": 1, "High": 1},
            issue_distribution={"api_issues": 2},
            total_migration_effort=5,
            notebook_reports=[
                {
                    "path": "test1.py",
                    "is_compatible": True,
                    "complexity": "Low",
                    "total_issues": 0,
                },
                {
                    "path": "test2.py",
                    "is_compatible": False,
                    "complexity": "High",
                    "total_issues": 2,
                },
            ],
            summary={"compatibility_rate": 50.0, "average_complexity": "Medium"},
            all_spark_configurations={},
        )

        summary = self.service.generate_summary_report(report)

        self.assertIn("DATABRICKS SERVERLESS COMPATIBILITY ANALYSIS SUMMARY", summary)
        self.assertIn("Total Notebooks Analyzed: 2", summary)
        self.assertIn("Compatible Notebooks: 1", summary)
        self.assertIn("Incompatible Notebooks: 1", summary)
        self.assertIn("Compatibility Rate: 50.0%", summary)


class TestWorkspaceService(unittest.TestCase):
    """Test the WorkspaceService."""

    def setUp(self):
        """Set up test fixtures."""
        self.service = WorkspaceService()

    def test_service_initialization(self):
        """Test service initialization."""
        self.assertIsNotNone(self.service.workspace_client)
        self.assertIsNotNone(self.service.file_reader)

    def test_get_workspace_metadata(self):
        """Test getting workspace metadata."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as tmp:
            tmp.write("print('Hello')")
            tmp_path = tmp.name

        try:
            metadata = self.service.get_workspace_metadata([tmp_path])

            self.assertIn(tmp_path, metadata)
            self.assertEqual(metadata[tmp_path].path, tmp_path)
            self.assertEqual(metadata[tmp_path].object_name, Path(tmp_path).name)
        finally:
            os.unlink(tmp_path)

    def test_validate_workspace_access(self):
        """Test workspace access validation."""
        # Test with non-workspace path
        result = self.service.validate_workspace_access("/tmp/test")
        self.assertFalse(result)

        # Test with workspace path (should return False since we're not in Databricks)
        result = self.service.validate_workspace_access("/Workspace/test")
        # This might return True or False depending on the implementation
        self.assertIsInstance(result, bool)


if __name__ == "__main__":
    unittest.main()
