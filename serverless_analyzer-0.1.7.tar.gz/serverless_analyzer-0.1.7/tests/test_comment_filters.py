import unittest
from serverless_analyzer.core.comment_filters import filter_comments


class TestCommentFilters(unittest.TestCase):
    def test_python_comments(self):
        lines = [
            "# comment",
            "x = 1",
            '"""doc"""',
            "y = 2",
        ]
        out = filter_comments(lines, "python")
        assert out == ["x = 1", "y = 2"]

    def test_sql_comments(self):
        lines = [
            "-- comment",
            "SELECT 1",
            "/* block */",
            "WHERE x = 1",
        ]
        out = filter_comments(lines, "sql")
        assert out == ["SELECT 1", "WHERE x = 1"]
