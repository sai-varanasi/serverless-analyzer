#!/usr/bin/env python3
"""
Test the modularized CLI layer.
"""

import unittest
import os
import sys

# Add the parent directory to the path to import the module
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from serverless_analyzer.cli.argument_parser import ArgumentParser
from serverless_analyzer.cli.output_formatter import OutputFormatter
from serverless_analyzer.models.analysis import ServerlessAnalysis, ConsolidatedReport
from serverless_analyzer.models.enums import ComplexityLevel
from datetime import datetime


class TestArgumentParser(unittest.TestCase):
    """Test the ArgumentParser."""

    def setUp(self):
        """Set up test fixtures."""
        self.parser = ArgumentParser()

    def test_parser_initialization(self):
        """Test parser initialization."""
        self.assertIsNotNone(self.parser.parser)

    def test_parse_basic_args(self):
        """Test parsing basic arguments."""
        args = self.parser.parse_args(["test.py"])

        self.assertEqual(args.notebook_path, "test.py")
        self.assertFalse(args.verbose)
        self.assertFalse(args.databricks)
        self.assertFalse(args.generate_queries)
        self.assertFalse(args.scala_as_jar)
        # format is deprecated; still present but default should be json
        self.assertEqual(args.format, "json")
        # new export flag defaults to None
        self.assertIsNone(getattr(args, "export"))

    def test_parse_all_args(self):
        """Test parsing all arguments."""
        args = self.parser.parse_args([
            "test.py",
            "--output",
            "report.json",
            "--verbose",
            "--databricks",
            "--generate-queries",
            "--scala-as-jar",
            "--format",
            "summary",
            "--include-metadata",
            "--max-file-size",
            "5242880",
            "--recursive",
        ])

        self.assertEqual(args.notebook_path, "test.py")
        self.assertEqual(args.output, "report.json")
        self.assertTrue(args.verbose)
        self.assertTrue(args.databricks)
        self.assertTrue(args.generate_queries)
        self.assertTrue(args.scala_as_jar)
        self.assertEqual(args.format, "summary")
        self.assertIsNone(getattr(args, "export"))
        self.assertTrue(args.include_metadata)
        self.assertEqual(args.max_file_size, 5242880)
        self.assertTrue(args.recursive)

    def test_validate_args(self):
        """Test argument validation."""
        # Valid args
        args = self.parser.parse_args(["test.py"])
        errors = self.parser.validate_args(args)
        self.assertEqual(len(errors), 0)

        # Invalid max file size
        args = self.parser.parse_args(["test.py", "--max-file-size", "0"])
        errors = self.parser.validate_args(args)
        self.assertGreater(len(errors), 0)
        self.assertIn("Maximum file size must be positive", errors[0])

    def test_print_help(self):
        """Test help message generation."""
        help_text = self.parser.print_help()
        self.assertIn("serverless-analyze", help_text)
        self.assertIn("Analyze Databricks notebooks", help_text)
        self.assertIn("--scala-as-jar", help_text)


class TestOutputFormatter(unittest.TestCase):
    """Test the OutputFormatter."""

    def setUp(self):
        """Set up test fixtures."""
        self.formatter = OutputFormatter(verbose=False)
        self.verbose_formatter = OutputFormatter(verbose=True)

    def test_formatter_initialization(self):
        """Test formatter initialization."""
        self.assertFalse(self.formatter.verbose)
        self.assertTrue(self.verbose_formatter.verbose)

    def test_format_analysis_result(self):
        """Test formatting analysis result."""
        analysis = ServerlessAnalysis(
            notebook_path="test.py",
            is_compatible=True,
            complexity=ComplexityLevel.LOW,
            issues=[],
            required_changes=[],
            performance_impacts=[],
            recommendations=["Test recommendation"],
            code_snippets={},
            language_support={},
            api_support={},
            data_source_support={},
            streaming_support={},
            ml_support={},
            caching_support={},
            hive_support={},
            issue_counts={},
            complexity_factors={},
            migration_effort={"estimated_hours": 2},
            detailed_issues=[],
            analysis_timestamp=datetime.now().isoformat(),
            notebook_metadata={},
            spark_configurations={},
        )

        result = self.formatter.format_analysis_result(analysis)

        self.assertIn("All Done!!", result)
        # self.assertIn("Analysis Results for: test.py", result)
        # self.assertIn("✓ COMPATIBLE", result)
        # self.assertIn("Complexity: Low", result)
        # self.assertIn("Test recommendation", result)
        # self.assertIn("estimated_hours: 2", result)

    def test_format_consolidated_result(self):
        """Test formatting consolidated result."""
        report = ConsolidatedReport(
            analysis_timestamp=datetime.now().isoformat(),
            total_notebooks=2,
            compatible_notebooks=1,
            incompatible_notebooks=1,
            complexity_distribution={"Low": 1, "High": 1},
            issue_distribution={"api_issues": 2},
            total_migration_effort=5,
            notebook_reports=[
                {
                    "path": "test1.py",
                    "is_compatible": True,
                    "complexity": "Low",
                    "total_issues": 0,
                },
                {
                    "path": "test2.py",
                    "is_compatible": False,
                    "complexity": "High",
                    "total_issues": 2,
                },
            ],
            summary={"compatibility_rate": 50.0},
            all_spark_configurations={},
        )

        result = self.formatter.format_consolidated_result(report)

        self.assertIn("All Done!!", result)
        # self.assertIn("Consolidated Analysis Report", result)
        # self.assertIn("Total Notebooks: 2", result)
        # self.assertIn("Compatible Notebooks: 1", result)
        # self.assertIn("Incompatible Notebooks: 1", result)
        # self.assertIn("Compatibility Rate: 50.0%", result)
        # self.assertIn("Total Migration Effort: 5 hours", result)

    def test_format_error(self):
        """Test formatting error message."""
        error = self.formatter.format_error("Test error")
        self.assertEqual(error, "Error: Test error")

    def test_format_warning(self):
        """Test formatting warning message."""
        warning = self.formatter.format_warning("Test warning")
        self.assertEqual(warning, "Warning: Test warning")

    def test_format_info(self):
        """Test formatting info message."""
        info = self.formatter.format_info("Test info")
        self.assertEqual(info, "Info: Test info")

    def test_format_progress(self):
        """Test formatting progress message."""
        progress = self.formatter.format_progress(3, 10, "test.py")
        self.assertIn("Progress: 3/10 (30.0%) - test.py", progress)


if __name__ == "__main__":
    unittest.main()
