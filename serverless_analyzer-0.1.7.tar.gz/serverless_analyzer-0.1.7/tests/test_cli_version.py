from serverless_analyzer.cli.cli_runner import CLIRunner


def test_version_flag(capsys):
    rc = CLIRunner().run(["--version"])
    assert rc == 0
    out, _ = capsys.readouterr()
    assert out.strip()
