#!/usr/bin/env python3
"""
Basic tests for ServerlessAnalyzer that don't require external dependencies.

These tests focus on core logic and data structures.
"""

import unittest
import sys
import os
import json
import tempfile
from pathlib import Path

# Import from the new modularized components
from serverless_analyzer.models import (
    ComplexityLevel,
    IssueDetail,
    ServerlessAnalysis,
    ConsolidatedReport,
)
from serverless_analyzer.io import FileReader

# Add the parent directory to the path to import the module
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

# Mock rich module before importing serverless_analyzer
import unittest.mock as mock

sys.modules["rich.console"] = mock.MagicMock()
sys.modules["rich.table"] = mock.MagicMock()
sys.modules["rich.panel"] = mock.MagicMock()
sys.modules["rich.syntax"] = mock.MagicMock()
sys.modules["rich.progress"] = mock.MagicMock()
sys.modules["rich.live"] = mock.MagicMock()
sys.modules["rich.spinner"] = mock.MagicMock()


class TestComplexityLevel(unittest.TestCase):
    """Test ComplexityLevel enum."""

    def test_complexity_level_values(self):
        """Test that complexity levels have expected values."""
        self.assertEqual(ComplexityLevel.LOW.value, "Low")
        self.assertEqual(ComplexityLevel.MEDIUM.value, "Medium")
        self.assertEqual(ComplexityLevel.HIGH.value, "High")
        self.assertEqual(ComplexityLevel.EXTREME.value, "Extreme")

    def test_complexity_level_enumeration(self):
        """Test that all complexity levels can be enumerated."""
        levels = list(ComplexityLevel)
        self.assertEqual(len(levels), 4)
        self.assertIn(ComplexityLevel.LOW, levels)
        self.assertIn(ComplexityLevel.MEDIUM, levels)
        self.assertIn(ComplexityLevel.HIGH, levels)
        self.assertIn(ComplexityLevel.EXTREME, levels)


class TestIssueDetail(unittest.TestCase):
    """Test IssueDetail data class."""

    def test_issue_detail_creation(self):
        """Test creating an IssueDetail instance."""
        issue = IssueDetail(
            type="TEST_ISSUE",
            description="Test issue description",
            line_number=10,
            code_snippet="test_code()",
            severity="HIGH",
            impact="Performance impact",
            recommendation="Fix the issue",
        )

        self.assertEqual(issue.type, "TEST_ISSUE")
        self.assertEqual(issue.description, "Test issue description")
        self.assertEqual(issue.line_number, 10)
        self.assertEqual(issue.code_snippet, "test_code()")
        self.assertEqual(issue.severity, "HIGH")
        self.assertEqual(issue.impact, "Performance impact")
        self.assertEqual(issue.recommendation, "Fix the issue")

    def test_issue_detail_optional_fields(self):
        """Test IssueDetail with optional fields."""
        issue = IssueDetail(
            type="TEST_ISSUE",
            description="Test issue description",
            line_number=10,
            code_snippet="test_code()",
            severity="HIGH",
            impact="Performance impact",
            recommendation="Fix the issue",
            affected_apis=["api1", "api2"],
            related_issues=["issue1", "issue2"],
        )

        self.assertEqual(issue.affected_apis, ["api1", "api2"])
        self.assertEqual(issue.related_issues, ["issue1", "issue2"])


class TestServerlessAnalysis(unittest.TestCase):
    """Test ServerlessAnalysis data class."""

    def test_serverless_analysis_creation(self):
        """Test creating a ServerlessAnalysis instance."""
        analysis = ServerlessAnalysis(
            notebook_path="test.py",
            is_compatible=True,
            complexity=ComplexityLevel.LOW,
            issue_counts={"TEST_ISSUE": 0},
            recommendations=["Keep up the good work!"],
            migration_effort={"hours": 0},
            detailed_issues=[],
        )

        self.assertEqual(analysis.notebook_path, "test.py")
        self.assertTrue(analysis.is_compatible)
        self.assertEqual(analysis.complexity, ComplexityLevel.LOW)
        self.assertEqual(analysis.issue_counts, {"TEST_ISSUE": 0})
        self.assertEqual(analysis.recommendations, ["Keep up the good work!"])
        self.assertEqual(analysis.migration_effort, {"hours": 0})
        self.assertEqual(analysis.detailed_issues, [])


class TestConsolidatedReport(unittest.TestCase):
    """Test ConsolidatedReport data class."""

    def test_consolidated_report_creation(self):
        """Test creating a ConsolidatedReport instance."""
        report = ConsolidatedReport(
            total_notebooks=5,
            compatible_notebooks=3,
            incompatible_notebooks=2,
            complexity_distribution={"Low": 2, "Medium": 2, "High": 1},
            issue_distribution={"TEST_ISSUE": 5},
            total_migration_effort=10,
            notebook_reports=[],
            summary={"key": "value"},
        )

        self.assertEqual(report.total_notebooks, 5)
        self.assertEqual(report.incompatible_notebooks, 2)
        self.assertEqual(
            report.complexity_distribution, {"Low": 2, "Medium": 2, "High": 1}
        )
        self.assertEqual(report.issue_distribution, {"TEST_ISSUE": 5})
        self.assertEqual(report.total_migration_effort, 10)
        self.assertEqual(report.notebook_reports, [])
        self.assertEqual(report.summary, {"key": "value"})


class TestFileReader(unittest.TestCase):
    """Test FileReader utility functions."""

    def setUp(self):
        """Set up test fixtures."""
        self.file_reader = FileReader()

    def test_is_databricks_path(self):
        """Test Databricks path detection."""
        # Valid Databricks paths
        self.assertTrue(
            self.file_reader.is_databricks_path("/Workspace/Repos/user/repo/notebook")
        )
        self.assertTrue(
            self.file_reader.is_databricks_path("/Repos/user/repo/notebook")
        )
        self.assertTrue(self.file_reader.is_databricks_path("/Shared/notebook"))

        # Invalid paths
        self.assertFalse(self.file_reader.is_databricks_path("notebook.py"))
        self.assertFalse(self.file_reader.is_databricks_path("./notebook.py"))
        self.assertFalse(self.file_reader.is_databricks_path("C:/notebook.py"))
        self.assertFalse(self.file_reader.is_databricks_path(""))
        self.assertFalse(self.file_reader.is_databricks_path(None))

    def test_safe_is_file(self):
        """Test safe file detection."""
        # Test with temporary file
        with tempfile.NamedTemporaryFile(delete=False) as tmp:
            tmp.write(b"test content")
            tmp.flush()

            self.assertTrue(self.file_reader.safe_is_file(tmp.name))

            # Test with temporary directory
            with tempfile.TemporaryDirectory() as tmp_dir:
                self.assertFalse(self.file_reader.safe_is_file(tmp_dir))

        # Test with Databricks path (should return True as they're assumed to be files)
        self.assertTrue(self.file_reader.safe_is_file("/Workspace/notebook"))

        # Test with Path object
        path_obj = Path("test_file.py")
        self.assertTrue(self.file_reader.safe_is_file(path_obj))

    def test_safe_get_file_size(self):
        """Test safe file size retrieval."""
        # Test with temporary file
        with tempfile.NamedTemporaryFile(delete=False) as tmp:
            tmp.write(b"test content")
            tmp.flush()

            size = self.file_reader.safe_get_file_size(tmp.name)
            self.assertGreater(size, 0)

        # Test with Databricks path (should return 0)
        size = self.file_reader.safe_get_file_size("/Workspace/notebook")
        self.assertEqual(size, 0)


class TestJSONSerialization(unittest.TestCase):
    """Test JSON serialization of data classes."""

    def test_enum_json_serialization(self):
        """Test that enums can be serialized to JSON."""
        analysis = ServerlessAnalysis(
            notebook_path="test.py",
            is_compatible=True,
            complexity=ComplexityLevel.LOW,
            issue_counts={"TEST_ISSUE": 0},
            recommendations=["Keep up the good work!"],
            migration_effort={"hours": 0},
            detailed_issues=[],
        )

        # Test that the analysis can be converted to dict and then to JSON
        analysis_dict = analysis.__dict__
        json_str = json.dumps(analysis_dict, default=str)

        self.assertIsInstance(json_str, str)
        self.assertIn("Low", json_str)  # Should contain the enum value


if __name__ == "__main__":
    unittest.main()
