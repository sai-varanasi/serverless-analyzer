from serverless_analyzer.core.analyzer import CompatibilityAnalyzer


def test_line_numbers_preserve_original_positions_with_comments():
    # Build content as lines to safely include triple quotes
    lines = [
        "# Databricks notebook source",
        "",
        "# This is a comment line that should be ignored",
        '"""',
        "This is a multi-line docstring",
        "that should be filtered out",
        '"""',
        "",
        "from pyspark.sql import SparkSession",
        "spark.sparkContext  # trigger spark_context pattern on this original line",
        "df = SparkSession.builder.getOrCreate().range(1)",
    ]
    content = "\n".join(lines)

    analyzer = CompatibilityAnalyzer()
    analysis = analyzer.analyze_notebook_from_content(content, notebook_path="test.py")

    assert analysis.detailed_issues, "Expected at least one issue to be detected"
    # Find the spark_context issue
    spark_ctx_issues = [
        i
        for i in analysis.detailed_issues
        if (i.type == "Unsupported API" and "spark_context" in (i.affected_apis or []))
    ]
    assert spark_ctx_issues, "Expected spark_context Unsupported API issue"

    issue = spark_ctx_issues[0]
    # Compute the original line number where spark.sparkContext appears
    original_lines = content.splitlines()
    expected_line = next(
        idx + 1 for idx, ln in enumerate(original_lines) if "spark.sparkContext" in ln
    )

    assert issue.line_number == expected_line, (
        f"Expected line number {expected_line}, got {issue.line_number}"
    )
