from serverless_analyzer.core.analyzer import CompatibilityAnalyzer


def test_jdbc_reads_marked_private_preview_with_medium_severity():
    content = "%sql\nCREATE TABLE t USING JDBC OPTIONS (url 'jdbc:postgresql://x');\n"

    analyzer = CompatibilityAnalyzer()
    analysis = analyzer.analyze_notebook_from_content(content, notebook_path="test.sql")

    # Look for the JDBC reads issue under Unsupported SQL Command
    jdbc_issues = [
        i
        for i in analysis.detailed_issues
        if i.type == "Unsupported SQL Command"
        and (i.affected_apis or [None])[0] == "jdbc_reads"
    ]
    assert jdbc_issues, "Expected jdbc_reads Unsupported SQL Command issue"

    issue = jdbc_issues[0]
    assert issue.severity == "Medium"
    assert "private preview" in (issue.description or "").lower()
