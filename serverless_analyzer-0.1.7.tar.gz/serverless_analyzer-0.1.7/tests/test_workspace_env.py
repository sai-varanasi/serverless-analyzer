import os
from unittest.mock import patch
from serverless_analyzer.io.workspace_client import WorkspaceClient


def test_detect_env_via_host_token():
    with patch.dict(
        os.environ,
        {"DATABRICKS_HOST": "https://abc", "DATABRICKS_TOKEN": "t"},
        clear=False,
    ):
        wc = WorkspaceClient()
        assert wc._detect_databricks_environment()


def test_detect_env_via_profile():
    with patch.dict(os.environ, {"DATABRICKS_CONFIG_PROFILE": "DEFAULT"}, clear=False):
        wc = WorkspaceClient()
        assert wc._detect_databricks_environment()
