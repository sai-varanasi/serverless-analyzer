#!/usr/bin/env python3
"""
Simple test for the modularized serverless analyzer components.
"""

import unittest
import os
import sys

# Add the parent directory to the path to import the module
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

# Test the models directly
from serverless_analyzer.models.enums import ComplexityLevel
from serverless_analyzer.models.issues import IssueDetail
from serverless_analyzer.models.metadata import WorkspaceMetadata
from serverless_analyzer.models.analysis import ServerlessAnalysis, ConsolidatedReport


class TestModularizedModels(unittest.TestCase):
    """Test the modularized model components."""

    def test_complexity_level_enum(self):
        """Test ComplexityLevel enum."""
        self.assertEqual(ComplexityLevel.LOW.value, "Low")
        self.assertEqual(ComplexityLevel.MEDIUM.value, "Medium")
        self.assertEqual(ComplexityLevel.HIGH.value, "High")
        self.assertEqual(ComplexityLevel.EXTREME.value, "Extreme")

    def test_issue_detail_creation(self):
        """Test IssueDetail creation."""
        issue = IssueDetail(
            type="Test Issue",
            description="Test description",
            line_number=42,
            code_snippet="test code",
            severity="High",
            impact="Critical",
            recommendation="Test recommendation",
        )

        self.assertEqual(issue.type, "Test Issue")
        self.assertEqual(issue.description, "Test description")
        self.assertEqual(issue.line_number, 42)
        self.assertEqual(issue.code_snippet, "test code")
        self.assertEqual(issue.severity, "High")
        self.assertEqual(issue.impact, "Critical")
        self.assertEqual(issue.recommendation, "Test recommendation")

    def test_workspace_metadata_creation(self):
        """Test WorkspaceMetadata creation."""
        metadata = WorkspaceMetadata(
            object_id=123,
            object_type="NOTEBOOK",
            path="/Workspace/test",
            language="python",
        )

        self.assertEqual(metadata.object_id, 123)
        self.assertEqual(metadata.object_type, "NOTEBOOK")
        self.assertEqual(metadata.path, "/Workspace/test")
        self.assertEqual(metadata.language, "python")

    def test_serverless_analysis_creation(self):
        """Test ServerlessAnalysis creation."""
        analysis = ServerlessAnalysis(
            notebook_path="/test/notebook.py",
            is_compatible=True,
            complexity=ComplexityLevel.LOW,
            issues=[],
            required_changes=[],
            performance_impacts=[],
            recommendations=[],
            code_snippets={},
            language_support={},
            api_support={},
            data_source_support={},
            streaming_support={},
            ml_support={},
            caching_support={},
            hive_support={},
            issue_counts={},
            complexity_factors={},
            migration_effort={},
            detailed_issues=[],
            analysis_timestamp="2024-01-01T00:00:00",
            notebook_metadata={},
            spark_configurations={},
        )

        self.assertEqual(analysis.notebook_path, "/test/notebook.py")
        self.assertTrue(analysis.is_compatible)
        self.assertEqual(analysis.complexity, ComplexityLevel.LOW)
        self.assertEqual(analysis.analysis_timestamp, "2024-01-01T00:00:00")

    def test_consolidated_report_creation(self):
        """Test ConsolidatedReport creation."""
        report = ConsolidatedReport(
            analysis_timestamp="2024-01-01T00:00:00",
            total_notebooks=2,
            compatible_notebooks=1,
            incompatible_notebooks=1,
            complexity_distribution={"LOW": 1, "HIGH": 1},
            issue_distribution={"api_issues": 2},
            total_migration_effort=4,
            notebook_reports=[],
            summary={},
            all_spark_configurations={},
        )

        self.assertEqual(report.total_notebooks, 2)
        self.assertEqual(report.compatible_notebooks, 1)
        self.assertEqual(report.incompatible_notebooks, 1)
        self.assertEqual(report.total_migration_effort, 4)


if __name__ == "__main__":
    unittest.main()
