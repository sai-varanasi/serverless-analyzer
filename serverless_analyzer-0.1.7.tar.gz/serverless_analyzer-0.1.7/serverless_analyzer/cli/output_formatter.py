"""
Output formatting for serverless analyzer CLI.
"""

from typing import List
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.text import Text
from ..models.analysis import ServerlessAnalysis, ConsolidatedReport


class OutputFormatter:
    """Handles output formatting for the CLI."""

    def __init__(self, verbose: bool = False):
        self.verbose = verbose
        self.console = Console()

    def format_analysis_result(self, analysis: ServerlessAnalysis) -> str:
        """Format a single analysis result for display."""
        # Use rich for enhanced terminal output
        self._print_analysis_result_rich(analysis)
        # return self._format_analysis_result_text(analysis)
        return "All Done!!"

    def _print_analysis_result_rich(self, analysis: ServerlessAnalysis) -> None:
        """Print analysis result using rich for enhanced terminal display."""
        # Create status indicator
        status = "✅ COMPATIBLE" if analysis.is_compatible else "❌ INCOMPATIBLE"
        status_color = "green" if analysis.is_compatible else "red"

        # Header panel
        header_text = Text()
        header_text.append("Analysis Results for: ", style="bold cyan")
        header_text.append(str(analysis.notebook_path), style="bold white")

        self.console.print(
            Panel(header_text, title="📊 Notebook Analysis", border_style="blue")
        )

        # Status and complexity
        status_table = Table(show_header=False, box=None)
        status_table.add_column("Label", style="dim", width=12)
        status_table.add_column("Value", style="bold")

        status_table.add_row("Status:", Text(status, style=status_color))
        status_table.add_row(
            "Complexity:", Text(analysis.complexity.value, style="yellow")
        )
        # Calculate total active issues (exclude skipped_issues from sum)
        total_issues = 0
        if analysis.issue_counts:
            total_issues = sum(
                count
                for key, count in analysis.issue_counts.items()
                if key != "skipped_issues"
            )
        status_table.add_row("Total Issues:", Text(str(total_issues), style="white"))

        self.console.print(status_table)
        self.console.print()

        # Issue summary - calculate total active issues (exclude skipped)
        total_issues = sum(
            count
            for key, count in analysis.issue_counts.items()
            if key != "skipped_issues"
        )
        if total_issues > 0:
            issues_panel = Panel.fit(
                self._format_issues_rich(analysis.issue_counts),
                title="⚠️ Issues Found",
                border_style="yellow",
            )
            self.console.print(issues_panel)

        # Recommendations
        if analysis.recommendations:
            recs_panel = Panel.fit(
                "\n".join(f"• {rec}" for rec in analysis.recommendations),
                title="💡 Recommendations",
                border_style="green",
            )
            self.console.print(recs_panel)

        # Analysis summary with migration effort
        migration_effort = analysis.migration_effort or {}
        est_hours = migration_effort.get("estimated_hours", 0)
        risk_level = migration_effort.get("risk_level", "Unknown")
        priority = migration_effort.get("priority", "Unknown")
        self.console.print(
            Panel(
                f"[bold]Serverless Compatibility Analysis[/bold]\n"
                f"Notebook: {analysis.notebook_path.split('/')[-1]}\n"
                f"Analysis Time: {analysis.analysis_timestamp}\n"
                f"Compatibility: {'[green]Compatible[/green]' if analysis.is_compatible else '[red]Not Compatible[/red]'}\n"
                f"Complexity: {analysis.complexity.value}\n"
                f"Total Issues: {total_issues}\n"
                f"Migration Effort: {est_hours} hours\n"
                f"Risk Level: {risk_level}\n"
                f"Priority: {priority}",
                title="Analysis Summary",
                border_style="cyan",
            )
        )

        # Notebook metadata
        if analysis.notebook_metadata:
            metadata_table = Table(show_header=True, header_style="bold")
            metadata_table.add_column("Property")
            metadata_table.add_column("Value")
            for key, value in analysis.notebook_metadata.items():
                if isinstance(value, list):
                    value = ", ".join(map(str, value))
                elif isinstance(value, dict):
                    # Keep dicts readable in a single cell
                    value = ", ".join(f"{k}={v}" for k, v in value.items())
                metadata_table.add_row(key.replace("_", " ").title(), str(value))
            self.console.print(
                Panel.fit(
                    metadata_table, title="🧾 Notebook Metadata", border_style="blue"
                )
            )

        # Issue statistics
        if analysis.issue_counts:
            stats_table = Table(show_header=True, header_style="bold")
            stats_table.add_column("Issue Type")
            stats_table.add_column("Count", justify="right")
            stats_table.add_column("Status")
            for issue_type, count in analysis.issue_counts.items():
                # Mark skipped issues specially
                if issue_type == "skipped_issues":
                    stats_table.add_row(
                        issue_type.replace("_", " ").title(),
                        str(count),
                        "[dim]⏭️ Skipped[/dim]",
                    )
                else:
                    stats_table.add_row(
                        issue_type.replace("_", " ").title(),
                        str(count),
                        "[green]Active[/green]" if count > 0 else "",
                    )
            self.console.print(
                Panel.fit(
                    stats_table, title="📈 Issue Statistics", border_style="magenta"
                )
            )

        # Spark configurations
        if analysis.spark_configurations:
            config_table = Table(show_header=True, header_style="bold")
            config_table.add_column("Configuration")
            config_table.add_column("Value")
            config_table.add_column("Line", justify="right")
            config_table.add_column("Supported")
            for config_name, usages in analysis.spark_configurations.items():
                for usage in usages:
                    config_table.add_row(
                        config_name,
                        str(usage.get("value", "")),
                        str(usage.get("line_number", "")),
                        "[green]Yes[/green]"
                        if usage.get("is_supported")
                        else "[red]No[/red]",
                    )
            self.console.print(
                Panel.fit(
                    config_table, title="⚙️ Spark Configurations", border_style="yellow"
                )
            )

        # Detailed issues - separate active and skipped
        if analysis.detailed_issues:
            active_issues = [
                iss for iss in analysis.detailed_issues if not iss.is_skipped
            ]
            skipped_issues = [iss for iss in analysis.detailed_issues if iss.is_skipped]

            # Show active issues
            if active_issues:
                self.console.print("\n[bold]Active Issues:[/bold]")
                for issue in active_issues:
                    affected_list = issue.affected_apis or []
                    related_list = issue.related_issues or []
                    affected = ", ".join(affected_list) if affected_list else "None"
                    related = ", ".join(related_list) if related_list else "None"
                    self.console.print(
                        Panel(
                            f"[bold]{issue.type}[/bold]\n"
                            f"Line: {issue.line_number}\n"
                            f"Severity: {issue.severity}\n"
                            f"Impact: {issue.impact}\n"
                            f"Description: {issue.description}\n"
                            f"Code: {issue.code_snippet}\n"
                            f"Recommendation: {issue.recommendation}\n"
                            f"Affected APIs: {affected}\n"
                            f"Related Issues: {related}",
                            title=f"Issue at Line {issue.line_number}",
                            border_style=(
                                "red" if issue.severity == "High" else "yellow"
                            ),
                        )
                    )

            # Show skipped issues
            if skipped_issues:
                self.console.print("\n[bold dim]⏭️ Skipped Issues:[/bold dim]")
                for issue in skipped_issues:
                    affected_list = issue.affected_apis or []
                    related_list = issue.related_issues or []
                    affected = ", ".join(affected_list) if affected_list else "None"
                    related = ", ".join(related_list) if related_list else "None"
                    skip_info = (
                        f"\n[dim]Skip Reason: {issue.skip_reason}[/dim]"
                        if issue.skip_reason
                        else ""
                    )
                    self.console.print(
                        Panel(
                            f"[bold dim]{issue.type}[/bold dim]\n"
                            f"Line: {issue.line_number}\n"
                            f"Severity: {issue.severity}\n"
                            f"Impact: {issue.impact}\n"
                            f"Description: {issue.description}\n"
                            f"Code: {issue.code_snippet}\n"
                            f"Recommendation: {issue.recommendation}\n"
                            f"Affected APIs: {affected}\n"
                            f"Related Issues: {related}"
                            f"{skip_info}",
                            title=f"⏭️ Skipped Issue at Line {issue.line_number}",
                            border_style="dim",
                        )
                    )

    def _format_issues_rich(self, issue_counts: dict) -> str:
        """Format issue counts using rich."""
        lines = []
        for issue_type, count in issue_counts.items():
            if count > 0:
                lines.append(f"• {issue_type}: {count}")
        return "\n".join(lines)

    def _format_analysis_result_text(self, analysis: ServerlessAnalysis) -> str:
        """Format analysis result as plain text (for backward compatibility)."""
        lines = []

        # Header
        lines.append(f"Analysis Results for: {analysis.notebook_path}")
        lines.append("=" * 60)

        # Compatibility status
        status = "✓ COMPATIBLE" if analysis.is_compatible else "✗ INCOMPATIBLE"
        lines.append(f"Status: {status}")
        lines.append(f"Complexity: {analysis.complexity.value}")
        lines.append("")

        # Metadata
        if analysis.notebook_metadata:
            lines.append("Notebook Metadata:")
            for key, value in analysis.notebook_metadata.items():
                if isinstance(value, list):
                    value = ", ".join(map(str, value))
                elif isinstance(value, dict):
                    value = ", ".join(f"{k}={v}" for k, v in value.items())
                lines.append(f"  {key}: {value}")
            lines.append("")

        # Issue summary
        total_issues = sum(analysis.issue_counts.values())
        if total_issues > 0:
            lines.append("Issues Found:")
            for issue_type, count in analysis.issue_counts.items():
                if count > 0:
                    lines.append(f"  {issue_type}: {count}")
            lines.append("")

        # Recommendations
        if analysis.recommendations:
            lines.append("Recommendations:")
            for i, rec in enumerate(analysis.recommendations, 1):
                lines.append(f"  {i}. {rec}")
            lines.append("")

        # Migration effort
        if analysis.migration_effort:
            lines.append("Migration Effort:")
            for key, value in analysis.migration_effort.items():
                lines.append(f"  {key}: {value}")
            lines.append("")

        # Spark configurations
        if analysis.spark_configurations:
            lines.append("Spark Configurations:")
            for config_name, usages in analysis.spark_configurations.items():
                for usage in usages:
                    supported = "Yes" if usage.get("is_supported") else "No"
                    lines.append(
                        f"  {config_name} = {usage.get('value', '')} (line {usage.get('line_number', '')}, supported: {supported})"
                    )
            lines.append("")

        # Detailed issues (verbose mode)
        if self.verbose and analysis.detailed_issues:
            lines.append("Detailed Issues:")
            for issue in analysis.detailed_issues:
                lines.append(f"  Line {issue.line_number}: {issue.type}")
                lines.append(f"    Description: {issue.description}")
                lines.append(f"    Severity: {issue.severity}")
                lines.append(f"    Impact: {issue.impact}")
                lines.append(f"    Recommendation: {issue.recommendation}")
                if issue.code_snippet:
                    lines.append(f"    Code: {issue.code_snippet}")
                lines.append("")

        # return "\n".join(lines)
        return "All Done!!"

    def format_consolidated_result(self, report: ConsolidatedReport) -> str:
        """Format a consolidated report for display."""
        # Use rich for enhanced terminal output
        self._print_consolidated_result_rich(report)
        return self._format_consolidated_result_text(report)

    def _print_consolidated_result_rich(self, report: ConsolidatedReport) -> None:
        """Print consolidated result using rich for enhanced terminal display."""
        # Header panel
        header_panel = Panel.fit(
            "📈 Consolidated Analysis Report", title="📊 Summary", border_style="blue"
        )
        self.console.print(header_panel)

        # Summary table
        summary_table = Table(show_header=True, header_style="bold magenta")
        summary_table.add_column("Metric", style="cyan")
        summary_table.add_column("Value", style="white", justify="right")

        summary_table.add_row("Total Notebooks", str(report.total_notebooks))
        summary_table.add_row("Compatible", str(report.compatible_notebooks))
        summary_table.add_row("Incompatible", str(report.incompatible_notebooks))

        if report.total_notebooks > 0:
            compatibility_rate = (
                report.compatible_notebooks / report.total_notebooks
            ) * 100
            summary_table.add_row("Compatibility Rate", f"{compatibility_rate:.1f}%")
        if report.summary and report.summary.get("average_complexity"):
            summary_table.add_row(
                "Average Complexity", str(report.summary.get("average_complexity"))
            )
        summary_table.add_row(
            "Total Migration Effort (hrs)", str(report.total_migration_effort)
        )

        # Show skipped issues total if present
        skipped_total = getattr(report, "skipped_issues_total", 0)
        if skipped_total:
            summary_table.add_row("Skipped Issues", str(skipped_total))

        # Risk assessment (derived if not present)
        if report.total_notebooks > 0:
            incompatible = report.incompatible_notebooks
            risk = (
                "High"
                if incompatible > report.total_notebooks * 0.5
                else ("Medium" if incompatible > 0 else "Low")
            )
            summary_table.add_row("Risk Assessment", risk)

        self.console.print(summary_table)
        self.console.print()

        # Complexity distribution table with percentages
        if report.complexity_distribution:
            comp_table = Table(show_header=True, header_style="bold")
            comp_table.add_column("Complexity")
            comp_table.add_column("Count", justify="right")
            comp_table.add_column("Percentage", justify="right")
            total = report.total_notebooks or 0
            for key, count in report.complexity_distribution.items():
                pct = (count / total * 100) if total else 0
                comp_table.add_row(key, str(count), f"{pct:.1f}%")
            self.console.print(
                Panel.fit(
                    comp_table,
                    title="🎯 Complexity Distribution",
                    border_style="yellow",
                )
            )

        # Issue distribution table with percentages
        if report.issue_distribution:
            issues_table = Table(show_header=True, header_style="bold")
            issues_table.add_column("Issue Type")
            issues_table.add_column("Count", justify="right")
            issues_table.add_column("Percentage", justify="right")
            total_issues = sum(report.issue_distribution.values()) or 0
            for key, count in report.issue_distribution.items():
                pct = (count / total_issues * 100) if total_issues else 0
                issues_table.add_row(
                    key.replace("_", " ").title(), str(count), f"{pct:.1f}%"
                )
            self.console.print(
                Panel.fit(
                    issues_table, title="⚠️ Issue Distribution", border_style="red"
                )
            )

        # Notebook details (include migration effort if present)
        if report.notebook_reports:
            table = Table(
                show_header=True, header_style="bold blue", title="📝 Notebook Details"
            )
            table.add_column(
                "Notebook", style="white", no_wrap=False, overflow="fold", max_width=60
            )
            table.add_column("Status", style="white")
            table.add_column("Complexity", style="yellow")
            table.add_column("Issues", style="red", justify="right")
            table.add_column("Migration Effort (hrs)", justify="right")

            for notebook in report.notebook_reports:
                status = "✅" if notebook.get("is_compatible") else "❌"
                complexity = notebook.get("complexity")
                issues = str(notebook.get("total_issues", 0))
                mig = notebook.get("migration_effort")
                if isinstance(mig, dict):
                    mig_val = mig.get("estimated_hours", 0)
                else:
                    mig_val = mig if mig is not None else 0
                path_str = str(notebook.get("path")).split("/")[-1]
                if len(path_str) > 80:
                    path_str = "…" + path_str[-79:]
                table.add_row(
                    path_str,
                    status,
                    str(complexity),
                    issues,
                    str(mig_val),
                )

            self.console.print(table)

        # Optional: Spark configurations across notebooks (if provided)
        if report.all_spark_configurations:
            agg_table = Table(show_header=True, header_style="bold")
            agg_table.add_column("Configuration")
            agg_table.add_column("Occurrences", justify="right")
            agg_table.add_column("Is Supported", justify="right")
            for config_name, usages in report.all_spark_configurations.items():
                total = len(usages)
                supported = any([u.get("is_supported") for u in usages])
                agg_table.add_row(config_name, str(total), str(supported))
            self.console.print(
                Panel.fit(
                    agg_table,
                    title="⚙️ Spark Configurations (Aggregate)",
                    border_style="green",
                )
            )

    def _format_distribution_rich(self, distribution: dict, item_type: str) -> str:
        """Format distribution data using rich."""
        lines = []
        for key, count in distribution.items():
            if count > 0:
                lines.append(f"• {key}: {count} {item_type}")
        return "\n".join(lines)

    def _print_notebook_details_rich(self, notebook_reports: List[dict]) -> None:
        """Print notebook details using rich table."""
        table = Table(
            show_header=True, header_style="bold blue", title="📝 Notebook Details"
        )
        table.add_column(
            "Notebook", style="white", no_wrap=False, overflow="fold", max_width=60
        )
        table.add_column("Status", style="white")
        table.add_column("Complexity", style="yellow")
        table.add_column("Issues", style="red", justify="right")
        table.add_column("Migration Effort (hrs)", justify="right")

        for notebook in notebook_reports:
            status = "✅" if notebook["is_compatible"] else "❌"
            mig = notebook.get("migration_effort")
            if isinstance(mig, dict):
                mig_val = mig.get("estimated_hours", 0)
            else:
                mig_val = mig if mig is not None else 0
            path_str = str(notebook["path"])
            if len(path_str) > 80:
                path_str = "…" + path_str[-79:]
            table.add_row(
                path_str,
                status,
                notebook["complexity"],
                str(notebook["total_issues"]),
                str(mig_val),
            )

        self.console.print(table)

    def _format_consolidated_result_text(self, report: ConsolidatedReport) -> str:
        """Format consolidated report as plain text (for backward compatibility)."""
        lines = []

        # Header
        lines.append("Consolidated Analysis Report")
        lines.append("=" * 60)

        # Summary
        lines.append("Summary:")
        lines.append(f"  Total Notebooks: {report.total_notebooks}")
        lines.append(f"  Compatible Notebooks: {report.compatible_notebooks}")
        lines.append(f"  Incompatible Notebooks: {report.incompatible_notebooks}")

        if report.total_notebooks > 0:
            compatibility_rate = (
                report.compatible_notebooks / report.total_notebooks
            ) * 100
            lines.append(f"  Compatibility Rate: {compatibility_rate:.1f}%")
        if report.summary and report.summary.get("average_complexity"):
            lines.append(
                f"  Average Complexity: {report.summary.get('average_complexity')}"
            )
        lines.append(f"  Total Migration Effort: {report.total_migration_effort} hours")
        lines.append("")

        # Complexity distribution
        if report.complexity_distribution:
            lines.append("Complexity Distribution:")
            for complexity, count in report.complexity_distribution.items():
                pct = (
                    (count / report.total_notebooks * 100)
                    if report.total_notebooks > 0
                    else 0
                )
                lines.append(f"  {complexity}: {count} ({pct:.1f}%)")
            lines.append("")

        # Issue distribution
        if report.issue_distribution:
            lines.append("Issue Distribution:")
            total_issues = sum(report.issue_distribution.values())
            for issue_type, count in report.issue_distribution.items():
                if count > 0:
                    pct = (count / total_issues * 100) if total_issues > 0 else 0
                    lines.append(f"  {issue_type}: {count} ({pct:.1f}%)")
            lines.append("")

        # Notebook details
        if report.notebook_reports:
            lines.append("Notebook Details:")
            for notebook in report.notebook_reports:
                status = (
                    "✓ COMPATIBLE" if notebook["is_compatible"] else "✗ INCOMPATIBLE"
                )
                mig = notebook.get("migration_effort")
                if isinstance(mig, dict):
                    mig_val = mig.get("estimated_hours", 0)
                else:
                    mig_val = mig if mig is not None else 0
                lines.append(
                    f"  {notebook['path']}: {status} ({notebook['complexity']} complexity, {notebook['total_issues']} issues, {mig_val} hrs)"
                )
            lines.append("")

        # Summary insights
        if report.summary:
            lines.append("Summary Insights:")
            for key, value in report.summary.items():
                lines.append(f"  {key}: {value}")
            lines.append("")

        # return "\n".join(lines)
        return "All Done!!"

    def format_error(self, error: str) -> str:
        """Format an error message."""
        return f"Error: {error}"

    def format_warning(self, warning: str) -> str:
        """Format a warning message."""
        return f"Warning: {warning}"

    def format_info(self, info: str) -> str:
        """Format an info message."""
        return f"Info: {info}"

    def format_progress(self, current: int, total: int, item: str) -> str:
        """Format a progress message."""
        percentage = (current / total * 100) if total > 0 else 0
        return f"Progress: {current}/{total} ({percentage:.1f}%) - {item}"
