"""
CLI runner for serverless analyzer.
"""

import sys
import argparse
import logging
from pathlib import Path
from typing import List, Optional, Dict, Any
import json
from .argument_parser import ArgumentParser
from .output_formatter import OutputFormatter
from ..services.analysis_service import AnalysisService
from ..services.report_service import ReportService
from ..models.analysis import ServerlessAnalysis
from ..publisher import PublishConfig, AnalysisPublisher
from ..services.workspace_service import WorkspaceService


class CLIRunner:
    """Main CLI runner for the serverless analyzer."""

    def __init__(self) -> None:
        self.argument_parser = ArgumentParser()
        self.output_formatter = OutputFormatter()
        self.logger: Optional[logging.Logger] = None

    def run(self, args: Optional[List[str]] = None) -> int:
        """Run the CLI with the given arguments."""
        try:
            # Parse arguments
            try:
                parsed_args = self.argument_parser.parse_args(args)
            except SystemExit as e:
                # Allow --version/--help to terminate gracefully with printed output
                return int(getattr(e, "code", 0) or 0)

            # Handle --list-checks flag
            if getattr(parsed_args, "list_checks", False):
                from ..config.skip_config import SkipConfig

                print(SkipConfig.get_help_text())
                return 0

            # Validate arguments
            errors = self.argument_parser.validate_args(parsed_args)
            if errors:
                for error in errors:
                    print(self.output_formatter.format_error(error), file=sys.stderr)
                return 1

            # Deprecation notices for legacy flags
            if getattr(parsed_args, "publish_tables", False) and not getattr(
                parsed_args, "export", None
            ):
                print(
                    self.output_formatter.format_warning(
                        "--publish-tables is deprecated; use --export tables"
                    )
                )
            if getattr(parsed_args, "format", None):
                if parsed_args.format == "json" and not getattr(
                    parsed_args, "export", None
                ):
                    if getattr(parsed_args, "output", None) or getattr(
                        parsed_args, "output_dir", None
                    ):
                        print(
                            self.output_formatter.format_warning(
                                "--format json is deprecated; use --export json"
                            )
                        )
                if parsed_args.format == "summary" and not getattr(
                    parsed_args, "export", None
                ):
                    print(
                        self.output_formatter.format_warning(
                            "--format summary is deprecated; summary is now the default stdout output"
                        )
                    )

            # Set up logging if verbose mode is enabled
            if parsed_args.verbose:
                logging.basicConfig(
                    level=logging.INFO,
                    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
                    stream=sys.stderr,
                )
                logger = logging.getLogger("serverless_analyzer")
                self.logger = logger
                logger.info("Verbose logging enabled")

            # Update formatter with verbose setting
            self.output_formatter = OutputFormatter(verbose=parsed_args.verbose)

            # Extract skip_checks list from args
            skip_checks_list = None
            if getattr(parsed_args, "skip_checks", None):
                skip_checks_list = [
                    s.strip() for s in parsed_args.skip_checks.split(",")
                ]

            # Initialize services
            analysis_service = AnalysisService(
                scala_as_jar=parsed_args.scala_as_jar,
                verbose=parsed_args.verbose,
                logger=self.logger,
                force_workspace=parsed_args.databricks,
                max_file_size=parsed_args.max_file_size,
                skip_checks=skip_checks_list,
            )
            report_service = ReportService(logger=self.logger)

            # Analyze notebooks
            if parsed_args.verbose:
                print(
                    self.output_formatter.format_info(
                        f"Analyzing: {parsed_args.notebook_path}"
                    )
                )

            analyses = self._analyze_notebooks(analysis_service, parsed_args)

            if not analyses:
                print(
                    self.output_formatter.format_error("No notebooks found to analyze")
                )
                return 1

            # Determine export mode (new unified flag and legacy compatibility)
            export_mode: Optional[str] = getattr(parsed_args, "export", None)
            # Legacy compatibility for --publish-tables
            if export_mode is None and getattr(parsed_args, "publish_tables", False):
                export_mode = "tables"

            # Legacy compatibility for --format option
            # - format=json implies export json when an output destination is provided
            # - format=summary implies stdout summary by default
            if export_mode is None and getattr(parsed_args, "format", None) == "json":
                # Only treat as json export if user asked to write to file/dir
                if getattr(parsed_args, "output", None) or getattr(
                    parsed_args, "output_dir", None
                ):
                    export_mode = "json"

            # Default behavior when no explicit export: print human-readable summary to stdout

            # Generate report
            if len(analyses) == 1:
                # Single notebook analysis
                analysis = analyses[0]
                if export_mode == "json":
                    # Respect output or output-dir
                    if parsed_args.output:
                        report_service.generate_json_report(
                            analysis, parsed_args.output
                        )
                        if parsed_args.verbose:
                            print(
                                self.output_formatter.format_info(
                                    f"Report saved to: {parsed_args.output}"
                                )
                            )
                    elif parsed_args.output_dir:
                        output_dir = Path(parsed_args.output_dir)
                        output_dir.mkdir(parents=True, exist_ok=True)
                        safe_name = report_service._get_safe_filename(
                            analysis.notebook_path
                        )
                        individual_path = output_dir / f"{safe_name}_report.json"
                        report_service.generate_json_report(analysis, individual_path)
                        if parsed_args.verbose:
                            print(
                                self.output_formatter.format_info(
                                    f"Report saved to: {individual_path}"
                                )
                            )
                    else:
                        # No destination specified; print summary per default behavior
                        print(self.output_formatter.format_analysis_result(analysis))
                elif export_mode == "csv":
                    # For single analysis, require directory and write detailed CSV only
                    base_dir = self._resolve_output_dir_from_args(parsed_args)
                    if base_dir is None:
                        print(
                            self.output_formatter.format_error(
                                "CSV export requires --output-dir or --output to derive the directory"
                            )
                        )
                        return 1
                    # Warn if deriving directory from --output
                    if (
                        getattr(parsed_args, "output_dir", None) is None
                        and getattr(parsed_args, "output", None) is not None
                    ):
                        print(
                            self.output_formatter.format_warning(
                                f"Deriving CSV output directory from --output path parent: {base_dir}"
                            )
                        )

                    consolidated = analysis_service.create_consolidated_report([
                        analysis
                    ])
                    report_service.generate_csv_reports(
                        [analysis], consolidated, base_dir
                    )
                    if parsed_args.verbose:
                        print(
                            self.output_formatter.format_info(
                                f"CSV files written under: {base_dir}"
                            )
                        )
                elif export_mode == "tables":
                    # Fall through to publish block after consolidated handling
                    pass
                else:
                    # Default summary to stdout
                    print(self.output_formatter.format_analysis_result(analysis))
            else:
                # Multiple notebook analysis
                consolidated_report = analysis_service.create_consolidated_report(
                    analyses
                )
                if export_mode == "json":
                    if parsed_args.output:
                        report_service.generate_consolidated_json_report(
                            consolidated_report, parsed_args.output
                        )
                        if parsed_args.verbose:
                            print(
                                self.output_formatter.format_info(
                                    f"Report saved to: {parsed_args.output}"
                                )
                            )
                    elif parsed_args.output_dir:
                        output_dir = Path(parsed_args.output_dir)
                        report_service.generate_directory_reports(
                            analyses, consolidated_report, output_dir
                        )
                        if parsed_args.verbose:
                            print(
                                self.output_formatter.format_info(
                                    f"All reports saved to: {output_dir}"
                                )
                            )
                    else:
                        # No destination specified; print summary per default
                        print(
                            self.output_formatter.format_consolidated_result(
                                consolidated_report
                            )
                        )
                elif export_mode == "csv":
                    base_dir = self._resolve_output_dir_from_args(parsed_args)
                    if base_dir is None:
                        print(
                            self.output_formatter.format_error(
                                "CSV export requires --output-dir or --output to derive the directory"
                            )
                        )
                        return 1
                    if (
                        getattr(parsed_args, "output_dir", None) is None
                        and getattr(parsed_args, "output", None) is not None
                    ):
                        print(
                            self.output_formatter.format_warning(
                                f"Deriving CSV output directory from --output path parent: {base_dir}"
                            )
                        )
                    report_service.generate_csv_reports(
                        analyses, consolidated_report, base_dir
                    )
                    if parsed_args.verbose:
                        print(
                            self.output_formatter.format_info(
                                f"CSV files written under: {base_dir}"
                            )
                        )
                elif export_mode == "tables":
                    # Fall through to publish block below
                    pass
                else:
                    print(
                        self.output_formatter.format_consolidated_result(
                            consolidated_report
                        )
                    )

            # Generate system table queries if requested
            if getattr(parsed_args, "generate_queries", False):
                ws_service = WorkspaceService(logger=self.logger)
                analyzed_paths: List[str] = [a.notebook_path for a in analyses]
                queries = ws_service.get_system_table_queries(analyzed_paths)

                base_dir_from_queries: Optional[Path] = None
                if parsed_args.output_dir:
                    base_dir_from_queries = Path(parsed_args.output_dir)
                elif parsed_args.output:
                    base_dir_from_queries = Path(parsed_args.output).parent

                if base_dir_from_queries is not None:
                    written = report_service.write_query_files(
                        queries, base_dir_from_queries
                    )
                    print(
                        self.output_formatter.format_info(
                            f"Wrote {len(written)} SQL files under: {base_dir_from_queries / 'queries'}"
                        )
                    )
                else:
                    # No output destination; print to stdout
                    print(self.output_formatter.format_info("Generated SQL queries:"))
                    for key, sql in queries.items():
                        print("")
                        print(self.output_formatter.format_info(f"-- {key} --"))
                        print(sql)
                    print(
                        self.output_formatter.format_info(
                            "Tip: use --output-dir to write these into .sql files"
                        )
                    )

            # Optional publishing to Unity Catalog tables (new export=tables or legacy flag)
            if export_mode == "tables":
                consolidated = analysis_service.create_consolidated_report(analyses)
                report_dict: Dict[str, Any] = {
                    "analysis_timestamp": consolidated.analysis_timestamp,
                    "total_notebooks": consolidated.total_notebooks,
                    "compatible_notebooks": consolidated.compatible_notebooks,
                    "incompatible_notebooks": consolidated.incompatible_notebooks,
                    "total_migration_effort": consolidated.total_migration_effort,
                    "notebook_reports": consolidated.notebook_reports,
                    "summary": consolidated.summary,
                }

                # Prepare detailed rows from analyses
                detailed_rows: List[Dict[str, Any]] = []
                for a in analyses:
                    detailed_rows.append({
                        "analysis_timestamp": consolidated.analysis_timestamp,
                        "notebook_path": a.notebook_path,
                        "complexity": a.complexity.value,
                        "is_compatible": a.is_compatible,
                        "total_issues": sum(a.issue_counts.values()),
                        "migration_effort": (
                            a.migration_effort.get("estimated_hours", 0)
                            if isinstance(a.migration_effort, dict)
                            else a.migration_effort
                        ),
                        "issue_counts_json": json.dumps(a.issue_counts or {}),
                        "detailed_issues_json": json.dumps(
                            [di.__dict__ for di in a.detailed_issues]
                            if a.detailed_issues
                            else []
                        ),
                        "notebook_metadata_json": json.dumps(a.notebook_metadata or {}),
                        "spark_configurations_json": json.dumps(
                            a.spark_configurations or {}
                        ),
                    })

                cfg = PublishConfig(
                    catalog=getattr(parsed_args, "catalog", "main"),
                    schema=getattr(parsed_args, "schema", "serverless_reports"),
                    warehouse_id=getattr(parsed_args, "warehouse_id", None),
                )
                publisher = AnalysisPublisher(cfg, logger=self.logger)
                # User-facing progress regardless of verbose
                dataset_fq = f"{cfg.catalog}.{cfg.schema}.{cfg.dataset_table_name}"
                detailed_fq = f"{cfg.catalog}.{cfg.schema}.{cfg.detailed_table_name}"
                total_detail = len(detailed_rows)
                print(
                    self.output_formatter.format_info(
                        f"Publishing to catalog.schema: {cfg.catalog}.{cfg.schema}"
                    )
                )
                try:
                    print(
                        self.output_formatter.format_info(
                            f"Using SQL Warehouse: {publisher.warehouse_id}"
                        )
                    )
                except Exception:
                    pass
                print(
                    self.output_formatter.format_info(
                        f"Dataset table: {dataset_fq}; Detailed table: {detailed_fq}"
                    )
                )
                report_service.publish_to_unity_catalog = True  # type: ignore[attr-defined]
                print(
                    self.output_formatter.format_info(
                        f"Publishing dataset summary to {dataset_fq}"
                    )
                )
                publisher.publish_dataset_summary(report_dict)
                print(self.output_formatter.format_info("Dataset summary published."))
                if not getattr(parsed_args, "no_detailed", False):
                    print(
                        self.output_formatter.format_info(
                            f"Publishing {total_detail} detailed rows to {detailed_fq}"
                        )
                    )
                    publisher.publish_notebook_detailed(detailed_rows)
                    print(self.output_formatter.format_info("Detailed rows published."))

            return 0

        except KeyboardInterrupt:
            print(self.output_formatter.format_error("Analysis interrupted by user"))
            return 1
        except Exception as e:
            print(self.output_formatter.format_error(f"Unexpected error: {e}"))
            if parsed_args.verbose if "parsed_args" in locals() else False:
                import traceback

                traceback.print_exc()
            return 1

    def _analyze_notebooks(
        self, analysis_service: AnalysisService, args: argparse.Namespace
    ) -> List[ServerlessAnalysis]:
        """Analyze notebooks based on the provided path."""
        raw_path = args.notebook_path
        # If workspace-like path (with --databricks forcing), bypass local Path checks
        if analysis_service._is_workspace_path(str(raw_path)):
            path_str = str(raw_path)
            # Heuristic: treat as file if it looks like a notebook file
            notebook_exts = (".py", ".sql", ".scala", ".r", ".ipynb")
            is_file_like = any(path_str.lower().endswith(ext) for ext in notebook_exts)
            if args.verbose:
                print(
                    self.output_formatter.format_info(
                        f"Analyzing workspace {'file' if is_file_like else 'directory'}: {path_str}"
                    )
                )
            if is_file_like:
                return [analysis_service.analyze_notebook(path_str)]
            return analysis_service.analyze_directory(path_str)

        # Local filesystem behavior
        path = Path(raw_path)

        if not path.exists():
            print(self.output_formatter.format_error(f"Path does not exist: {path}"))
            return []

        if path.is_file():
            # Single file analysis
            if args.verbose:
                print(
                    self.output_formatter.format_info(f"Analyzing single file: {path}")
                )
            return [analysis_service.analyze_notebook(path)]
        else:
            # Directory analysis
            if args.verbose:
                print(self.output_formatter.format_info(f"Analyzing directory: {path}"))
            return analysis_service.analyze_directory(path)

    def _resolve_output_dir_from_args(self, args: argparse.Namespace) -> Optional[Path]:
        """Resolve a directory to write outputs. Prefer --output-dir, else parent of --output."""
        if getattr(args, "output_dir", None):
            return Path(args.output_dir)
        if getattr(args, "output", None):
            return Path(args.output).parent
        return None


def main() -> int:
    """Main entry point for the CLI."""
    runner = CLIRunner()
    return runner.run()


if __name__ == "__main__":
    sys.exit(main())
