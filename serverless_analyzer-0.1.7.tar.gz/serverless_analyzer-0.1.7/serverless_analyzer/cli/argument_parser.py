"""
Argument parser for serverless analyzer CLI.
"""

import argparse
from typing import List, Optional
import importlib.metadata as importlib_metadata


class ArgumentParser:
    """Handles command-line argument parsing for the serverless analyzer."""

    def __init__(self) -> None:
        self.parser = self._create_parser()

    def _create_parser(self) -> argparse.ArgumentParser:
        """Create the argument parser with all options."""
        parser = argparse.ArgumentParser(
            prog="serverless-analyze",
            description="Analyze Databricks notebooks for serverless compatibility",
            formatter_class=argparse.RawDescriptionHelpFormatter,
            add_help=False,
            usage="serverless-analyze [options] notebook_path",
        )

        # Version flag that works without positional args
        try:
            version_str = importlib_metadata.version("serverless-analyzer")
        except Exception:
            version_str = "unknown"
        # We'll add version into Misc group further below

        # Argument groups for contextual help
        analyze_group = parser.add_argument_group("Analyze")
        export_group = parser.add_argument_group("Export")
        publish_group = parser.add_argument_group("Publish (Export: tables)")
        queries_group = parser.add_argument_group("Queries")
        deprecated_group = parser.add_argument_group("Deprecated")
        misc_group = parser.add_argument_group("Misc")

        # Custom contextual help action
        class ContextualHelpAction(argparse.Action):
            def __call__(
                self,
                parser: argparse.ArgumentParser,
                namespace: argparse.Namespace,
                values: object,
                option_string: Optional[str] = None,
            ) -> None:
                export_val = getattr(namespace, "export", None)
                fmt = parser._get_formatter()

                # Minimal usage
                fmt.add_text("Usage: serverless-analyze [options] notebook_path\n\n")

                if export_val is None:
                    # Quick start
                    fmt.add_text("Quick start:\n")
                    fmt.add_text("  serverless-analyze nb.py\n")
                    fmt.add_text(
                        "  serverless-analyze dir/ --export json --output-dir out/\n"
                    )
                    fmt.add_text(
                        "  serverless-analyze dir/ --export tables --catalog main --schema reports\n\n"
                    )

                    # Core options
                    fmt.add_text("Core options:\n")
                    core_actions = [
                        export_action,
                        output_dir_action,
                        databricks_action,
                        scala_as_jar_action,
                        skip_checks_action,
                        verbose_action,
                    ]
                    fmt.add_arguments(core_actions)
                    fmt.add_text("\n")

                    # Misc options
                    fmt.add_text("Misc options:\n")
                    misc_actions = [list_checks_action]
                    fmt.add_arguments(misc_actions)
                    fmt.add_text(
                        "\nHint: Add '--export json|csv|tables' then '-h' for mode-specific options.\n\n"
                    )

                elif export_val == "tables":
                    # Export (publish) options
                    fmt.add_text("Export (tables):\n")
                    fmt.add_arguments(publish_actions)
                    fmt.add_text("\n")
                    # Common export options
                    fmt.add_text("Common export options:\n")
                    common_actions = [output_dir_action]
                    fmt.add_arguments(common_actions)
                    fmt.add_text("\n")

                else:
                    # Export json/csv common options only
                    fmt.add_text(f"Export ({export_val}):\n")
                    common_actions = [output_dir_action]
                    fmt.add_arguments(common_actions)
                    fmt.add_text("\n")

                parser._print_message(fmt.format_help())
                parser.exit(0)

        # Re-add -h/--help using contextual action
        misc_group.add_argument(
            "-h",
            "--help",
            action=ContextualHelpAction,
            nargs=0,
            help="Show this help message and exit (contextual to --export)",
        )

        # Required arguments (optional when using --list-checks)
        analyze_group.add_argument(
            "notebook_path",
            nargs="?",  # Make it optional
            help="Path to notebook file or directory containing notebooks to analyze",
        )

        # Optional arguments
        analyze_group.add_argument(
            "-o",
            "--output",
            help="DEPRECATED: Output file path. Use --output-dir instead.",
        )

        output_dir_action = export_group.add_argument(
            "--output-dir",
            help="Directory to write the analysis reports to (both consolidated and individual notebook reports)",
        )

        verbose_action = analyze_group.add_argument(
            "-v",
            "--verbose",
            action="store_true",
            help="Enable verbose output with detailed logging",
        )

        databricks_action = analyze_group.add_argument(
            "--databricks",
            action="store_true",
            help="Enable Databricks workspace integration (to run on Databricks Environment)",
        )

        # Publishing options
        deprecated_group.add_argument(
            "--publish-tables",
            action="store_true",
            help="DEPRECATED: Use --export tables to publish to Unity Catalog",
        )
        catalog_action = publish_group.add_argument(
            "--catalog",
            default="main",
            help="Target Unity Catalog catalog for publishing (default: main)",
        )
        schema_action = publish_group.add_argument(
            "--schema",
            default="serverless_reports",
            help="Target Unity Catalog schema for publishing (default: serverless_reports)",
        )
        warehouse_id_action = publish_group.add_argument(
            "--warehouse-id",
            default=None,
            help="SQL Warehouse ID to use for publishing (default: auto-detect)",
        )
        no_detailed_action = publish_group.add_argument(
            "--no-detailed",
            action="store_true",
            help="Publish only dataset summary table, skip detailed table",
        )
        publish_actions = [
            catalog_action,
            schema_action,
            warehouse_id_action,
            no_detailed_action,
        ]

        queries_group.add_argument(
            "--generate-queries",
            action="store_true",
            help="Generate system table queries for workspace analysis",
        )

        scala_as_jar_action = analyze_group.add_argument(
            "--scala-as-jar",
            action="store_true",
            help="Treat Scala files as JAR compilation targets (overrides auto-detection of JAR indicators)",
        )

        deprecated_group.add_argument(
            "--format",
            choices=["json", "summary"],
            default="json",
            help="DEPRECATED: Output formatting selection. Use --export or default stdout summary.",
        )

        # Unified export target (new)
        export_action = export_group.add_argument(
            "--export",
            choices=["json", "csv", "tables"],
            default=None,
            help="Select export target: json files, csv files, or publish to Unity Catalog tables",
        )

        analyze_group.add_argument(
            "--include-metadata",
            action="store_true",
            help="Include detailed workspace metadata in the report",
        )

        analyze_group.add_argument(
            "--max-file-size",
            type=int,
            default=10485760,  # 10MB
            help="Maximum file size to analyze in bytes (default: 10485760)",
        )

        analyze_group.add_argument(
            "--recursive",
            action="store_true",
            help="Recursively analyze all notebooks in subdirectories",
        )

        skip_checks_action = analyze_group.add_argument(
            "--skip-checks",
            help="Comma-separated list of checks to skip (e.g., performance_concerns,driver_actions). "
            "Skipped checks will be detected but marked as skipped in reports.",
        )

        list_checks_action = misc_group.add_argument(
            "--list-checks",
            action="store_true",
            help="List all available check names and exit",
        )

        misc_group.add_argument(
            "-V",
            "--version",
            action="version",
            version=f"serverless-analyze {version_str}",
            help="Show program's version number and exit",
        )

        return parser

    def parse_args(self, args: Optional[List[str]] = None) -> argparse.Namespace:
        """Parse command-line arguments."""
        return self.parser.parse_args(args)

    def print_help(self) -> str:
        """Print help message."""
        return self.parser.format_help()

    def validate_args(self, args: argparse.Namespace) -> List[str]:
        """Validate parsed arguments and return any errors."""
        errors = []

        # Validate notebook path (not required for --list-checks or --version)
        if not args.notebook_path and not getattr(args, "list_checks", False):
            errors.append("Notebook path is required")

        # Validate output path if provided
        if args.output:
            try:
                from pathlib import Path

                output_path = Path(args.output)
                if output_path.exists() and not output_path.is_file():
                    errors.append(
                        f"Output path exists but is not a file: {args.output}"
                    )
            except Exception as e:
                errors.append(f"Invalid output path: {args.output} - {e}")

        # Validate output directory if provided
        if args.output_dir:
            try:
                from pathlib import Path

                output_dir = Path(args.output_dir)
                if output_dir.exists() and not output_dir.is_dir():
                    errors.append(
                        f"Output directory exists but is not a directory: {args.output_dir}"
                    )
                elif not output_dir.exists():
                    # Try to create it
                    try:
                        output_dir.mkdir(parents=True, exist_ok=True)
                    except Exception as e:
                        errors.append(
                            f"Cannot create output directory: {args.output_dir} - {e}"
                        )
            except Exception as e:
                errors.append(f"Invalid output directory: {args.output_dir} - {e}")

        # Validate that both output and output-dir are not specified together
        if args.output and args.output_dir:
            errors.append("Cannot specify both --output and --output-dir. Choose one.")

        # Validate max file size
        if args.max_file_size <= 0:
            errors.append("Maximum file size must be positive")

        # Validate publishing options (legacy --publish-tables or new --export=tables)
        if (
            getattr(args, "publish_tables", False)
            or getattr(args, "export", None) == "tables"
        ):
            import os
            import re

            ident_re = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
            if not ident_re.match(str(getattr(args, "catalog", ""))):
                errors.append(
                    f"Invalid catalog name: {getattr(args, 'catalog', '')}. Use letters, digits, and underscores, starting with a letter/underscore."
                )
            if not ident_re.match(str(getattr(args, "schema", ""))):
                errors.append(
                    f"Invalid schema name: {getattr(args, 'schema', '')}. Use letters, digits, and underscores, starting with a letter/underscore."
                )

            wid = getattr(args, "warehouse_id", None)
            if wid is not None and str(wid).strip() == "":
                errors.append("--warehouse-id cannot be empty when provided")

            # Validate Databricks environment
            host = os.getenv("DATABRICKS_HOST")
            token = os.getenv("DATABRICKS_TOKEN")
            profile = os.getenv("DATABRICKS_CONFIG_PROFILE")
            sdk_ok = True
            try:
                from databricks.sdk import WorkspaceClient as _SDKClient  # noqa: F401

                _ = _SDKClient  # silence unused
            except Exception:
                sdk_ok = False

            if not (profile or (host and token and sdk_ok)):
                errors.append(
                    "Databricks environment not configured for publishing. Set DATABRICKS_CONFIG_PROFILE, or DATABRICKS_HOST and DATABRICKS_TOKEN, and install databricks-sdk."
                )

        # Validate CSV export requirements
        if getattr(args, "export", None) == "csv":
            has_dest = bool(
                getattr(args, "output_dir", None) or getattr(args, "output", None)
            )
            if not has_dest:
                errors.append(
                    "CSV export requires --output-dir or --output (to derive directory)"
                )

        # Validate skip-checks
        if getattr(args, "skip_checks", None):
            from ..config.skip_config import SkipConfig

            skip_list = [s.strip() for s in args.skip_checks.split(",")]
            skip_config = SkipConfig(skip_list)
            validation_errors = skip_config.validate()
            errors.extend(validation_errors)

        return errors
