"""
Workspace client for Databricks workspace operations.
"""

from __future__ import annotations

import base64
import os
from typing import Optional, List, Any, Dict, Iterator

from ..models.metadata import WorkspaceMetadata


class WorkspaceClient:
    """Handles Databricks workspace operations."""

    def __init__(self, logger: Any | None = None) -> None:
        self.logger = logger
        self._client: Optional[Any] = None
        self._is_databricks_env = self._detect_databricks_environment()

    def _detect_databricks_environment(self) -> bool:
        """Detect if usable Databricks configuration is available.
        Returns True if a profile is set, or HOST+TOKEN are set with SDK available.
        """
        try:
            host = os.getenv("DATABRICKS_HOST")
            token = os.getenv("DATABRICKS_TOKEN")
            profile = os.getenv("DATABRICKS_CONFIG_PROFILE")

            # If a profile is configured, consider env detected regardless of SDK import here
            if profile:
                return True

            # Otherwise require SDK and host+token
            try:
                from databricks.sdk import WorkspaceClient as _SDKClient  # noqa: F401

                sdk_available = True
            except Exception:
                sdk_available = False

            return bool(host and token and sdk_available)
        except Exception:
            return False

    def get_workspace_client(self) -> Optional[Any]:
        """Get a Databricks WorkspaceClient if available and configured."""
        if self._client is not None:
            return self._client

        try:
            from databricks.sdk import WorkspaceClient as _SDKClient

            self._client = _SDKClient()
            return self._client
        except Exception as e:
            if self.logger:
                self.logger.warning(
                    f"Failed to initialize Databricks WorkspaceClient: {e}"
                )
            return None

    def _normalize_workspace_path(self, path: str) -> str:
        """Normalize workspace paths for SDK calls.

        SDK expects paths like "/Users/..." not "/Workspace/Users/...".
        """
        try:
            if isinstance(path, str) and path.startswith("/Workspace/"):
                # Strip only the "/Workspace" prefix, keep leading slash for SDK
                return "/" + path[len("/Workspace/") :]
        except Exception:
            pass
        return path

    def get_notebook_metadata(self, notebook_path: str) -> Optional[WorkspaceMetadata]:
        """Get metadata for a notebook from the workspace."""
        client: Any = self.get_workspace_client()
        if not client:
            return None

        try:
            # SDK types are optional; use getattr with defaults for resilience
            ws_path = self._normalize_workspace_path(notebook_path)
            info = client.workspace.get_status(ws_path)

            def _get(obj: Any, name: str, default: Any | None = None) -> Any:
                try:
                    return getattr(obj, name)
                except Exception:
                    return default

            # Convert enums safely to strings if present
            object_type = _get(info, "object_type")
            if object_type is not None:
                object_type = getattr(object_type, "value", str(object_type))

            language = _get(info, "language")
            if language is not None:
                language = getattr(language, "value", str(language))

            workspace_url = os.getenv("DATABRICKS_HOST")

            return WorkspaceMetadata(
                object_id=_get(info, "object_id"),
                object_type=object_type,
                path=_get(info, "path", notebook_path),
                language=language,
                size=_get(info, "size"),
                created_at=_get(info, "created_at"),
                modified_at=_get(info, "modified_at"),
                created_by=_get(info, "created_by"),
                modified_by=_get(info, "modified_by"),
                object_name=_get(info, "object_name"),
                parent_path=_get(info, "parent_path"),
                is_dir=str(object_type).upper() == "DIRECTORY" if object_type else None,
                workspace_url=workspace_url,
            )
        except Exception as e:
            if self.logger:
                self.logger.warning(f"Failed to get metadata for {notebook_path}: {e}")
            return None

    def list_workspace_paths(self, path: str) -> List[str]:
        """List paths in a workspace directory."""
        client: Any = self.get_workspace_client()
        if not client:
            return []

        try:
            # list returns an iterator of ObjectInfo
            ws_path = self._normalize_workspace_path(path)
            results = client.workspace.list(ws_path)
            paths: List[str] = []
            for item in results:
                try:
                    p = getattr(item, "path", None)
                    if not p:
                        continue
                    obj_type = getattr(item, "object_type", None)
                    # If SDK provides enum-like, get its value string
                    try:
                        obj_type_val = (
                            getattr(obj_type, "value", str(obj_type))
                            if obj_type is not None
                            else ""
                        )
                    except Exception:
                        obj_type_val = str(obj_type)
                    if str(obj_type_val).upper() == "DIRECTORY" and not p.endswith("/"):
                        p = p + "/"
                    paths.append(p)
                except Exception:
                    continue
            return paths
        except Exception as e:
            if self.logger:
                self.logger.warning(f"Failed to list workspace paths for {path}: {e}")
            return []

    def list_workspace_objects(self, path: str) -> List[Dict[str, str]]:
        """List objects in a workspace directory with their object types.

        Returns list of {"path": str, "object_type": str}
        """
        client: Any = self.get_workspace_client()
        if not client:
            return []

        try:
            ws_path = self._normalize_workspace_path(path)
            results = client.workspace.list(ws_path)
            objects: List[Dict[str, str]] = []
            for item in results:
                try:
                    p = getattr(item, "path", None)
                    if not p:
                        continue
                    obj_type = getattr(item, "object_type", None)
                    # Normalize enum-like to string
                    try:
                        obj_type_val = (
                            getattr(obj_type, "value", str(obj_type))
                            if obj_type is not None
                            else ""
                        )
                    except Exception:
                        obj_type_val = str(obj_type)
                    objects.append({"path": p, "object_type": str(obj_type_val)})
                except Exception:
                    continue
            return objects
        except Exception as e:
            if self.logger:
                self.logger.warning(f"Failed to list workspace objects for {path}: {e}")
            return []

    def iter_workspace_files(self, root_path: str) -> Iterator[str]:
        """Recursively yield all file paths under a workspace root.

        Treat NOTEBOOK/FILE as files; DIRECTORY/REPO as folders to traverse.
        """
        stack: List[str] = [root_path]
        while stack:
            current = stack.pop()
            for obj in self.list_workspace_objects(current):
                p = obj.get("path") or ""
                t = (obj.get("object_type") or "").upper()
                if t in {"NOTEBOOK", "FILE"}:
                    yield p
                elif t in {"DIRECTORY", "REPO"}:
                    stack.append(p)

    def read_notebook_content(self, notebook_path: str) -> Optional[str]:
        """Read notebook content from workspace using SOURCE export."""
        client: Any = self.get_workspace_client()
        if not client:
            return None

        try:
            # Always export as SOURCE for simplicity
            from databricks.sdk.service.workspace import ExportFormat

            if self.logger:
                self.logger.info(f"Notebook path: {notebook_path}")
            ws_path = self._normalize_workspace_path(notebook_path)
            if self.logger:
                self.logger.info(f"Normalized workspace path: {ws_path}")
            resp = client.workspace.export(ws_path, format=ExportFormat.SOURCE)

            # Possible return shapes:
            # - bytes/str content directly
            # - object with `.content` (base64-encoded)
            # - dict with 'content' (base64-encoded)
            if self.logger:
                self.logger.info(f"resp: {resp}")
            if isinstance(resp, bytes):
                try:
                    if self.logger:
                        try:
                            self.logger.info(f"resp is bytes: {resp.decode('utf-8')}")
                        except Exception:
                            pass
                    return resp.decode("utf-8")
                except Exception:
                    return resp.decode("latin-1", errors="ignore")
            if isinstance(resp, str):
                if self.logger:
                    self.logger.info(f"resp is str: {resp}")
                return resp

            content = None
            if hasattr(resp, "content"):
                if self.logger:
                    try:
                        self.logger.info(
                            f"resp has content: {getattr(resp, 'content')}"
                        )
                    except Exception:
                        pass
                content = getattr(resp, "content")
            elif isinstance(resp, dict):
                content = resp.get("content")

            if content is None:
                return None

            # content is typically base64-encoded
            try:
                decoded = base64.b64decode(content)
                text = decoded.decode("utf-8", errors="ignore")
            except Exception:
                # If not base64, return as-is
                if isinstance(content, bytes):
                    text = content.decode("utf-8", errors="ignore")
                else:
                    text = str(content)

            return text
        except Exception as e:
            if self.logger:
                self.logger.warning(
                    f"Failed to read notebook content for {notebook_path}: {e}"
                )
            return None

    def is_workspace_path(self, path: str) -> bool:
        """Check if a path is a Databricks workspace path.

        Include '/Users/' only when a Databricks environment is configured to avoid
        misclassifying local macOS paths. Otherwise require explicit workspace prefixes.
        """
        if not (isinstance(path, str) and path.startswith("/")):
            return False
        prefixes = ["/Workspace/", "/Repos/", "/Shared/"]
        # Guard '/Users/' behind detected Databricks env to avoid macOS local '/Users/...'
        if getattr(self, "_is_databricks_env", False):
            prefixes.append("/Users/")
        return any(path.startswith(prefix) for prefix in prefixes)
