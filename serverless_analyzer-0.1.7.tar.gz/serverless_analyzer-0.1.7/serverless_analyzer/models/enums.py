"""
Enums for serverless analyzer.
"""

from enum import Enum


class ComplexityLevel(Enum):
    """Complexity levels for notebook analysis."""

    LOW = "Low"
    MEDIUM = "Medium"
    HIGH = "High"
    EXTREME = "Extreme"

    def __str__(self) -> str:
        return self.value
