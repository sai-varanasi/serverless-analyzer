"""
Analysis models for serverless analyzer.
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
from .enums import ComplexityLevel
from .issues import IssueDetail
from .metadata import WorkspaceMetadata


@dataclass
class ServerlessAnalysis:
    """Contains notebook analysis results."""

    notebook_path: str
    is_compatible: bool
    complexity: ComplexityLevel
    issues: List[Dict[str, str]] = field(default_factory=list)
    required_changes: List[Dict[str, str]] = field(default_factory=list)
    performance_impacts: List[Dict[str, str]] = field(default_factory=list)
    recommendations: List[str] = field(default_factory=list)
    code_snippets: Dict[str, List[str]] = field(default_factory=dict)
    language_support: Dict[str, bool] = field(default_factory=dict)
    api_support: Dict[str, bool] = field(default_factory=dict)
    data_source_support: Dict[str, bool] = field(default_factory=dict)
    streaming_support: Dict[str, bool] = field(default_factory=dict)
    ml_support: Dict[str, bool] = field(default_factory=dict)
    caching_support: Dict[str, bool] = field(default_factory=dict)
    hive_support: Dict[str, bool] = field(default_factory=dict)
    issue_counts: Dict[str, int] = field(default_factory=dict)
    complexity_factors: Dict[str, Any] = field(default_factory=dict)
    migration_effort: Dict[str, Any] = field(default_factory=dict)
    detailed_issues: List[IssueDetail] = field(default_factory=list)
    analysis_timestamp: str = ""
    notebook_metadata: Dict[str, Any] = field(default_factory=dict)
    spark_configurations: Dict[str, List[Dict[str, Any]]] = field(default_factory=dict)


@dataclass
class ConsolidatedReport:
    """Summary of multiple notebook analysis results."""

    analysis_timestamp: str = ""
    total_notebooks: int = 0
    compatible_notebooks: int = 0
    incompatible_notebooks: int = 0
    complexity_distribution: Dict[str, int] = field(default_factory=dict)
    issue_distribution: Dict[str, int] = field(default_factory=dict)
    total_migration_effort: int = 0
    notebook_reports: List[Dict[str, Any]] = field(default_factory=list)
    summary: Dict[str, Any] = field(default_factory=dict)
    all_spark_configurations: Dict[str, List[Dict[str, Any]]] = field(
        default_factory=dict
    )
    workspace_metadata: Optional[Dict[str, WorkspaceMetadata]] = None
    system_table_queries: Optional[Dict[str, str]] = None
    # Total number of skipped issues across all notebooks (reported separately)
    skipped_issues_total: int = 0
