"""
Pattern definitions for serverless analyzer.
"""

# Define patterns for various checks
PATTERNS = {
    "unsupported_languages": {"scala": r"%scala|\.scala$", "r": r"%r|\.r$"},
    "jar_compilation_indicators": {
        "main_method": r"def\s+main\s*\(args:\s*Array\[String\]\)",
        "object_declaration": r"object\s+\w+\s*\{",
        "package_declaration": r"package\s+\w+",
        "import_scala_collection": r"import\s+scala\.collection",
        "case_class": r"case\s+class\s+\w+",
        "trait_declaration": r"trait\s+\w+",
        "extends_app": r"extends\s+App",
        "extends_application": r"extends\s+Application",
    },
    "unsupported_apis": {
        "rdd": r"\.rdd|\.parallelize|\.textFile",
        "spark_context": r"sc\.|spark\.sparkContext|sqlContext",
        "global_temp_views": r"createGlobalTempView|createOrReplaceGlobalTempView",
        "timeout_settings": r"spark\.databricks\.execution\.timeout",
        "unsupported_formats": r"\.format\([\'\"](?!avro|binaryfile|csv|delta|json|kafka|orc|parquet|text|xml)[^\'\"]+[\'\"]\)",
        "large_rows": r"spark\.databricks\.io\.parquet\.maxRowSize|spark\.databricks\.delta\.maxRowSize",
    },
    "unsupported_commands": {
        "hive_variables": r"\${env:|${configName}|${system:|spark\.sql\.variable"
    },
    "unsupported_caching": {
        "cache_apis": r"\.cache\(|\.persist\(|\.unpersist\(|spark\.catalog\.cacheTable|spark\.catalog\.uncacheTable|spark\.catalog\.clearCache",
        "cache_commands": r"CACHE TABLE|UNCACHE TABLE|REFRESH TABLE|CLEAR CACHE",
    },
    "performance_concerns": {
        "large_operations": r"\.toPandas\(",
        "driver_actions": r"\.collect\(|\.toLocalIterator\(",
        "complex_operations": r"\.window\(",  # Only window operations are currently matched. Note: join and groupBy operations may also have performance implications.
        "long_running": r"\.foreach\(|\.foreachPartition\(|\.mapPartitions\(",
    },
    "unsupported_data_sources": {
        "hive_serde": r"STORED AS SERDE|ROW FORMAT SERDE",
        "unsupported_formats": r"\.format\([\'\"](?!(?:avro|binaryfile|csv|delta|json|kafka|orc|parquet|text|xml)[\'\"])[^\'\"]+[\'\"]\)",
    },
    "streaming_limitations": {
        "unsupported_triggers": r"Trigger\.ProcessingTime|Trigger\.Once|Trigger\.Continuous",
        "supported_triggers": r"Trigger\.AvailableNow",
    },
    "ml_limitations": {
        "unsupported_ml": r"from pyspark\.ml|from pyspark\.mllib|\.fit\(|\.transform\(",
        "gpu_usage": r"\.gpu|\.cuda",
    },
    "dbfs_limitations": {"mounts": r"dbutils\.fs\.mount|dbutils\.fs\.mounts"},
    "udf_limitations": {
        "internet_access": r"CREATE\s+FUNCTION\s*\(\s*External\s*\)|http\.client|requests\.|urllib\.|socket\."
    },
    # SQL-specific patterns
    "sql_unsupported_apis": {
        "create_external_function": r"CREATE\s+(?:OR\s+REPLACE\s+)?FUNCTION\s+[\w\.]+\s*\([^)]*\)\s+RETURNS\s+[^;]+\s+USING\s+JAR",
        "global_temp_view_sql": r"CREATE\s+(?:OR\s+REPLACE\s+)?GLOBAL\s+(?:TEMPORARY\s+|TEMP\s+)?VIEW",
        "serde_sql": r"STORED\s+AS\s+(?:INPUTFORMAT|OUTPUTFORMAT)|ROW\s+FORMAT\s+SERDE|SERDEPROPERTIES",
        "hive_udfs": r"reflect\s*\(|java_method\s*\(|named_struct\s*\(",
        "refresh_table": r"\bREFRESH\s+TABLE\b",
    },
    #  SQL commands
    "sql_unsupported_commands": {
        "msck_repair": r"MSCK\s+REPAIR\s+TABLE",
        "analyze_compute_stats": r"ANALYZE\s+TABLE\s+[\w\.]+\s+COMPUTE\s+STATISTICS",
        "hive_variables_sql": r"SET\s+hive\.|SET\s+hivevar:|SET\s+hiveconf:",
        "jdbc_reads": r"USING\s+(?:JDBC|org\.apache\.spark\.sql\.jdbc)",
    },
    #  caching for SQL
    "sql_unsupported_caching": {
        "cache_lazy_sql": r"CACHE\s+LAZY\s+TABLE",
        "cache_select_sql": r"CACHE\s+TABLE\s+[\w\.]+\s+(?:OPTIONS|AS\s+SELECT)",
        "cache_storage_level": r"CACHE\s+TABLE\s+[\w\.]+\s+STORAGELEVEL",
    },
}
