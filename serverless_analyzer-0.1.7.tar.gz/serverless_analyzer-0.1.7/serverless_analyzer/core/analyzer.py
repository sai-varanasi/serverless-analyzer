# mypy: disable-error-code=unreachable
"""
Main compatibility analyzer for serverless analyzer.
"""

import re
from datetime import datetime
from typing import List, Dict, Any, Tuple, Union, Optional
from ..models.analysis import ServerlessAnalysis
from ..models.issues import IssueDetail
from ..config.constants import SUPPORTED_SPARK_CONFIGS
from .patterns import PatternMatcher
from .language_detector import LanguageDetector
from .complexity import ComplexityCalculator
from .comment_filters import filter_comments_with_mapping


class CompatibilityAnalyzer:
    """Main analyzer for Databricks Serverless compatibility."""

    def __init__(
        self, scala_as_jar: bool = False, skip_checks: Optional[List[str]] = None
    ):
        self.scala_as_jar = scala_as_jar
        self.skip_checks = skip_checks

        # Create skip config if skip_checks provided
        self.skip_config = None
        if skip_checks:
            from ..config.skip_config import SkipConfig

            self.skip_config = SkipConfig(skip_checks)

        self.pattern_matcher = PatternMatcher(skip_config=self.skip_config)
        self.language_detector = LanguageDetector()
        self.complexity_calculator = ComplexityCalculator()

    def analyze_notebook_from_content(
        self, content: str, notebook_path: str = "test_notebook"
    ) -> ServerlessAnalysis:
        """Analyze notebook content directly without reading from file."""
        content_lines = content.splitlines()

        # Detect language from content
        detected_language = self.language_detector.detect_language_from_content(
            content, notebook_path
        )

        # Filter out commented lines and build original line mapping
        filtered_content_lines, line_number_map = filter_comments_with_mapping(
            content_lines, detected_language
        )

        # Create basic metadata
        notebook_metadata = {
            "path": notebook_path,
            "language": detected_language,
            "format": "content",
            "total_lines": len(content_lines),
            "non_empty_lines": sum(1 for line in content_lines if line.strip()),
            "imports": [],
            "dependencies": [],
        }

        # Extract imports and dependencies
        imports_list: List[str] = []
        notebook_metadata["imports"] = imports_list
        # Only capture Python-style imports. Require 'from X import Y' to avoid SQL 'FROM table'.
        import_pattern = re.compile(
            r"^(?:from\s+([A-Za-z_][\w\.]*)\s+import\b|import\s+([A-Za-z_][\w\.]*))"
        )
        for line in filtered_content_lines:
            match = import_pattern.match(line)
            if match:
                module = (match.group(1) or match.group(2)) or ""
                if module and module not in imports_list:
                    imports_list.append(module)

        # Continue with the analysis logic
        return self._analyze_content(
            filtered_content_lines,
            detected_language,
            notebook_metadata,
            notebook_path,
            line_number_map,
        )

    def _analyze_content(
        self,
        filtered_content_lines: List[str],
        detected_language: str,
        notebook_metadata: Dict[str, Any],
        notebook_path: str,
        line_number_map: List[int],
    ) -> ServerlessAnalysis:
        """Analyze filtered content for serverless compatibility."""
        # Track issues and recommendations
        issues: List[Dict[str, str]] = []
        required_changes: List[Dict[str, str]] = []
        performance_impacts: List[Dict[str, str]] = []
        recommendations: List[str] = []
        detailed_issues: List[IssueDetail] = []
        code_snippets: Dict[str, List[str]] = {
            "unsupported_languages": [],
            "unsupported_apis": [],
            "unsupported_commands": [],
            "unsupported_caching": [],
            "performance_concerns": [],
            "unsupported_data_sources": [],
            "streaming_limitations": [],
            "ml_limitations": [],
            "dbfs_limitations": [],
            "udf_limitations": [],
        }

        # Initialize issue counts
        issue_counts: Dict[str, int] = {
            "language_issues": 0,
            "api_issues": 0,
            "command_issues": 0,
            "caching_issues": 0,
            "data_source_issues": 0,
            "streaming_issues": 0,
            "ml_issues": 0,
            "hive_issues": 0,
            "performance_issues": 0,
            "dbfs_issues": 0,
            "udf_issues": 0,
        }

        # Initialize complexity factors
        complexity_factors: Dict[str, Any] = (
            self.complexity_calculator.calculate_complexity_factors(
                filtered_content_lines
            )
        )

        # Initialize support dictionaries
        language_support: Dict[str, bool] = {
            "python": True,
            "sql": True,
            "scala": False if detected_language in ["scala", "scala_jar"] else True,
            "r": False if detected_language == "r" else True,
        }

        # Handle language-specific logic
        if detected_language and detected_language.lower() in [
            "scala",
            "scala_jar",
            "r",
        ]:
            if detected_language.lower() in ["scala", "scala_jar"]:
                is_jar_compilation = self.language_detector.is_jar_compilation(
                    "\n".join(filtered_content_lines),
                    detected_language,
                    self.scala_as_jar,
                )

                if is_jar_compilation:
                    language_support["scala"] = True
                    detailed_issues.append(
                        IssueDetail(
                            type="Scala JAR Compilation",
                            description="Scala code will be compiled to JAR for serverless execution"
                            + (
                                " (explicitly specified)"
                                if self.scala_as_jar
                                else " (auto-detected)"
                            ),
                            line_number=1,
                            code_snippet=f"Notebook language: {detected_language} (JAR mode)",
                            severity="Info",
                            impact="None - Code will be compiled to JAR",
                            recommendation="Ensure JAR is properly configured for Databricks Jobs",
                            affected_apis=["Scala Compilation"],
                            related_issues=["JAR Deployment"],
                        )
                    )
                else:
                    language_support["scala"] = False
                    issue_counts["language_issues"] += 1
                    detailed_issues.append(
                        IssueDetail(
                            type="Unsupported Language",
                            description=f"{detected_language.upper()} is not supported in serverless compute",
                            line_number=1,
                            code_snippet=f"Notebook language: {detected_language}",
                            severity="High",
                            impact="Critical - Language must be changed",
                            recommendation=f"Convert {detected_language.upper()} code to Python or SQL",
                            affected_apis=[detected_language],
                            related_issues=["Language Migration"],
                        )
                    )
            else:
                # Handle R language (always unsupported)
                language_support[detected_language.lower()] = False
                issue_counts["language_issues"] += 1
                detailed_issues.append(
                    IssueDetail(
                        type="Unsupported Language",
                        description=f"{detected_language.upper()} is not supported in serverless compute",
                        line_number=1,
                        code_snippet=f"Notebook language: {detected_language}",
                        severity="High",
                        impact="Critical - Language must be changed",
                        recommendation=f"Convert {detected_language.upper()} code to Python or SQL",
                        affected_apis=[detected_language],
                        related_issues=["Language Migration"],
                    )
                )

        # Initialize other support dictionaries
        (
            api_support,
            caching_support,
            data_source_support,
            streaming_support,
            ml_support,
            hive_support,
            dbfs_support,
            udf_support,
        ) = self._init_support_flags()

        # Continue with pattern checks
        filtered_content = "\n".join(filtered_content_lines)

        # Check for unsupported APIs
        api_issues = self.pattern_matcher.check_unsupported_apis(
            filtered_content_lines, line_number_map
        )
        detailed_issues.extend(api_issues)
        issue_counts["api_issues"] += len(api_issues)

        # Check for unsupported commands
        command_issues = self.pattern_matcher.check_unsupported_commands(
            filtered_content_lines, line_number_map
        )
        detailed_issues.extend(command_issues)
        issue_counts["command_issues"] += len(command_issues)

        # Check for unsupported caching
        caching_issues = self.pattern_matcher.check_unsupported_caching(
            filtered_content_lines, line_number_map
        )
        detailed_issues.extend(caching_issues)
        issue_counts["caching_issues"] += len(caching_issues)

        # Check for performance concerns and
        performance_issues = self.pattern_matcher.check_performance_concerns(
            filtered_content_lines, line_number_map
        )
        detailed_issues.extend(performance_issues)
        issue_counts["performance_issues"] += len(performance_issues)

        # Check for SQL issues
        sql_issues = self.pattern_matcher.check_sql_issues(
            filtered_content_lines, line_number_map
        )
        detailed_issues.extend(sql_issues)
        # Defer counting until deduplication step below

        # Extract Spark configurations
        spark_configurations = self._extract_spark_configurations(
            filtered_content, filtered_content_lines, line_number_map
        )

        # Check for unsupported Spark configurations
        for config_name, usages in spark_configurations.items():
            if config_name not in SUPPORTED_SPARK_CONFIGS:
                for usage in usages:
                    issue_counts["api_issues"] += 1
                    detailed_issues.append(
                        IssueDetail(
                            type="Unsupported Spark Configuration",
                            description=f'The Spark configuration "{config_name}" is not supported in serverless compute',
                            line_number=usage["line_number"],
                            code_snippet=usage["code_snippet"],
                            severity="Medium",
                            impact="Functional - Configuration will be ignored",
                            recommendation="Use only supported configurations for serverless: spark.databricks.execution.timeout, spark.sql.legacy.timeParserPolicy, spark.sql.session.timeZone, spark.sql.shuffle.partitions, spark.sql.ansi.enabled",
                            affected_apis=["Spark Configurations"],
                            related_issues=["Configuration Migration"],
                        )
                    )

        # First, separate active and skipped issues
        active_issues: List[IssueDetail] = []
        skipped_issues_list: List[IssueDetail] = []

        for iss in detailed_issues:
            if iss.is_skipped:
                skipped_issues_list.append(iss)
            else:
                active_issues.append(iss)

        # Deduplicate issue counting across overlapping patterns by line number
        # ONLY count active (non-skipped) issues
        category_type_map = {
            "api_issues": {
                "Unsupported API",
                "Unsupported SQL API",
                "Unsupported Spark Configuration",
            },
            "command_issues": {"Unsupported Command", "Unsupported SQL Command"},
            "caching_issues": {"Unsupported Caching"},
            "performance_issues": {"Performance Concern"},
            "language_issues": {"Unsupported Language"},
            # Keep existing keys; others default to empty sets
        }

        # Reset all category counts to 0 before recounting (since we initially counted all issues)
        for cat in category_type_map.keys():
            issue_counts[cat] = 0

        # Build sets of line numbers per category - ONLY from active issues
        dedup_sets: Dict[str, set] = {k: set() for k in issue_counts.keys()}
        active_issue_lines: set = set()

        for iss in active_issues:
            line_no = iss.line_number
            line_key: Union[int, Tuple[str, str]]
            if not isinstance(line_no, int) or line_no <= 0:
                # Use a synthetic line key for non-positive/missing line numbers
                line_key = (iss.type, iss.code_snippet)
            else:
                line_key = line_no

            # Map issue type to categories
            for cat, types in category_type_map.items():
                if iss.type in types:
                    dedup_sets[cat].add(line_key)
            # For categories not explicitly mapped above, leave previous counts as-is

            active_issue_lines.add(line_key)

        # Set counts based on deduplicated active issues only
        for cat, lines in dedup_sets.items():
            issue_counts[cat] = len(lines)

        # Determine overall compatibility: compatible only if no active (non-skipped) issues were found
        is_compatible = len(active_issue_lines) == 0

        # Calculate total issues based on unique active lines (not sum of categories)
        total_issues = len(active_issue_lines)

        # Track skipped issues separately
        issue_counts["skipped_issues"] = len(skipped_issues_list)

        complexity = self.complexity_calculator.calculate_complexity_level(total_issues)

        # Calculate migration effort
        migration_effort = self.complexity_calculator.calculate_migration_effort(
            total_issues, complexity_factors
        )

        # Build contextual high-level recommendations based on ACTIVE issues only
        if not is_compatible:
            has_unsupported_language = False
            has_unsupported_api = False
            has_unsupported_sql_api = False
            has_unsupported_caching = False
            has_performance_concern = False
            has_hive_or_serde = False
            has_unsupported_format = False
            has_unsupported_spark_config = False

            # Only consider active (non-skipped) issues for recommendations
            for iss in active_issues:
                iss_type = (iss.type or "").strip()
                snippet_lower = (iss.code_snippet or "").lower()
                affected = [a.lower() for a in (iss.affected_apis or [])]

                if iss_type == "Unsupported Language":
                    has_unsupported_language = True
                if iss_type == "Unsupported API":
                    has_unsupported_api = True
                if iss_type == "Unsupported SQL API":
                    has_unsupported_sql_api = True
                if iss_type == "Unsupported Caching":
                    has_unsupported_caching = True
                if iss_type == "Performance Concern":
                    has_performance_concern = True
                if iss_type == "Unsupported Spark Configuration":
                    has_unsupported_spark_config = True
                # Heuristics for Hive/SerDe and unsupported formats
                if "serde" in snippet_lower or "hive" in snippet_lower:
                    has_hive_or_serde = True
                if "unsupported_formats" in affected or ".format(" in snippet_lower:
                    has_unsupported_format = True

            # Only suggest what is relevant for the notebook (based on active issues)
            if has_unsupported_language:
                recommendations.append("Migrate to supported languages (Python/SQL)")

            if has_unsupported_api or has_unsupported_sql_api:
                recommendations.append(
                    "Replace unsupported APIs with Spark Connect alternatives"
                )

            if has_unsupported_caching:
                recommendations.append("Implement alternative caching strategies")

            if has_unsupported_format or has_unsupported_sql_api:
                recommendations.append("Use supported data sources and formats")

            if has_hive_or_serde:
                recommendations.append("Migrate from Hive SerDe tables and variables")

            if has_performance_concern:
                recommendations.append(
                    "Review and optimize performance-heavy operations"
                )

            if has_unsupported_spark_config:
                recommendations.append(
                    "Use only supported Spark configurations for serverless"
                )

        return ServerlessAnalysis(
            notebook_path=notebook_path,
            is_compatible=is_compatible,
            complexity=complexity,
            issues=issues,
            required_changes=required_changes,
            performance_impacts=performance_impacts,
            recommendations=recommendations,
            code_snippets=code_snippets,
            language_support=language_support,
            api_support=api_support,
            data_source_support=data_source_support,
            streaming_support=streaming_support,
            ml_support=ml_support,
            caching_support=caching_support,
            hive_support=hive_support,
            issue_counts=issue_counts,
            complexity_factors=complexity_factors,
            migration_effort=migration_effort,
            detailed_issues=detailed_issues,
            analysis_timestamp=datetime.now().isoformat(),
            notebook_metadata=notebook_metadata,
            spark_configurations=spark_configurations,
        )

    def _init_support_flags(
        self,
    ) -> Tuple[
        Dict[str, bool],
        Dict[str, bool],
        Dict[str, bool],
        Dict[str, bool],
        Dict[str, bool],
        Dict[str, bool],
        Dict[str, bool],
        Dict[str, bool],
    ]:
        """Initialize support flags assuming non-compatibility by default."""
        api_support = {"rdd": False, "spark_context": False, "global_temp_views": False}
        caching_support = {"cache_apis": False, "cache_commands": False}
        data_source_support = {"hive_serde": False, "unsupported_formats": False}
        streaming_support = {"unsupported_triggers": False, "supported_triggers": False}
        ml_support = {"ml_libs": False, "gpu": False}
        hive_support = {"serde": False, "variables": False}
        dbfs_support = {"mounts": False}
        udf_support = {"internet_access": False}
        return (
            api_support,
            caching_support,
            data_source_support,
            streaming_support,
            ml_support,
            hive_support,
            dbfs_support,
            udf_support,
        )

    def _extract_spark_configurations(
        self, content: str, content_lines: List[str], line_number_map: List[int]
    ) -> Dict[str, List[Dict[str, Any]]]:
        """Find Spark configurations in the notebook code."""
        spark_configurations: Dict[str, List[Dict[str, Any]]] = {}

        # Patterns to match different ways of setting Spark configurations
        patterns = [
            # Python: spark.conf.set("spark.conf.name", "value")
            r'spark\.conf\.set\([\'"]([^\'"]*)[\'"]\s*,\s*[\'"]([^\'"]*)[\'"]',
            # Python: sqlContext.setConf("spark.conf.name", "value")
            r'sqlContext\.setConf\([\'"]([^\'"]*)[\'"]\s*,\s*[\'"]([^\'"]*)[\'"]',
            # SparkConf: conf.set("spark.conf.name", "value")
            r'\.set\([\'"]([^\'"]*)[\'"]\s*,\s*[\'"]([^\'"]*)[\'"]',
            # SQL: SET spark.conf.name=value
            r"SET\s+([^\s=]+)\s*=\s*([^\s;]+)",
            # SparkSession builder: .config("spark.conf.name", "value")
            r'\.config\([\'"]([^\'"]*)[\'"]\s*,\s*[\'"]([^\'"]*)[\'"]',
        ]

        for i, line in enumerate(content_lines, 1):
            for pattern in patterns:
                matches = re.findall(pattern, line, re.IGNORECASE)
                for match in matches:
                    config_name = match[0]
                    config_value = match[1]

                    # Only process if it's a Spark configuration
                    if config_name.startswith("spark."):
                        if config_name not in spark_configurations:
                            spark_configurations[config_name] = []

                        spark_configurations[config_name].append({
                            "line_number": line_number_map[i - 1]
                            if line_number_map
                            else i,
                            "code_snippet": line.strip(),
                            "value": config_value,
                            "is_supported": config_name in SUPPORTED_SPARK_CONFIGS,
                        })

        return spark_configurations
