"""
Language detection for serverless analyzer.
"""

import re
from pathlib import Path


class LanguageDetector:
    """Handles language detection for notebooks."""

    def detect_language_from_content(self, content: str, notebook_path: str) -> str:
        """Detect language from notebook content."""
        # Check for magic commands first (line-aware)
        if re.search(r"(?m)^\s*%python\b", content):
            return "python"
        elif re.search(r"(?m)^\s*%sql\b", content):
            return "sql"
        elif re.search(r"(?m)^\s*%scala\b", content):
            return "scala"
        # %run is a Python magic and must NOT be mistaken for %r
        elif re.search(r"(?m)^\s*%run\b", content):
            return "python"
        elif re.search(r"(?m)^\s*%r(\s|$)", content):
            return "r"

        # Check file extension
        path = Path(notebook_path)
        if path.suffix.lower() == ".py":
            return "python"
        elif path.suffix.lower() == ".sql":
            return "sql"
        elif path.suffix.lower() == ".scala":
            # Check if Scala file has JAR compilation indicators
            jar_indicators = 0
            jar_patterns = [
                r"def\s+main\s*\(args:\s*Array\[String\]\)",
                r"object\s+\w+\s*\{",
                r"package\s+\w+",
                r"extends\s+(?:App|Application)",
                r"case\s+class\s+\w+",
                r"trait\s+\w+",
            ]
            for pattern in jar_patterns:
                if re.search(pattern, content, re.IGNORECASE):
                    jar_indicators += 1

            if jar_indicators >= 2:
                return "scala_jar"
            else:
                return "scala"
        elif path.suffix.lower() == ".r":
            return "r"

        # Default to Python for Databricks notebooks
        if "# Databricks notebook source" in content:
            return "python"

        return "python"

    def is_jar_compilation(
        self, content: str, detected_language: str, scala_as_jar: bool = False
    ) -> bool:
        """Determine if Scala code is for JAR compilation."""
        if scala_as_jar or detected_language == "scala_jar":
            return True

        if detected_language == "scala":
            # Auto-detect JAR compilation patterns
            jar_indicators = 0
            jar_patterns = [
                r"def\s+main\s*\(args:\s*Array\[String\]\)",
                r"object\s+\w+\s*\{",
                r"package\s+\w+",
                r"extends\s+(?:App|Application)",
                r"case\s+class\s+\w+",
                r"trait\s+\w+",
            ]
            for pattern in jar_patterns:
                if re.search(pattern, content, re.IGNORECASE):
                    jar_indicators += 1

            return jar_indicators >= 2

        return False
