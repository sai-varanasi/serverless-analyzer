"""
Complexity calculation for serverless analyzer.
"""

import re
from typing import Dict, Any, List
from ..models.enums import ComplexityLevel


class ComplexityCalculator:
    """Handles complexity calculation for notebooks."""

    def calculate_complexity_factors(self, content_lines: List[str]) -> Dict[str, Any]:
        """Calculate complexity factors from content."""
        complexity_factors = {
            "code_size": len(content_lines),
            "complex_operations": 0,
            "data_transformations": 0,
            "external_dependencies": 0,
            "custom_functions": 0,
            "nested_operations": 0,
        }

        # Count data transformations
        data_transform_patterns = [
            r"\.select\(",
            r"\.filter\(",
            r"\.where\(",
            r"\.groupBy\(",
            r"\.join\(",
            r"\.union\(",
            r"\.intersect\(",
            r"\.except\(",
            r"\.distinct\(",
            r"\.dropDuplicates\(",
        ]

        for line in content_lines:
            for pattern in data_transform_patterns:
                if re.search(pattern, line, re.IGNORECASE):
                    complexity_factors["data_transformations"] += 1

        # Count external dependencies
        dependency_patterns = [
            r"import\s+\w+",
            r"from\s+\w+\s+import",
            r"pip\s+install",
            r"%pip\s+install",
        ]

        for line in content_lines:
            for pattern in dependency_patterns:
                if re.search(pattern, line, re.IGNORECASE):
                    complexity_factors["external_dependencies"] += 1

        # Count custom functions
        function_patterns = [r"def\s+\w+\s*\(", r"lambda\s+", r"\.apply\(", r"\.map\("]

        for line in content_lines:
            for pattern in function_patterns:
                if re.search(pattern, line, re.IGNORECASE):
                    complexity_factors["custom_functions"] += 1

        # Count nested operations
        nested_patterns = [
            r"\.select\(.*\.select\(",
            r"\.filter\(.*\.filter\(",
            r"\.where\(.*\.where\(",
            r"\.groupBy\(.*\.groupBy\(",
            r"\.join\(.*\.join\(",
        ]

        for line in content_lines:
            for pattern in nested_patterns:
                if re.search(pattern, line, re.IGNORECASE):
                    complexity_factors["nested_operations"] += 1

        return complexity_factors

    def calculate_complexity_level(self, total_issues: int) -> ComplexityLevel:
        """Calculate complexity level based on total issues."""
        if total_issues == 0:
            return ComplexityLevel.LOW
        elif total_issues <= 3:
            return ComplexityLevel.MEDIUM
        elif total_issues <= 7:
            return ComplexityLevel.HIGH
        else:
            return ComplexityLevel.EXTREME

    def calculate_migration_effort(
        self, total_issues: int, complexity_factors: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Calculate migration effort based on issues and complexity factors.

        Returns a legacy-aligned structure including estimated_hours, risk_level,
        priority, and dependencies.
        """
        # Estimated hours: rough estimate as in legacy (2 hours per issue, minimum 1)
        estimated_hours = max(1, total_issues * 2)

        # Risk level based on number of issues
        if total_issues > 5:
            risk_level = "High"
        elif total_issues > 2:
            risk_level = "Medium"
        else:
            risk_level = "Low"

        # Priority mirrors legacy behavior: High if any issues, else Low
        priority = "High" if total_issues > 0 else "Low"

        # Dependency complexity derived from external dependency count
        dependencies = (
            "High"
            if complexity_factors.get("external_dependencies", 0) > 5
            else (
                "Medium"
                if complexity_factors.get("external_dependencies", 0) > 2
                else "Low"
            )
        )

        return {
            "estimated_hours": estimated_hours,
            "risk_level": risk_level,
            "priority": priority,
            "dependencies": dependencies,
        }
