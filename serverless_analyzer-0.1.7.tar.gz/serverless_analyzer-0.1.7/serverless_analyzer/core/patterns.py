"""
Pattern matching for serverless analyzer.
"""

import re
from typing import List, Optional, TYPE_CHECKING
from ..models.issues import IssueDetail
from ..config.patterns import PATTERNS

if TYPE_CHECKING:
    # Imported only for type checking to avoid runtime dependency
    from ..config.skip_config import SkipConfig


class PatternMatcher:
    """Handles pattern matching for compatibility analysis."""

    def __init__(self, skip_config: Optional["SkipConfig"] = None) -> None:
        self.patterns = PATTERNS
        self.skip_config = skip_config

    def check_unsupported_languages(
        self, content: str, content_lines: List[str], detected_language: str
    ) -> List[IssueDetail]:
        """Check for unsupported languages."""
        issues = []

        if detected_language and detected_language.lower() in [
            "scala",
            "scala_jar",
            "r",
        ]:
            if detected_language.lower() in ["scala", "scala_jar"]:
                # Check if this is JAR compilation (supported)
                jar_indicators = 0
                for pattern in self.patterns["jar_compilation_indicators"].values():
                    if re.search(pattern, content, re.IGNORECASE):
                        jar_indicators += 1

                if jar_indicators < 2:
                    issues.append(
                        IssueDetail(
                            type="Unsupported Language",
                            description=f"{detected_language.upper()} is not supported in serverless compute",
                            line_number=1,
                            code_snippet=f"Notebook language: {detected_language}",
                            severity="High",
                            impact="Critical - Language must be changed",
                            recommendation=f"Convert {detected_language.upper()} code to Python or SQL",
                            affected_apis=[detected_language],
                            related_issues=["Language Migration"],
                        )
                    )
            else:
                # Handle R language (always unsupported)
                issues.append(
                    IssueDetail(
                        type="Unsupported Language",
                        description=f"{detected_language.upper()} is not supported in serverless compute",
                        line_number=1,
                        code_snippet=f"Notebook language: {detected_language}",
                        severity="High",
                        impact="Critical - Language must be changed",
                        recommendation=f"Convert {detected_language.upper()} code to Python or SQL",
                        affected_apis=[detected_language],
                        related_issues=["Language Migration"],
                    )
                )

        return issues

    def check_unsupported_apis(
        self, content_lines: List[str], line_number_map: Optional[List[int]] = None
    ) -> List[IssueDetail]:
        """Check for unsupported APIs."""
        issues = []

        for api, pattern in self.patterns["unsupported_apis"].items():
            # Check if this pattern should be skipped
            is_skipped = False
            skip_reason = None
            if self.skip_config:
                is_skipped = self.skip_config.should_skip("unsupported_apis", api)
                if is_skipped:
                    skip_reason = self.skip_config.get_skip_reason(
                        "unsupported_apis", api
                    )

            for i, line in enumerate(content_lines, 1):
                if re.search(pattern, line, re.IGNORECASE):
                    ln = line_number_map[i - 1] if line_number_map else i
                    api_description = self._get_api_description(api)
                    api_severity = self._get_api_severity(api)
                    api_impact = self._get_api_impact(api)
                    api_recommendation = self._get_api_recommendation(api)

                    issues.append(
                        IssueDetail(
                            type="Unsupported API",
                            description=api_description,
                            line_number=ln,
                            code_snippet=line.strip(),
                            severity=api_severity,
                            impact=api_impact,
                            recommendation=api_recommendation,
                            affected_apis=[api],
                            related_issues=["API Migration"],
                            is_skipped=is_skipped,
                            skip_reason=skip_reason,
                        )
                    )

        return issues

    def check_unsupported_commands(
        self, content_lines: List[str], line_number_map: Optional[List[int]] = None
    ) -> List[IssueDetail]:
        """Check for unsupported commands."""
        issues = []

        for cmd, pattern in self.patterns["unsupported_commands"].items():
            # Check if this pattern should be skipped
            is_skipped = False
            skip_reason = None
            if self.skip_config:
                is_skipped = self.skip_config.should_skip("unsupported_commands", cmd)
                if is_skipped:
                    skip_reason = self.skip_config.get_skip_reason(
                        "unsupported_commands", cmd
                    )

            for i, line in enumerate(content_lines, 1):
                if re.search(pattern, line, re.IGNORECASE):
                    ln = line_number_map[i - 1] if line_number_map else i
                    issues.append(
                        IssueDetail(
                            type="Unsupported Command",
                            description=f"{cmd} commands are not supported in serverless compute",
                            line_number=ln,
                            code_snippet=line.strip(),
                            severity="High",
                            impact="Critical - Command must be replaced",
                            recommendation=f"Replace {cmd} commands with serverless-compatible alternatives",
                            affected_apis=[cmd],
                            related_issues=["Command Replacement"],
                            is_skipped=is_skipped,
                            skip_reason=skip_reason,
                        )
                    )

        return issues

    def check_unsupported_caching(
        self, content_lines: List[str], line_number_map: Optional[List[int]] = None
    ) -> List[IssueDetail]:
        """Check for unsupported caching."""
        issues = []

        for cache_type, pattern in self.patterns["unsupported_caching"].items():
            # Check if this pattern should be skipped
            is_skipped = False
            skip_reason = None
            if self.skip_config:
                is_skipped = self.skip_config.should_skip(
                    "unsupported_caching", cache_type
                )
                if is_skipped:
                    skip_reason = self.skip_config.get_skip_reason(
                        "unsupported_caching", cache_type
                    )

            for i, line in enumerate(content_lines, 1):
                if re.search(pattern, line, re.IGNORECASE):
                    ln = line_number_map[i - 1] if line_number_map else i
                    issues.append(
                        IssueDetail(
                            type="Unsupported Caching",
                            description=f"{cache_type} are not supported in serverless compute",
                            line_number=ln,
                            code_snippet=line.strip(),
                            severity="Medium",
                            impact="Performance - Caching strategy must be changed",
                            recommendation=f"Implement alternative caching strategy for {cache_type}",
                            affected_apis=[cache_type],
                            related_issues=["Caching Strategy"],
                            is_skipped=is_skipped,
                            skip_reason=skip_reason,
                        )
                    )

        return issues

    def check_performance_concerns(
        self, content_lines: List[str], line_number_map: Optional[List[int]] = None
    ) -> List[IssueDetail]:
        """Check for performance concerns."""
        issues = []

        for concern, pattern in self.patterns["performance_concerns"].items():
            # Check if this pattern should be skipped
            is_skipped = False
            skip_reason = None
            if self.skip_config:
                is_skipped = self.skip_config.should_skip(
                    "performance_concerns", concern
                )
                if is_skipped:
                    skip_reason = self.skip_config.get_skip_reason(
                        "performance_concerns", concern
                    )

            for i, line in enumerate(content_lines, 1):
                if re.search(pattern, line, re.IGNORECASE):
                    ln = line_number_map[i - 1] if line_number_map else i
                    issues.append(
                        IssueDetail(
                            type="Performance Concern",
                            description=f"Consider optimizing {concern} operations for serverless",
                            line_number=ln,
                            code_snippet=line.strip(),
                            severity="Medium",
                            impact="Performance - Operation may need optimization",
                            recommendation=f"Review and optimize {concern} operations",
                            affected_apis=[concern],
                            related_issues=["Performance Optimization"],
                            is_skipped=is_skipped,
                            skip_reason=skip_reason,
                        )
                    )

        return issues

    def check_sql_issues(
        self, content_lines: List[str], line_number_map: Optional[List[int]] = None
    ) -> List[IssueDetail]:
        """Check for SQL-specific issues."""
        issues = []

        # Check SQL unsupported APIs
        for api, pattern in self.patterns["sql_unsupported_apis"].items():
            # Check if this pattern should be skipped
            is_skipped = False
            skip_reason = None
            if self.skip_config:
                is_skipped = self.skip_config.should_skip("sql_unsupported_apis", api)
                if is_skipped:
                    skip_reason = self.skip_config.get_skip_reason(
                        "sql_unsupported_apis", api
                    )

            for i, line in enumerate(content_lines, 1):
                if re.search(pattern, line, re.IGNORECASE):
                    ln = line_number_map[i - 1] if line_number_map else i
                    issues.append(
                        IssueDetail(
                            type="Unsupported SQL API",
                            description=f"{api} is not supported in serverless compute",
                            line_number=ln,
                            code_snippet=line.strip(),
                            severity="High",
                            impact="Critical - SQL feature must be migrated",
                            recommendation=f"Replace {api} with serverless-compatible alternatives",
                            affected_apis=[api],
                            related_issues=["SQL Migration"],
                            is_skipped=is_skipped,
                            skip_reason=skip_reason,
                        )
                    )

        # Check SQL unsupported commands
        for cmd, pattern in self.patterns["sql_unsupported_commands"].items():
            # Check if this pattern should be skipped
            is_skipped = False
            skip_reason = None
            if self.skip_config:
                is_skipped = self.skip_config.should_skip(
                    "sql_unsupported_commands", cmd
                )
                if is_skipped:
                    skip_reason = self.skip_config.get_skip_reason(
                        "sql_unsupported_commands", cmd
                    )

            for i, line in enumerate(content_lines, 1):
                if re.search(pattern, line, re.IGNORECASE):
                    ln = line_number_map[i - 1] if line_number_map else i
                    # Defaults
                    severity = "High"
                    impact = "Critical - SQL command must be replaced"
                    description = (
                        f"{cmd} commands are not supported in serverless compute"
                    )
                    recommendation = f"Replace {cmd} commands with serverless-compatible alternatives"

                    # JDBC private preview handling
                    if cmd == "jdbc_reads":
                        severity = "Medium"
                        impact = "Limited - Private preview; functionality and availability may vary"
                        description = "JDBC reads may be available via private preview; validate compatibility before use."
                        recommendation = "Validate JDBC read support in your workspace; consider alternatives if unavailable"
                    issues.append(
                        IssueDetail(
                            type="Unsupported SQL Command",
                            description=description,
                            line_number=ln,
                            code_snippet=line.strip(),
                            severity=severity,
                            impact=impact,
                            recommendation=recommendation,
                            affected_apis=[cmd],
                            related_issues=["SQL Command Replacement"],
                            is_skipped=is_skipped,
                            skip_reason=skip_reason,
                        )
                    )

        return issues

    def _get_api_description(self, api: str) -> str:
        """Get description for API type."""
        descriptions = {
            "rdd": "RDD APIs are not supported in serverless compute",
            "spark_context": "Spark Context (sc), spark.sparkContext, and sqlContext are not supported in serverless compute",
            "global_temp_views": "Global temporary views are not supported in serverless compute",
            "timeout_settings": "Custom Spark query timeout settings detected. Default is 9000 seconds in serverless.",
            "unsupported_formats": "Data source format may not be supported in serverless. Only AVRO, BINARYFILE, CSV, DELTA, JSON, KAFKA, ORC, PARQUET, TEXT, and XML are supported.",
            "large_rows": "Individual rows must not exceed 128MB in serverless compute",
        }
        return descriptions.get(api, f"{api} is not supported in serverless compute")

    def _get_api_severity(self, api: str) -> str:
        """Get severity for API type."""
        if api == "timeout_settings":
            return "Low"
        elif api == "large_rows":
            return "Medium"
        return "High"

    def _get_api_impact(self, api: str) -> str:
        """Get impact for API type."""
        if api == "timeout_settings":
            return "Performance - Query timeout behavior difference"
        elif api == "large_rows":
            return "Functional - Large row operations may fail"
        return "Critical - API must be replaced"

    def _get_api_recommendation(self, api: str) -> str:
        """Get recommendation for API type."""
        if api == "timeout_settings":
            return "Review any long-running queries and optimize if needed"
        elif api == "unsupported_formats":
            return "Convert data to a supported format"
        elif api == "large_rows":
            return "Restructure data to avoid very large individual rows"
        return f"Replace {api} APIs with Spark Connect alternatives"
