"""
Databricks Serverless Compatibility Analyzer

Tool to check Databricks notebooks for serverless compatibility and identify migration issues.
"""

# Import models
from .models import (
    ServerlessAnalysis,
    ConsolidatedReport,
    IssueDetail,
    WorkspaceMetadata,
    ComplexityLevel,
)

# Import core components
from .core import (
    CompatibilityAnalyzer,
    PatternMatcher,
    LanguageDetector,
    ComplexityCalculator,
)

# Import I/O components
from .io import (
    FileReader,
    WorkspaceClient,
    NotebookParser,
)

# Import services
from .services import (
    AnalysisService,
    ReportService,
    WorkspaceService,
)

# Import CLI components
from .cli import (
    ArgumentParser,
    OutputFormatter,
    CLIRunner,
)

__version__ = "0.1.4"

__all__ = [
    # Models
    "ServerlessAnalysis",
    "ConsolidatedReport",
    "IssueDetail",
    "WorkspaceMetadata",
    "ComplexityLevel",
    # Core components
    "CompatibilityAnalyzer",
    "PatternMatcher",
    "LanguageDetector",
    "ComplexityCalculator",
    # I/O components
    "FileReader",
    "WorkspaceClient",
    "NotebookParser",
    # Services
    "AnalysisService",
    "ReportService",
    "WorkspaceService",
    # CLI components
    "ArgumentParser",
    "OutputFormatter",
    "CLIRunner",
]
