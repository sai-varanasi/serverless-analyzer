# Databricks Serverless Compatibility Analyzer

A comprehensive tool for analyzing Databricks notebooks to determine their compatibility with Databricks Serverless compute and provide complexity assessment for migration. Enhanced with comprehensive metadata collection, cost analysis capabilities, and a modular architecture.

P.S: The docs and the tests are AI generated, so they may not be 100% accurate.

## 🏗️ Architecture

The analyzer follows a modular architecture with clear separation of concerns:

```text
serverless_analyzer/
├── models/           # Data models and domain objects
├── config/           # Configuration and constants  
├── core/             # Core business logic
├── io/               # Input/Output operations
├── services/         # Service orchestration layer
├── cli/              # Command-line interface components
└── __init__.py       # Package initialization with backward compatibility
```

### Layer Responsibilities

- **Models**: Data structures, enums, and domain objects
- **Config**: Pattern definitions and constants
- **Core**: Business logic for compatibility analysis
- **I/O**: File operations and workspace interactions
- **Services**: High-level orchestration and reporting
- **CLI**: Command-line interface components

## 🚀 Installation

### Option 1: Using uv (recommended for speed)

```bash
# Install uv if not installed
curl -LsSf https://astral.sh/uv/install.sh | sh

# Create and activate a virtualenv
uv venv .venv
source .venv/bin/activate

# Install in editable mode with dev extras (ruff, mypy, pytest, etc.)
uv pip install -e .[dev]
```

### Option 2: Using pip

```bash
# Create and activate a virtualenv (macOS/Linux)
python3 -m venv .venv
source .venv/bin/activate

# Install in editable mode with dev extras (ruff, mypy, pytest, etc.)
pip install -e .[dev]
```

### Option 3: Install from the directory (runtime only)

```bash
# Clone this repository
git clone https://github.com/databricks-field-eng/serverless-analyzer
cd serverless-analyzer

# Install the package directly (runtime deps only)
pip install .

# OR build a wheel first
python -m build
pip install dist/serverless_analyzer-*.whl
```

## 🛠️ Development Workflow

You can use the consolidated dev script:

```bash
# From repo root
bash tools/dev.sh all

# Or run specific steps
bash tools/dev.sh format   # ruff format
bash tools/dev.sh lint     # ruff check
bash tools/dev.sh type     # mypy
bash tools/dev.sh test     # pytest
```

Ruff configuration lives in `pyproject.toml` and consolidates lint and format in one tool. See Ruff for details: [astral-sh/ruff](https://github.com/astral-sh/ruff).

## 📖 Usage

### Basic Usage

```bash
# Analyze a single script
serverless-analyze /path/to/script.py

# Analyze a directory of scripts/notebooks
serverless-analyze /path/to/directory

# Analyze with output to specific directory
serverless-analyze /path/to/directory --output-dir ./reports

# Generate system table queries (writes .sql files under ./reports/queries)
serverless-analyze /path/to/directory --output-dir ./reports --generate-queries

# Enable verbose mode for debugging
serverless-analyze /path/to/script.py --verbose

# Skip specific checks (see Skip Specific Checks section below)
serverless-analyze /path/to/script.py --skip-checks performance_concerns,driver_actions

# List all available check names
serverless-analyze --list-checks
```

### Export Modes

The CLI provides a unified export flag to control where results go:

- `--export json`: Write JSON files
- `--export csv`: Write CSV files
- `--export tables`: Publish to Unity Catalog tables

Examples:

```bash
# JSON: write consolidated + individual JSON reports
serverless-analyze /path/to/directory --export json --output-dir ./reports

# CSV: write CSV artifacts under ./reports/csv
serverless-analyze /path/to/directory --export csv --output-dir ./reports

# Tables: publish results to Unity Catalog (optionally skip detailed rows)
serverless-analyze /path/to/directory \
  --export tables \
  --catalog main \
  --schema serverless_reports \
  --warehouse-id <WAREHOUSE_ID> \
  --no-detailed
```

### Contextual CLI Help

Help adapts to the selected export mode. Try:

```bash
serverless-analyze -h                  # Quick start and core options
serverless-analyze --export csv -h     # CSV-specific help
serverless-analyze --export tables -h  # Publishing-specific help
```

### Export Modes

The CLI provides a unified export flag to control where results go:

- `--export json`: Write JSON files
- `--export csv`: Write CSV files
- `--export tables`: Publish to Unity Catalog tables

Examples:

```bash
# JSON: write consolidated + individual JSON reports
serverless-analyze /path/to/directory --export json --output-dir ./reports

# CSV: write CSV artifacts under ./reports/csv
serverless-analyze /path/to/directory --export csv --output-dir ./reports

# Tables: publish results to Unity Catalog (optionally skip detailed rows)
serverless-analyze /path/to/directory \
  --export tables \
  --catalog main \
  --schema serverless_reports \
  --warehouse-id <WAREHOUSE_ID> \
  --no-detailed
```

### Contextual CLI Help

Help adapts to the selected export mode. Try:

```bash
serverless-analyze -h                  # Quick start and core options
serverless-analyze --export csv -h     # CSV-specific help
serverless-analyze --export tables -h  # Publishing-specific help
```

### Advanced Features

```bash
# Publish results to Unity Catalog (unified export)
serverless-analyze /path/to/directory \
  --export tables \
  --catalog main \
  --schema serverless_reports \
  --warehouse-id <WAREHOUSE_ID>

# Use in Databricks environment
serverless-analyze /path/to/directory --databricks

# Full analysis with all features
serverless-analyze /path/to/directory \
  --databricks \
  --generate-queries \
  --output-dir ./reports \
  --export tables \
  --verbose
```

### Skip Specific Checks

You can skip specific compatibility checks during analysis using the `--skip-checks` flag. Skipped issues are still detected and reported but marked as "skipped" for transparency.

```bash
# Skip entire performance concerns category
serverless-analyze notebook.py --skip-checks performance_concerns

# Skip specific sub-patterns
serverless-analyze notebook.py --skip-checks driver_actions,cache_apis

# Skip multiple categories
serverless-analyze notebook.py --skip-checks performance_concerns,unsupported_caching

# Mix categories and sub-patterns
serverless-analyze notebook.py --skip-checks performance_concerns,hive_variables

# List all available check names
serverless-analyze --list-checks
```

**Available Categories:**

- `unsupported_apis` - RDD, SparkContext, global temp views, etc.
- `unsupported_commands` - Hive variables and other commands
- `unsupported_caching` - Cache/persist APIs and commands
- `performance_concerns` - Driver actions, large operations, etc.
- `sql_unsupported_apis` - SQL-specific API issues
- `sql_unsupported_commands` - SQL-specific command issues

**Common Sub-patterns:**

- `driver_actions` - .collect(), .toLocalIterator()
- `large_operations` - .toPandas()
- `cache_apis` - .cache(), .persist()
- `rdd` - RDD operations
- And more (use `--list-checks` to see all)

**Key Points:**

- Skipped issues are still detected and included in reports
- They are marked with "⏭️ SKIPPED" in the output
- Skipped issues don't affect compatibility status
- Available in all export modes (JSON, CSV, tables)

### Scala JAR Support

The analyzer auto-detects Scala source intended for JAR compilation:

```bash
# Force JAR mode for Scala files
serverless-analyze /path/to/script.scala --scala-as-jar
```

Auto-detection looks for JAR indicators:

- `object Main` declarations
- `def main(args: Array[String])` methods
- `package` declarations
- `extends App` or `extends Application`
- `case class` and `trait` declarations

## 🔍 Features

### Compatibility Analysis

Identifies potential issues with:

- **Unsupported Languages**: Scala (non-JAR), R
- **Unsupported APIs**: RDD, Spark Context, Global temp views
- **Unsupported Commands**: Hive variables, custom timeouts
- **Caching Limitations**: Cache APIs and commands
- **Performance Concerns**: Large operations, complex transformations
- **Data Source Issues**: Unsupported formats, Hive SerDe
- **JDBC Reads (Private Preview)**: JDBC reads may be available via private preview; validate compatibility and availability in your workspace
- **Streaming Limitations**: Unsupported triggers
- **ML Limitations**: GPU usage, unsupported libraries
- **DBFS Limitations**: Mount operations
- **UDF Limitations**: Internet access restrictions

### Enhanced Metadata Collection

- **Workspace Metadata**: Object IDs, timestamps, user info, workspace URLs
- **Local File Metadata**: File system metadata, sizes, timestamps
- **Language Detection**: Multi-source detection (extensions, magic commands, metadata)

### System Table Query Generation

Generate SQL queries for cost analysis:

- Workspace objects metadata
- Execution history and compute usage
- Cost analysis and DBU usage
- Query history patterns
- Data lineage and dependencies
- Audit logs and user activity
- Cluster events and storage costs

## 📊 Output

The tool can produce multiple report types:

1. **JSON Files** (with `--export json`):
   - `consolidated_report.json` with aggregated metrics and metadata
   - `individual_reports/*_report.json` per analyzed notebook
2. **CSV Files** (with `--export csv`): written under `<output-dir>/csv/`
   - `dataset_summary.csv`: high-level metrics
   - `notebook_detailed.csv`: one row per notebook, includes per-issue counts and JSON blobs
   - `issues_detailed.csv`: one row per issue with notebook context (now includes `is_skipped` and `skip_reason` for easy filtering)
   - `issues_skipped.csv`: one row per skipped issue (subset of columns from `issues_detailed.csv`)
   Notes:
   - Spark configuration counts are not exported as separate columns; full configurations are preserved in the `spark_configurations_json` column.
   - Line numbers in reports reflect original source lines even when comments/docstrings are filtered during analysis.
3. **Unity Catalog Tables** (with `--export tables`):
   - Creates/uses tables in `<catalog>.<schema>`:
     - `serverless_analysis_consolidated`
     - `notebook_reports_detailed` (omit with `--no-detailed`)
4. **System Table Queries**: SQL for cost analysis (with `--generate-queries`) written under `<output-dir>/queries/` or printed to stdout.

### Key Features

- Analyzes individual notebooks or entire directories
- Provides complexity assessment for serverless migration
- **Enhanced workspace metadata collection via Databricks SDK**
- **Generates system table queries for cost analysis**
- Identifies potential issues with:
  - Unsupported languages (Scala, R) — Scala is supported when compiled as a JAR (auto-detected or via --scala-as-jar)
  - Unsupported APIs including:
    - RDD and Spark Context APIs
    - Global temporary views
    - Custom query timeout settings
    - Unsupported data formats
    - Row size limitations
  - Unsupported commands and Hive features
  - Caching limitations
  - Performance concerns
  - Data source compatibility
  - JDBC reads (private preview; availability may vary)
  - Streaming limitations
  - ML library limitations
  - DBFS mount limitations with AWS instance profiles
  - UDF internet access limitations

### Additional CLI Flags

- `--output-dir`: Destination directory for JSON/CSV outputs
- `--output`: Deprecated; when present, parent directory is used for CSV
- `--recursive`: Recursively analyze subdirectories
- `--max-file-size`: Maximum file size to analyze (bytes; default 10485760)
- `--include-metadata`: Include detailed workspace metadata in reports
- `--scala-as-jar`: Treat Scala files as JAR compilation targets
- `--databricks`: Enable Databricks workspace integration
- `--skip-checks`: Comma-separated list of checks to skip (see Skip Specific Checks section)
- `--list-checks`: List all available check names and exit
- `-v/--verbose`: Verbose logs
- `-V/--version`: Show version
- Deprecated: `--publish-tables` (use `--export tables`), `--format`
